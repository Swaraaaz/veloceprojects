import { Switch } from 'react-router-dom';
import { Route } from 'react-router-dom';
import { BrowserRouter } from 'react-router-dom';
import './App.css';
import Admin from './Admin/Admin';
import ForgotPassword from './Login/ForgotPassword';
import { Redirect } from 'react-router'
import Login from './Login/Login';
import AddEmployeeDetails from './Login/Employee/Components/AddEmployeeDetails';
import './App.css';

function App() {
  console.log(localStorage.getItem("emp_id"))
  return (
    <BrowserRouter>
      <Switch>
        <Route exact path='/Login' component={Login} />
        <Route exact path='/Reset_Password' component={ForgotPassword} />
        {
          localStorage.getItem("emp_id") !== undefined || localStorage.getItem("emp_id") !== null ? <Route exact path='/my_profile' component={AddEmployeeDetails} /> : <Redirect to="/Login" />
        }
        <Route path='/' component={Admin} />
      </Switch>
    </BrowserRouter>
  );
}

export default App;
