import React, { useState } from 'react'
import { useHistory } from 'react-router-dom'
import './login.css'
import logo from './logo.png'
import './input.css'
import axios from 'axios'

export default function ForgotPassword() {
    const [insertData, setInsertData] = useState({
        email: '',
        password: '',
        cpassword: ''
    });

    const history = useHistory()

    const validate = (e) => {
        handleChange(e)
        const submitBtn = document.getElementById("submit");
        axios.post("http://localhost/php/pms/auth/validateEmail.php", e.target.value).then((resp) => {
            // setData(resp.data)
            if (resp.data.length !== 0)
                submitBtn.disabled = false
            console.log(resp.data)
        })
    }

    const submit = (e) => {
        e.preventDefault()
        console.log(insertData)
        if(insertData.cpassword === insertData.password){
            axios.post("http://localhost/php/pms/auth/resetpassword.php", insertData)
            history.push("/Login")
        }
        else
            alert("Password and Confirm Password are not matching")

    }

    const handleChange = (e) => {
        setInsertData({ ...insertData, [e.target.name]: e.target.value });
    }

    return (
        <div className="login-wrapper">
            <form className="form" method='post' onSubmit={submit}>
                <img src={logo} alt="logo" />
                <h3>RESET PASSWORD</h3>
                <div className="omrs-input-group">
                    <label className="omrs-input-underlined">
                        <input
                            type="text"
                            name='email'
                            id="email"
                            value={insertData.email}
                            onChange={validate}
                            required />
                        <span className="omrs-input-label">Username</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>

                </div>
                <div className="omrs-input-group">
                    <label className="omrs-input-underlined">
                        <input
                            type="password"
                            name='password'
                            onChange={handleChange}
                            value={insertData.password}
                            required />
                        <span className="omrs-input-label">Password</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>
                </div>
                <div className="omrs-input-group">
                    <label className="omrs-input-underlined">
                        <input
                            type="password"
                            name='cpassword'
                            onChange={handleChange}
                            value={insertData.cpassword}
                            required />
                        <span className="omrs-input-label">Confirm Password</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>
                </div>
                <div className="row">
                    <div className="d-flex justify-content-between">
                        <p></p>
                        <input type="submit" value="Login" name="login" className="submit-btn" id="submit" disabled/>
                        <p></p>
                    </div>
                    <div className="d-flex justify-content-between mt-3">
                        <p></p>
                        <p></p>
                    </div>
                </div>
            </form>
        </div>
    )
}
