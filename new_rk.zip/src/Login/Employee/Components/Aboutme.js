import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import ReactDOM from "react-dom";
import axios from "axios";
import { BorderColor } from "@material-ui/icons";
export default function Aboutme() {
  const [insertData, setInsertData] = useState({
    emp_id: 1,
  });

  const handleChange = (e) => {
    setInsertData({ ...insertData, [e.target.name]: e.target.value });
  };


  const [show, setShow] = useState(true);
  const [show1, setShow1] = useState(false);
  const [validated, setValidated] = useState(false);
  const editclick = (e) => {
    setShow1(true);
    setShow(false);

      axios
    .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
    .then((res) => {
      //Storing users detail in state array object
      setData(res.data[0]);
    });
  };

  const cancelclick = (e) => {
    setShow1(false);
    setShow(true);
  };
  const [data, setData] = useState();
  const addaboutme = (e, index) => {
   
    const form = e.currentTarget;
 
    if (form.checkValidity() === false) {
      e.preventDefault();
      e.stopPropagation();
      setValidated(true);
    }else{
  
    e.preventDefault();

    axios
      .post(
        "http://localhost/php/pms/employee/updateEmployee.php",
        insertData
      )
      .then((response) => {
        setShow1(false);
        setShow(true);
        axios
        .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
        .then((res) => {
          //Storing users detail in state array object
          setData(res.data[0]);
        });
      
      })
      .catch((error) => {
        console.log(error);
      });
    }
  };

  useEffect(() => {
    axios
  .get("http://localhost/php/pms/employee/getEmployeebyId.php")
  .then((res) => {
   
    setData(res.data[0]);
  });
  }, []);
 

  return (
    <div className="row col-md-11">
      <div className="col-md-3"></div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-body">
            <h6 className="name">About Me</h6>
            {show && (
              <div className="row">
                <div className="col-md-2 float-left">
                  
                <i className='bx bxs-user-circle'></i>
                </div>
                <div align="center" className="col-md-10">
                  <Row className="mb-3">
                    <Form.Group
                      as={Row}
                      className="mb-3"
                      controlId="exampleForm.ControlTextarea1"
                    >
                      {/* <Form.Label column sm={2}>
                        About me
                      </Form.Label> */}
                      <Col sm={10}>
                        <Form.Control
                          value=  {data === undefined ? "" : data.about_me}
                          placeholder="Share interesting life stories about yourself"
                           style= {{borderColor: "transparent"}}
                          as="textarea"
                          rows={1}
                        />
                        <Form.Control.Feedback type="invalid">
                          Please Share interesting life stories about yourself
                        </Form.Control.Feedback>
                      </Col>
                    </Form.Group>
                  </Row>
                  <Button
                  type="submit"
                  style={{ marginLeft: "2%" }}
                  status="primary"    onClick={editclick}>
                 Tell About Yourself
                </Button>
                
                </div>
              </div>
            )}
              <div>
              <Form noValidate validated={validated} onSubmit={addaboutme}>
               
                {show1 && (
                  <div>
                <Form.Group
                      as={Row}
                      className="mb-3"
                      controlId="exampleForm.ControlTextarea1"
                      onSubmit={addaboutme}
                    >
                     
                      <Col sm={10}>
                        
                        <Form.Control
                            as="textarea"
                          name="aboutme"
                          onChange={handleChange}
                          defaultValue= {data === undefined ? "" : data.about_me}
                          placeholder="About me"
                          required
                        />
                        <Form.Control.Feedback type="invalid">
                        About me required
                        </Form.Control.Feedback>
                      </Col>
                    </Form.Group>
               
                   
                <Button variant="success" type="submit">Save</Button>
                <Button
                  type="submit"
                  style={{ marginLeft: "2%" }}
                  status="primary"  onClick={cancelclick} >
                  cancel
                </Button>
                </div>
                 )}
            </Form>
          </div>
        </div>
      </div>
    </div>
    </div>
  );
}
