import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import Aboutme from "./Aboutme";
import AdditionalInformation from "./AdditionalInformation";
import EmployeeContactInfo from "./EmployeeContactInfo";
import EmployeeEducation from "./EmployeeEducation";
import KYC from "./EmployeeKYC";
import IntrestOfFields from "./IntrestOfFields";
import ThingsILike from "./ThingsILike";

import "./employee.css";
export default function AddEmployeeDetails() {
  const [validated, setValidated] = useState(false);
  // date parameter is a date object

  const handleSubmit = (event) => {
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    setValidated(true);
  };
  return (
  
      <div className="row col-md-12">
        <div className="col-md-3">
          <div className="card">
            <div className="card-body">
              <span>Upload photo</span>

              <div className="form-group" align="center">
                <form>
                  <img className="myimg" alt="" style={{ cursor: "pointer" }} />

                  <div className="upload-img-div">
                    <div
                      className="iupload-img"
                      id="intranet-user-profile-photo-file"
                    >
                      Upload a photo
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-9">
        <div className="card">
          <div className="card-body">
              <h6 className="name">Basic Information</h6>
              <Form noValidate validated={validated} onSubmit={handleSubmit}>
                <Row className="mb-3">
                  <Form.Group as={Row}>
                    <Form.Label column sm={2}>
                      First name
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        readOnly
                        type="text"
                        placeholder="First name"
                        defaultValue="Mark"
                        name="emp_firstname"
                      />
                    </Col>

                    <Form.Label column sm={2}>
                      Last name
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        readOnly
                        type="text"
                        name="emp_lastname"
                        placeholder="Last name"
                        defaultValue="Otto"
                      />
                    </Col>
                  </Form.Group>
                </Row>{" "}
                <Row className="mb-3">
                  <Form.Group as={Row} controlId="validationCustom02">
                    <Form.Label column sm={2}>
                      Employee Type
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control required as="select" custom>
                        <option value="">Select gender</option>
                        <option value="male">A</option>
                        <option value="Female">B</option>
                      </Form.Control>{" "}
                    </Col>
                    <Form.Control.Feedback type="invalid">
                      Please department
                    </Form.Control.Feedback>

                    <Form.Label column sm={2}>
                      Gender
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control required as="select" custom>
                        <option value="">Select gender</option>
                        <option value="male">A</option>
                        <option value="Female">B</option>
                      </Form.Control>{" "}
                    </Col>
                    <Form.Control.Feedback type="invalid">
                      Please department
                    </Form.Control.Feedback>
                  </Form.Group>
                </Row>
                <Row className="mb-3">
                  <Form.Group as={Row} controlId="dob">
                    <Form.Label column sm={2}>
                      Select Date
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="date"
                        name="dob"
                        placeholder="Date of Birth"
                      />{" "}
                    </Col>
                    <Form.Control.Feedback type="invalid">
                      Please dob
                    </Form.Control.Feedback>

                    <Form.Label column sm={2}>
                      Deparment
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control required as="select" custom>
                        <option value="">Select gender</option>
                        <option value="male">A</option>
                        <option value="Female">B</option>
                      </Form.Control>{" "}
                    </Col>
                    <Form.Control.Feedback type="invalid">
                      Please department
                    </Form.Control.Feedback>
                  </Form.Group>
                </Row>
                <Button type="submit">Submit form</Button>
              </Form>
            </div>
          </div>
        </div>
        <EmployeeContactInfo></EmployeeContactInfo>
        <KYC></KYC>
        <EmployeeEducation></EmployeeEducation>
        <Aboutme></Aboutme>
        <ThingsILike></ThingsILike>
        <IntrestOfFields></IntrestOfFields>
        <AdditionalInformation></AdditionalInformation>
      </div>
   
  );
}
