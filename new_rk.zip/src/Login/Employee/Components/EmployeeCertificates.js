import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
import EmployeeCOA from "./EmployeeCOA";
import EmployeeSoftwares from "./EmployeeSoftwares";
export default function EmployeeCertificates() {
  const [inputList, setInputList] = useState([
    { certificate: "", file_name: "" },
  ]);
  const [validated, setValidated] = useState(false);
  const [data, setData] = useState();

  // handle input change
  const handleInputChange = (e, index) => {
    if (e.target.type === "file") {
      // const { name, files } = e.target;
      const list = [...inputList];
      list[index][e.target.name] = e.target.files[0];
      list[index]["file_name"] = e.target.value;
      console.log(e.target.files[0]);
      setInputList(list);
      console.log(list);
    } else {
      const { name, value } = e.target;
      const list = [...inputList];
      list[index][name] = value;
      setInputList(list);
      console.log(list);
    }
  };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
  };

  // handle click event of the Add button
  const handleAddClick = () => {
    setInputList([...inputList, { certificate: "", file_name: "" }]);
  };

  const [certificate, setcertificate] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost/php/pms/employee/getCertificates.php")
      .then((res) => {
        setInputList(res.data);
      });
  }, []);
  const onSubmit = (e, index) => {
    // const form = e.currentTarget;
    // if (form.checkValidity() === false) {
    //   e.preventDefault();
    //   e.stopPropagation();
    // }
    //  setValidated(true);

    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("emp_id", "1");
    modalFormData.append("id", inputList[index]["id"]);
    modalFormData.append("certificate", inputList[index]["certificate"]);
    modalFormData.append(
      "certificate_file",
      inputList[index]["certificate_file"]
    );

    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(
        "http://localhost/php/pms/employee/addEmpCertificatefile.php",
        modalFormData,
        config
      )
      .then((response) => {
        // axios.post(
        //     "http://localhost/girnar_backend/api/read_customer_inquiry.php", { customer: localStorage.getItem('customer_id')})
        //     .then((res) => {
        //         set_inquiry(res.data);
        //         //console.log(inquiry);
        //     })
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="divclass">
      {inputList.map((x, i) => {
        return (
          <div className="box">
            <Form noValidate validated={validated} onSubmit={onSubmit}>
              <Row className="mb-3">
                <Form.Group
                  as={Row}
                  className="mb-3"
                  controlId="validationCustom01"
                >
                  <Form.Label column sm={2}>
                    Certificate
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="text"
                      name="certificate"
                      value={x.certificate}
                      placeholder="Enter certificate name"
                      onChange={(e) => handleInputChange(e, i)}
                    />
                    <Form.Control.Feedback type="invalid">
                      Please enter certificate name
                    </Form.Control.Feedback>
                  </Col>

                  <Form.Label column sm={2}>
                    Upload cerificate
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="file"
                      value={x.file_name}
                      onChange={(e) => handleInputChange(e, i)}
                      name="certificate_file"
                    />
                  </Col>
                  <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                </Form.Group>
              </Row>

              <div className="btn-box">
                {inputList.length !== 1 && (
                  <div className="remove-tag">
                    <a
                      className="acnhor-tag-remove"
                      onClick={() => handleRemoveClick(i)} >
                      Remove
                    </a>
                  </div>
                )}
                <Button
                  variant="success"
                  type="button"
                  onClick={(e) => onSubmit(e, i)}
                >
                  Save
                </Button>
                <br></br>
                {inputList.length - 1 === i && (
                  <div className="add-tag">
                    <a className="acnhor-tag-add" onClick={handleAddClick}>
                      Add
                    </a>
                  </div>
                )}
              </div>
            </Form>
          </div>
        );
      })}
      {/* <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div> */}
    </div>
  );
}
