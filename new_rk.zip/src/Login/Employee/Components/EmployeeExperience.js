import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
export default function EmployeeExperience() {
  const [inputList, setInputList] = useState([
    { id:"",past_experience: "", experience_from: "", experience_to: "" },
  ]);
  const [validated, setValidated] = useState(false);

  // handle input change
  const handleInputChange = (e, index) => {
    console.log(e.target);
    const { name, value } = e.target;
    const list = [...inputList];
    list[index][name] = value;
    setInputList(list);
  };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    console.log(index);
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
  };

  // handle click event of the Add button
  const handleAddClick = () => {
    setInputList([
      ...inputList,
      { past_experience: "", experience_from: "", experience_to: "" },
    ]);
  };

  const [experience, setexperience] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost/php/pms/employee/getEmployeeExperience.php")
      .then((res) => {
       
        setInputList(res.data);
      });
  }, []);

  const onSubmit = (e, index) => {
    e.preventDefault();
  
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
   
    axios
      .post(
        "http://localhost//php/pms/employee/addPastExperience.php",
        inputList,
        config
      )
      .then((response) => {
        // axios.post(
        //     "http://localhost/girnar_backend/api/read_customer_inquiry.php", { customer: localStorage.getItem('customer_id')})
        //     .then((res) => {
        //         set_inquiry(res.data);
        //         //console.log(inquiry);
        //     })
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="row col-md-12">
      {inputList.map((x, i) => {
        return (
          <div className="box">
            <Form noValidate validated={validated} onSubmit={onSubmit}>
              <Row className="mb-3">
                <Form.Group
                  as={Row}
                  className="mb-3"
                  controlId="validationCustom01"
                >
                   <Form.Control
                      type="hidden"
                      name="id"
                      
                      id="id"
                      value={x.id}
                     
                    />
                  <Form.Label for="past_experience" column sm={2}>
                    Experience
                  </Form.Label>
                  <Col sm={10}>
                    <Form.Control
                      type="text"
                      name="past_experience"
                      required
                      id="past_experience"
                      value={x.past_experience}
                      placeholder="Enter previous organization"
                      onChange={(e) => handleInputChange(e, i)}
                      aria-describedby="inputGroupPrepend"
                    />
                    <Form.Control.Feedback type="invalid">
                      Enter previous organization
                    </Form.Control.Feedback>
                  </Col>
                </Form.Group>
              </Row>

              <Row className="mb-3">
                <Form.Group
                  as={Row}
                  className="mb-3"
                  controlId="validationCustom01"
                >
                  <Form.Label
                    for="year_from"
                    column
                    sm={2}
                    style={{ paddingRight: "1px" }}
                  >
                    Past experience from
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="date"
                      value={x.experience_from}
                      name="experience_from"
                      onChange={(e) => handleInputChange(e, i)}
                      placeholder="Select date"
                    />
                  </Col>
                  <Form.Label column sm={2} for="experience_to">
                    Past experience to
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="date"
                      value={x.experience_to}
                      name="experience_to"
                      onChange={(e) => handleInputChange(e, i)}
                      placeholder="Select date"
                    />
                  </Col>
                </Form.Group>
              </Row>

              <div className="btn-box">
                {inputList.length !== 1 && (
                  <div className="remove-tag">
                    <a
                      className="acnhor-tag-remove"
                      onClick={() => handleRemoveClick(i)}
                    >
                      Remove
                    </a>
                  </div>
                )}
               
                {inputList.length - 1 === i && (
                  <div className="add-tag">
                    <a className="acnhor-tag-add" onClick={handleAddClick}>
                      Add
                    </a><br></br>

                    <Button
                  variant="success"
                  type="button"
                  onClick={(e) => onSubmit(e, i)}
                >
                  Save
                </Button>
                  </div>
                  
                )}
              </div>
            </Form>
          </div>
        );
      })}
      {/* <div style={{ marginTop: 20 }}>{JSON.stringify(inputList)}</div> */}
    </div>
  );
}
