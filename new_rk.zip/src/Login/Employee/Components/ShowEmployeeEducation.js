import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
import EmployeeCOA from "./EmployeeCOA";
import EmployeeSoftwares from "./EmployeeSoftwares";
import EmployeeCertificates from "./EmployeeCertificates";
import EmployeeExperience from "./EmployeeExperience";
import UploadResume from "./UploadResume";

import EmployeeEducation from "./EmployeeEducation";

export default function ShowEmployeeEducation() {
  const [data, setData] = useState([]);
  const [show, setShow] = useState(false);
  const [showedit, setshowedit] = useState(true);
  const [show1, setShow1] = useState(true);
  const [showcancel, setshowcancel] = useState(false);

  const editclick = (e) => {
    setShow(true);
    setshowcancel(true);
    setshowedit(false);
    setShow1(false);
  };

  const cancelclick = (e) => {
    setShow(false);
    setshowcancel(false);
    setshowedit(true);
    setShow1(true);
  };
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getEducationDetail.php", localStorage.getItem("emp_id"))
      .then((res) => {
        setData(res.data);
        console.log(1)
      });
  }, []);

  const [coa, setcoa] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        setcoa(res.data[0]);
      });
  }, []);

  const [certificate, setcertificate] = useState([]);
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getCertificates.php", localStorage.getItem("emp_id"))
      .then((res) => {
        setcertificate(res.data);
      });
  }, []);


  const [experience, setexperience] = useState([]);
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getEmployeeExperience.php", localStorage.getItem("emp_id"))
      .then((res) => {
        setexperience(res.data);
      });
  }, []);



  const [resume, setresume] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getPanAadhar.php", localStorage.getItem("emp_id"))
      .then((res) => {
        setresume(res.data[0]);
      });
  }, []);


  return (
    <div className="row col-md-11">
      <div className="col-md-3"></div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-body">
            <h6 className="name">
              Education details
              {showedit && (
                <a
                  className="acnhor-tag-edit"
                  style={{ float: "right" }}
                  onClick={editclick}
                >
                  Edit
                </a>
              )}
              {showcancel && (
                <a
                  className="acnhor-tag-edit"
                  style={{ float: "right" }}
                  onClick={cancelclick}
                >
                  Cancel
                </a>
              )}
            </h6>
            {show1 && (
              <>
                <div className="form-group row">
                  <div
                    className="form-group col-md-4"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="pan_no"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Degree name
                    </label>
                    {
                      data === undefined ? ""
                        : data.map((item) => {
                          return <div>{item.degree_name}
                            <span style={{ marginLeft: "2px" }}></span>   {item.year_from} -{item.year_to}
                          </div>;
                        })}
                  </div>

                  <div className="form-group col-md-8">
                    <label
                      for="Pan"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Degree file
                    </label>
                    <br></br>
                    {data === undefined
                      ? ""
                      : data.map((item) => {
                        return (
                          <div>
                            <a
                              href={item.degree_attachment}
                              download
                              onClick={() => {
                                // if(item.degree_attachment.split('.').pop()==='png')
                                // {
                                axios({
                                  url: `https://velocepro.in/assets/pan_aadhar6148741450737_PAN CARDKAPIL SIR.jpg `,
                                  method: "GET",
                                  responseType: "blob",
                                  mode: "no-cors",
                                }).then((res) => {
                                  const url = window.URL.createObjectURL(
                                    new Blob([res.data])
                                  );
                                  const link = document.createElement("a");
                                  link.href = url;
                                  link.setAttribute("download", "file.png");
                                  document.body.appendChild(link);
                                  link.click();
                                });
                                // }  else if(item.degree_attachment.split('.').pop()==='png')
                                // {
                                //     axios({
                                //         url:`${item.degree_attachment}`,
                                //         method:'GET',
                                //         responseType:'blob',
                                //         mode: "no-cors"
                                //     })
                                //     .then((res)=>{
                                //         const url = window.URL.createObjectURL(new Blob([res.data]));
                                //         const link = document.createElement("a")
                                //         link.classList.add("btn btn-success")
                                //         link.href=url;
                                //         link.setAttribute("download","file.txt")
                                //         document.body.appendChild(link);
                                //         link.click();
                                //     })
                                // }
                              }}
                            >
                              <i className="fa fa-download" />
                            </a>
                            {item.degree_attachment}
                          </div>
                        );
                      })}
                  </div>
                </div>

                <div className="form-group row">
                  <div
                    className="form-group col-md-6"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="pan_no"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      COA
                    </label>
                    <br></br>
                    {coa === undefined ? "" : coa.coa}
                  </div>

                  <div className="form-group col-md-6">
                    <label
                      for="Pan"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      COA file
                    </label>
                    <br></br>

                    <a
                      href={coa === undefined ? "" : coa.coa_attachment}
                      download
                    >
                      <i className="fa fa-download" />
                    </a>
                    {coa === undefined ? "" : coa.coa_attachment}
                  </div>
                </div>

                <div className="form-group row">
                  <div
                    className="form-group col-md-6"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="pan_no"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Softwares
                    </label>
                    <br></br>
                    {coa === undefined ? "" : coa.software_list}

                  </div>
                </div>

                <div className="form-group row">
                  <div
                    className="form-group col-md-6"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="pan_no"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Certificate
                    </label>
                    <br></br>
                    {certificate === undefined
                      ? ""
                      : certificate.map((item) => {
                        return <div>{item.certificate}</div>;
                      })}
                  </div>

                  <div className="form-group col-md-6">
                    <label
                      for="Pan"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Certificate file
                    </label>
                    <br></br>

                    {certificate === undefined
                      ? ""
                      : certificate.map((item) => {
                        return (
                          <div>
                            <a
                              href={item.certificate_file}
                              download

                            >
                              <i className="fa fa-download" />
                            </a>
                            {item.certificate_file}
                          </div>
                        );
                      })}
                  </div>
                </div>

                <div className="form-group row">
                  <div
                    className="form-group col-md-6"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="pan_no"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Experience
                    </label>
                    <br></br>
                    {experience === undefined
                      ? ""
                      : experience.map((item) => {
                        return (
                          <>
                            <div>{item.past_experience}</div>
                            <div>{item.experience_from}</div>
                            <div>{item.experience_to}</div>
                          </>
                        )
                      })}
                  </div>
                </div>
                <div className="form-group row">
                  <div className="form-group col-md-6">
                    <label
                      for="Pan"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Resume
                    </label>
                    <br></br>

                    <a href={resume === undefined ? "" : resume.resume} download>
                      <i className="fa fa-download" />
                    </a>
                    {resume === undefined ? "" : resume.resume}
                  </div>
                </div>
              </>
            )}

            {show && (
              <div>
                <EmployeeEducation></EmployeeEducation>
                <EmployeeCOA></EmployeeCOA>
                <EmployeeSoftwares></EmployeeSoftwares>
                <EmployeeCertificates></EmployeeCertificates>
                <EmployeeExperience></EmployeeExperience>
                <UploadResume></UploadResume>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
