import axios from "axios";
import React, { useEffect, useState } from "react";

import "./employee.css";

export default function AdditionalInformation() {
  const [data, setData] = useState();

  useEffect(() => {
    axios
      .get("http://localhost/php/pms/employee/getSupervisor.php")
      .then((res) => {
        //Storing users detail in state array object
        setData(res.data[0].primary_approver);
      //  console.log(res.data[0].primary_approver)
      });
  }, []);
  return (
    <div className="row col-md-11">
      <div className="col-md-3"></div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-body">
            <h6 className="name">Additional Information</h6>
            <div className="form-group col-md-6">
              <label for="emp_id" className="label">
                Supervisor
              </label>
              <div className="row">
                <div className="col-md-2">
                  <i className="fa fa-user-circle fa-2x "></i>
                </div>
                <div className="col-md-8">
                  <input type="text1" style={{ background: "transparent",border: "none",width:"100%"}} value={data} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
