import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import Aboutme from "./Aboutme";
import AdditionalInformation from "./AdditionalInformation";
import EmployeeContactInfo from "./EmployeeContactInfo";
import EmployeeEducation from "./EmployeeEducation";
import KYC from "./EmployeeKYC";
import IntrestOfFields from "./IntrestOfFields";
import ThingsILike from "./ThingsILike";
import axios from "axios";
import "./employee.css";
import { Modal } from "react-bootstrap";
import Webcam from "react-webcam";

// import "bootstrap/dist/css/bootstrap.css";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import { ArrowRight } from "react-bootstrap-icons";
import ShowEmployeeEducation from "./ShowEmployeeEducation";
const WebcamComponent = () => <Webcam />;

const videoConstraints = {
  width: 220,
  height: 200,
  facingMode: "user",
};
export default function AddEmployeeDetails() {
  const [data, setData] = useState();
  const [selectedFile, setSelectedFile] = useState();
  const [preview, setPreview] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {  
        setData(res.data[0]);
      });
  }, []);


 // /employee/setEmployeeFlag.php





  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [image, setImage] = useState("");
  const webcamRef = React.useRef(null);

  const capture = React.useCallback(() => {
    const imageSrc = webcamRef.current.getScreenshot();
    setImage(imageSrc);
    console.log(imageSrc);
  });

  const coaupload = (e) => {
    setSelectedFile(e.target.files[0]);

    const objectUrl = URL.createObjectURL(selectedFile);
    setPreview(objectUrl);
  };

  const saveimage = (e) => {
    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("EmployeeID", "1");
    modalFormData.append("file", selectedFile);

    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(
        "http://localhost/php/pms/employee/image/uploadimage.php",
        modalFormData,
        config
      )
      .then((response) => {
        setShow(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const savecaptureimage = (e) => {
    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("EmployeeID", "1");
    modalFormData.append("Image", image);

    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(
        "http://localhost/php/pms/employee/image/saveimage.php",
        modalFormData,
        config
      )
      .then((response) => {
        setShow(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const SaveAll = () => {

    axios
    .post(
      "http://localhost/php/pms/employee/setEmployeeFlag.php",1
    )
    .then((response) => {
     
    })
    .catch((error) => {
      console.log(error);
    });
   
  };
  return (
    <div>
      <div
        className="pull-right"
        style={{ marginBottom: "1%", marginRight: "4%", marginTop: "1rem" }}
      >
        <Button
          type="submit"
          onClick={SaveAll}
          variant="success"
          style={{ Padding: " 0.4rem 1.125rem !important" }}
        >
          Done
        </Button>
        &nbsp;
        <Button
          type="submit"
        
          variant="danger"
          style={{ Padding: " 0.4rem 1.125rem !important" }}
        >
          Log Out
        </Button>
      </div>
      <div className="row col-md-11">
        <div className="col-md-3">
          <div className="card" style={{ marginLeft: "10%" }}>
            <div className="card-body">
              <span>Upload photo</span>

              <div className="form-group" align="center">
                <form>
                  <img
                    className="myimg"
                    // src={require("./user.png")}

                    src={data === undefined ? "" : data.employee_photo}
                    onClick={handleShow}
                    style={{ cursor: "pointer" }}
                  />

                  <div className="upload-img-div">
                    <div
                      className="iupload-img"
                      id="intranet-user-profile-photo-file"
                    >
                      Upload a photo
                    </div>
                  </div>
                  {/* <Button variant="primary" onClick={handleShow}>
        Launch static backdrop modal
      </Button> */}

                  <Modal
                    show={show}
                    onHide={handleClose}
                    backdrop="static"
                    keyboard={false}
                  >
                    <Modal.Header closeButton>
                      <Modal.Title>Modal title</Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                      <Tabs
              variant="scrollable"
                        defaultActiveKey="profile"
                        id="uncontrolled-tab-example"
                        className="mb-3"
                      >
                        <Tab eventKey="home" title="Home">
                          <Form onSubmit={saveimage}>
                            <Row className="mb-3">
                              <Col sm={4}>
                                <div className="image-upload">
                                  <a
                                    style={{
                                      color: "inherit",
                                      textDecoration: "none",
                                    }}
                                  >
                                    Choose File
                                  </a>
                                  <Form.Control
                                    type="file"
                                    name="coa_attachment"
                                    className="image-input"
                                    onChange={coaupload}
                                  />
                                </div>
                              </Col>
                              <Col sm={1}>
                                <ArrowRight
                                  color="royalblue"
                                  size={20}
                                  style={{ marginTop: "2rem" }}
                                />
                              </Col>
                              <Col sm={4}>
                                {selectedFile && (
                                  <img
                                    src={preview}
                                    style={{ width: "124%" }}
                                  />
                                )}
                              </Col>
                            </Row>
                            <Button
                              variant="success"
                              type="submit"
                              onSubmit={saveimage}
                            >
                              Save
                            </Button>
                          </Form>
                        </Tab>
                        <Tab eventKey="profile" title="Profile">
                          <Form onSubmit={savecaptureimage}>
                            <div className="webcam-container">
                              <div className="webcam-img">
                                {image == "" ? (
                                  <Webcam
                                    audio={false}
                                    height={200}
                                    ref={webcamRef}
                                    screenshotFormat="image/jpeg"
                                    width={220}
                                    videoConstraints={videoConstraints}
                                  />
                                ) : (
                                  <img src={image} />
                                )}
                              </div>
                              <div>
                                {image != "" ? (
                                  <button
                                    onClick={(e) => {
                                      e.preventDefault();
                                      setImage("");
                                    }}
                                    className="webcam-btn"
                                  >
                                    Retake Image
                                  </button>
                                ) : (
                                  <button
                                    onClick={(e) => {
                                      e.preventDefault();
                                      capture();
                                    }}
                                    className="webcam-btn"
                                  >
                                    Capture
                                  </button>
                                )}
                              </div>
                            </div>
                            <Button
                              variant="success"
                              type="submit"
                              onSubmit={saveimage}
                            >
                              Save
                            </Button>
                          </Form>
                        </Tab>
                      </Tabs>
                    </Modal.Body>
                  </Modal>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-9">
          <div className="card">
            <div className="card-body">
              <h6 className="name">Basic Information</h6>
              <form>
                <div className="form-group row">
                  <div
                    className="form-group col-md-4"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="emp_firstname"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      First name
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.emp_firstname}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="emp_lastname"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Last name
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.emp_lastname}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="emptype"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Employee type
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.emptype}
                  </div>

                  <div
                    className="form-group col-md-4"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="role_id"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Employee role
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.role}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="hiring_date"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Hiring date
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.hiring_date}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="sex"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Gender
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.sex}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="dob"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Date of birth
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.dob}
                  </div>
                  <div className="form-group col-md-4">
                    <label
                      for="department"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Department
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.department_name}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="email"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Contact email
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.email}
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
      <EmployeeContactInfo></EmployeeContactInfo>
      <KYC></KYC>
      <ShowEmployeeEducation></ShowEmployeeEducation>
      <Aboutme></Aboutme>
      <ThingsILike></ThingsILike>
      <IntrestOfFields></IntrestOfFields>
      <AdditionalInformation></AdditionalInformation>
    </div>
  );
}
