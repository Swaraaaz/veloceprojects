import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from 'axios';
import createSpacing from "@material-ui/core/styles/createSpacing";

export default function EmployeeContactInfo() {
  const [validated, setValidated] = useState(false);
  // date parameter is a date object

  const [data, setData] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        // console.log(res.data[0]);
        setData(res.data[0]);
        //console.log(data);
      });
  }, []);
  const [show, setShow] = useState(false);
  const [showedit, setshowedit] = useState(true);
  const [show1, setShow1] = useState(true);
  const [showcancel, setshowcancel] = useState(false);

  const editclick= (e) => {
    setShow(true);
    setshowcancel(true);
    setshowedit(false);
    setShow1(false);
  }
  
  const cancelclick= (e) => {
    setShow(false);
    setshowcancel(false);
    setshowedit(true);
    setShow1(true);
  }

  const [insertData, setInsertData] = useState({
    emp_id: 1,
    session_role_id: 1
  
})



const handleChange = (e) => {
    setInsertData({ ...insertData, [e.target.name]: e.target.value });
}

  const addContactInfo = (event) => {
    const form = event.currentTarget;
    console.log(form.checkValidity());
    if (form.checkValidity() === false) {

      event.preventDefault();
      event.stopPropagation();
    }
        setValidated(true);
        event.preventDefault()
        console.log(insertData)
       axios.post("http://localhost/php/pms//employee/updateEmployee.php", insertData)

       setShow(false);
       setshowcancel(false);
       setshowedit(true);
       setShow1(true);
  };



  return (
<div className="row col-md-11">
      <div className="col-md-3"></div>
        <div className="col-md-9">
        
          <div className="card">
            <div className="card-body">
            <h6 className="name">Contact information
            {showedit && (
            <a  className="acnhor-tag-edit" style={{float:"right"}}  onClick={editclick}>Edit</a>
            )}
            {showcancel && (
            <a  className="acnhor-tag-edit" style={{float:"right"}}  onClick={cancelclick}>Cancel</a>
            )} 
            </h6>
         

            {show1 && (
            <div className="form-group row">
                  <div
                    className="form-group col-md-4"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="mobile"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                     Mobile
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.mobile}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="home_number"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Home number
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.home_number}
                  </div>

                  <div className="form-group col-md-4">
                    <label
                      for="pincode"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                     Pincode
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.pincode}
                  </div>

                  <div
                    className="form-group col-md-4"
                    style={{ marginBottom: "2%" }}
                  >
                    <label
                      for="role_id"
                      className="label"
                      style={{ marginBottom: "2%" }}
                    >
                      Address
                    </label>
                    <br></br>
                    {data === undefined ? "" : data.residential_address}
                  </div>

                </div>
            )}
                {show && (
              <div >
              <Form noValidate validated={validated} onSubmit={addContactInfo}>
                
                <Row className="mb-3">
                  
                  <Form.Group
                    as={Row}
                    className="mb-3"
                    controlId="validationCustom01"
                  >
                    <Form.Label column sm={2}>
                      Mobile
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        required
                        type="number"
                        name='mobile'
                        defaultValue= {data === undefined ? "" : data.mobile}
                        placeholder="Enter valid mobile number"
                        onChange={handleChange}
                      />
                       <Form.Control.Feedback type="invalid">
                      Please enter valid mobile number
                    </Form.Control.Feedback>
                    </Col>
                  
                    <Form.Label column sm={2}>
                      Home Number
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="number"
                        name="home_number"
                        id="home_number"
                        defaultValue= {data === undefined ? "" : data.home_number}
                        placeholder="Enter home number"
                        onChange={handleChange}
                      />
                    </Col>
                    <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                  </Form.Group>
                </Row>
                <Row className="mb-3">
                  <Form.Group
                    as={Row}
                    className="mb-3"
                    controlId="validationCustomUsername"
                  >
                    <Form.Label column sm={2}>
                      City
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="text"
                        name="city"
                        id="city"
                        defaultValue= {data === undefined ? "" : data.city}
                        placeholder="Enter city"
                        onChange={handleChange}
                        aria-describedby="inputGroupPrepend"
                        
                      />
                    </Col>
                   
                    <Form.Label column sm={2}>
                      Pincode
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control name="pincode"  defaultValue= {data === undefined ? "" : data.pincode}  onChange={handleChange} id="pincode" type="text" placeholder="Enter pincode"  />
                    </Col>
                  </Form.Group>
                </Row>
                <Row className="mb-3">
                  <Form.Group
                    as={Row}
                    className="mb-3"
                    controlId="exampleForm.ControlTextarea1"
                  >
                    <Form.Label column sm={2}>
                      Address
                    </Form.Label>
                    <Col sm={10}>
                      <Form.Control name="residential_address"  defaultValue= {data === undefined ? "" : data.residential_address}  onChange={handleChange} id="residential_address" placeholder="Enter address" required as="textarea" rows={1} />
                      <Form.Control.Feedback type="invalid">
                      Please enter address.
                    </Form.Control.Feedback>
                    </Col>
                   
                  </Form.Group>
                </Row>

                <Button variant="success" type="submit">Save</Button>
              </Form>
              </div>
                )}
            </div>
          </div>
        
      </div>
    </div> 
  );
}
