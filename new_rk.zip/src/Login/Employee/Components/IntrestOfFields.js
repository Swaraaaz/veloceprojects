import React, { useEffect, useState } from "react";
import ReactTagInput from "@pathofdev/react-tag-input";
import "@pathofdev/react-tag-input/build/index.css";
import { Col, Row, Form , Button } from "react-bootstrap";
import "./employee.css";
import axios from "axios";
export default function IntrestOfFields() {
  const [tags, setTags] = React.useState([])
  
  const [validated, setValidated] = useState(false);

  const onSubmit = (e) => {
    const form = e.currentTarget;
  
    if (tags.length === 0) {
      alert("enter atleast one tag");
      e.preventDefault();
      e.stopPropagation();
     
    }

    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("emp_id", "1");
    modalFormData.append("interest_of_fields", tags);
   
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(
        "http://localhost//php/pms/employee/addIntrestofField.php",
        modalFormData,
        config
      )
      .then((response) => {
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        console.log(res.data[0]);
        //setData(res.data[0]);
        //console.log(data);
      });
  }, []);

    return (
      
        <Form noValidate validated={validated} onSubmit={onSubmit}>
        <div className="row col-md-11">
        <div className="col-md-3"></div>
        <div className="col-md-9">
          <div className="card">
            <div className="card-body">
            <h6 className="name">Intrest of fields</h6>
        <ReactTagInput 
        tags={tags} 
        placeholder="Enter fields you would like to work(Type and press enter)"
        maxTags={10}
        editable={true}
        required
        readOnly={false}
        removeOnBackspace={true}
        onChange={(newTags) => setTags(newTags)}
        
      />
       <Button variant="success" type="submit">
              Save
            </Button>
      </div>
      </div>
      </div>
      </div>
      </Form>
    )
}
