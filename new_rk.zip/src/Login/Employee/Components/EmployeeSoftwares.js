
import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import ReactDOM from "react-dom";
import axios from "axios";
import ReactTagInput from "@pathofdev/react-tag-input";
import "@pathofdev/react-tag-input/build/index.css";

import "./employee.css";

export default function EmployeeSoftwares() {
    const [tags, setTags] = React.useState([""])

    const onSubmit = (e) => {
      const form = e.currentTarget;
      if (form.checkValidity() === false) {
        e.preventDefault();
        e.stopPropagation();
      }

      e.preventDefault();
      const modalFormData = new FormData();
      modalFormData.append("emp_id", "1");
      modalFormData.append("tags", tags);
     
      const config = {
        headers: { "content-type": "multipart/form-data" },
      };
      axios
        .post(
          "http://localhost//php/pms/employee/addEmployeeSoftware.php",
          modalFormData,
          config
        )
        .then((response) => {
        })
        .catch((error) => {
          console.log(error);
        });
    };

    return (

       <div>
  <div className="divclass" >
<Form onSubmit={onSubmit}>
        <Row className="mb-3">
          <Form.Group as={Row} className="mb-3" controlId="validationCustom01">
            <Form.Label row sm={2}>
             Softwares
            </Form.Label>
            <Col sm={12}>
        <ReactTagInput 
        tags={tags} 
        placeholder="Type and press enter"
        maxTags={10}
        editable={true}
        readOnly={false}
        removeOnBackspace={true}
        onChange={(newTags) => setTags(newTags)}
        
      />
      </Col>
      </Form.Group>
      </Row>
      <Button variant="success" type="submit">
          Save
        </Button>
      </Form>
      </div>
      </div>
    
    )
}
