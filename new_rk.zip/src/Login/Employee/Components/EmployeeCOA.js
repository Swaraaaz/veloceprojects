import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
import { saveAs } from "file-saver";
import UrlImageDownloader from "react-url-image-downloader";

export default function EmployeeCOA() {

  const [validated, setValidated] = useState(false);
  // date parameter is a date object
  const [emp_id, setEmpId] = useState({});
  const [coa, set_coa] = useState();
  const [coa_attachment, set_coa_file] = useState();
 
  const coachange = (e) => {
    console.log(e.target.value);
    set_coa(e.target.value);
  };
  const coaupload = (e) => {
    if(e.target.files.length === 1){
    set_coa_file(e.target.files[0]);
    }else{
      for (const key in e.target.files) {
         set_coa_file(key)
          
      }
    }
  };

  
  const [coanumber, setcoa] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        setcoa(res.data[0]);
       // alert(coanumber.coa);
        // console.log(coanumber.coa_attachment);
      });
  }, []);

  const uploadkyc = (e) => {
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.preventDefault();
      e.stopPropagation();
    }
    setValidated(true);

    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("EmployeeID", "1");
    modalFormData.append("coa", coa);
    modalFormData.append("coa_attachment", coa_attachment);

    const config = {
      headers: { "content-type": "multipart/form-data" },
    };

    
    axios
      .post(
        "http://localhost/php/pms/employee/updateCOA.php",
        modalFormData,
        config
      )
      .then((response) => {
        // axios.post(
        //     "http://localhost/girnar_backend/api/read_customer_inquiry.php", { customer: localStorage.getItem('customer_id')})
        //     .then((res) => {
        //         set_inquiry(res.data);
        //         //console.log(inquiry);
        //     })
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="divclass" >
        
         <div className="box">
      <Form noValidate validated={validated} onSubmit={uploadkyc}>
        <Row className="mb-3">
          <Form.Group as={Row} className="mb-3" controlId="validationCustom01">
            <Form.Label column sm={2}>
              COA Number
            </Form.Label>
            <Col sm={4}>
              <Form.Control
                type="text"
                name="coa"
                id="coa"
                defaultValue={coanumber === undefined ? "" :coanumber.coa}
                placeholder="Enter valid coa number"
                onChange={coachange}
              />
            </Col>

            <Form.Label column sm={2}>
              Upload COA
            </Form.Label>
            <Col sm={4}>
              <Form.Control
                type="file"
                onChange={coaupload}
                name="coa_attachment"
              />
               <a
                      href={coanumber === undefined ? "" : coanumber.coa_attachment}
                      download
                    >
                      <i className="fa fa-download" />
                    </a>
                    {coanumber === undefined ? "" : coanumber.coa_attachment}
            </Col>
           
            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
          </Form.Group>
        </Row>

        <Button variant="success" type="submit">
          Save
        </Button>
        <div></div>

      </Form>
      </div>
    </div>
  );
}
