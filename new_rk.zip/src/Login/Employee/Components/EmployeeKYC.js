import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
export default function KYC() {
  const [validated, setValidated] = useState(false);
  // date parameter is a date object

  const [emp_id, setEmpId] = useState({});

  const [data, setData] = useState();
  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getAllEmpByID.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        console.log(res.data[0]);
        setData(res.data[0]);
        //console.log(data);
      });
  }, []);
  const [show, setShow] = useState(false);
  const [showedit, setshowedit] = useState(true);
  const [show1, setShow1] = useState(true);
  const [showcancel, setshowcancel] = useState(false);

  const editclick = (e) => {
    setShow(true);
    setshowcancel(true);
    setshowedit(false);
    setShow1(false);
  };

  const cancelclick = (e) => {
    setShow(false);
    setshowcancel(false);
    setshowedit(true);
    setShow1(true);
  };

  const [pan_no, set_pan] = useState();
  const [Pan, set_upload_pan] = useState();
  const [aadhar_no, set_aadhar] = useState();
  const [Aadhar, set_upload_aadhar] = useState();
  const panchange = (e) => {
    set_pan(e.target.value);
  };
  const panupload = (e) => {
    console.log(e.target.files[0]);
    set_upload_pan(e.target.files[0]);
  };

  const aadharchange = (e) => {
    set_aadhar(e.target.value);
  };
  const aadharupload = (e) => {
    set_upload_aadhar(e.target.files[0]);
  };
  const uploadkyc = (e) => {
    const form = e.currentTarget;

    if (form.checkValidity() === false) {
      
      e.preventDefault();
      e.stopPropagation();
      setValidated(true);
    } else {
      e.preventDefault();
      const modalFormData = new FormData();
      modalFormData.append("emp_id", "1");
      modalFormData.append("pan_no", pan_no);
      modalFormData.append("Pan", Pan);
      modalFormData.append("aadhar_no", aadhar_no);
      modalFormData.append("Aadhar", Aadhar);

      const config = {
        headers: { "content-type": "multipart/form-data" },
      };
      axios
        .post(
          "http://localhost/php/pms/employee/uploadAadharPan.php",
          modalFormData,
          config
        )
        .then((response) => {
          setShow(false);
          setshowcancel(false);
          setshowedit(true);
          setShow1(true);
        })
        .catch((error) => {
          console.log(error);
        });
    }
  };
  return (
    <div className="row col-md-11">
      <div className="col-md-3"></div>
      <div className="col-md-9">
        <div className="card">
          <div className="card-body">
            <h6 className="name">
              KYC Details
              {showedit && (
                <a
                  className="acnhor-tag-edit"
                  style={{ float: "right" }}
                  onClick={editclick}
                >
                  Edit
                </a>
              )}
              {showcancel && (
                <a
                  className="acnhor-tag-edit"
                  style={{ float: "right" }}
                  onClick={cancelclick}
                >
                  Cancel
                </a>
              )}
            </h6>

            {show1 && (
              <div className="form-group row">
                <div
                  className="form-group col-md-4"
                  style={{ marginBottom: "2%" }}
                >
                  <label
                    for="pan_no"
                    className="label"
                    style={{ marginBottom: "2%" }}
                  >
                    Pan number
                  </label>
                  <br></br>
                  {data === undefined ? "" : data.pan_no}
                </div>

                <div className="form-group col-md-4">
                  <label
                    for="Pan"
                    className="label"
                    style={{ marginBottom: "2%" }}
                  >
                    Pan file
                  </label>
                  <br></br>

                  <a href={data === undefined ? "" : data.pan_no} download>
                    <i className="fa fa-download" />
                  </a>
                  {data === undefined ? "" : data.pan_photo}
                </div>

                <div className="form-group col-md-4">
                  <label
                    for="aadhar_no"
                    className="label"
                    style={{ marginBottom: "2%" }}
                  >
                    Aadhar number
                  </label>
                  <br></br>
                  {data === undefined ? "" : data.aadhar_no}
                </div>

                <div className="form-group col-md-4" style={{ marginBottom: "2%" }}>
                  <label
                    for="role_id"
                    className="label"
                    style={{ marginBottom: "2%" }}
                  >
                    Aadhar
                  </label>
                  <br></br>
                  {data === undefined ? "" : data.aadhar_photo}
                </div>
              </div>
            )}
            {show && (
              <Form noValidate validated={validated} onSubmit={uploadkyc}>
                <Row className="mb-3">
                  <Form.Group
                    as={Row}
                    className="mb-3"
                    controlId="validationCustom01"
                  >
                    <Form.Label column sm={2}>
                      Pan Number
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="text"
                        name="pan_no"
                        id="pan_no"
                        defaultValue={data === undefined ? "" : data.pan_no}
                        placeholder="Enter valid pan number"
                        onChange={panchange}
                      />
                    </Col>

                    <Form.Label column sm={2}>
                      Pan Number
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="file"
                        onChange={panupload}
                        name="pan"
                      />
                    </Col>
                    <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                  </Form.Group>
                </Row>
                <Row className="mb-3">
                  <Form.Group
                    as={Row}
                    className="mb-3"
                    controlId="validationCustomUsername"
                  >
                    <Form.Label column sm={2}>
                      Aadhar Number
                    </Form.Label>
                    <Col sm={4}>
                      <Form.Control
                        type="text"
                        name="aadhar_no"
                        required
                        id="aadhar_no"
                        defaultValue={data === undefined ? "" : data.aadhar_no}
                        placeholder="Enter aadhar"
                        onChange={aadharchange}
                        aria-describedby="inputGroupPrepend"
                      />
                      <Form.Control.Feedback type="invalid">
                        Please enter valid pan number
                      </Form.Control.Feedback>
                    </Col>

                    <Form.Label column sm={2}>
                      Upload Aadhar
                    </Form.Label>
                    <Col sm={4}>
                 
                    {/* defaultValue={data === undefined ? "" : data.aadhar_photo} */}
                      <Form.Control
                        type="file"
                        reaquired
                        onChange={aadharupload}
                        required
                        name="aadhar"
                      />
                      
                      <Form.Control.Feedback type="invalid">
                        Please enter valid pan number
                      </Form.Control.Feedback>
                    </Col>
                  </Form.Group>
                </Row>

                <Button variant="success" type="submit">
                  Save
                </Button>
              </Form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
