import React, { useEffect, useState } from "react";
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import axios from "axios";
import EmployeeCOA from "./EmployeeCOA";
import EmployeeSoftwares from "./EmployeeSoftwares";
import EmployeeCertificates from "./EmployeeCertificates";
import EmployeeExperience from "./EmployeeExperience";
import UploadResume from "./UploadResume";
export default function EmployeeEducation() {
  const [inputList, setInputList] = useState([
    { id: "", degree: "", degree_attachment_name: "", year_from: "", year_to: "" },
  ]);
  const [validated, setValidated] = useState(false);
  const [data, setData] = useState();

  // handle input change
  const handleInputChange = (e, index) => {
    if (e.target.type === "file") {
      // const { name, files } = e.target;
      const list = [...inputList];
      list[index][e.target.name] = e.target.files[0];
      list[index]["degree_attachment_name"] = e.target.value;
      console.log(e.target.files[0]);
      setInputList(list);
      console.log(list);
    } else {
      const { name, value } = e.target;
      const list = [...inputList];
      list[index][name] = value;
      setInputList(list);
      console.log(list);
    }
  };

  // const uploadDegree = (e, index) => {
  //   //let images = [];
  //   const list = [...images];
  //   list[index] = e.target.files[0];
  //   setimages(list);

  //   // if (e.target.files && e.target.files[0]) {
  //   //   var filesAmount = e.target.files.length;
  //   //   for (let i = 0; i < filesAmount; i++) {

  //   //    // setFileArray.push(e.target.result
  //   //    setFileArray(fileArray => fileArray.concat(e.target.result))

  //   //   }
  //   // }
  //   console.log(setimages);
  // };

  // handle click event of the Remove button
  const handleRemoveClick = (index) => {
    console.log(index);
    const list = [...inputList];
    list.splice(index, 1);
    setInputList(list);
  };

  // handle click event of the Add button
  const handleAddClick = () => {
    setInputList([
      ...inputList,
      { degree: "", degree_attachment_name: "", year_from: "", year_to: "" },
    ]);
  };

  //   const onSubmit = (e) => {
  //     e.preventDefault();
  //     console.log("refresh prevented");
  //   };

  useEffect(() => {
    axios
      .get("http://localhost/php/pms/employee/getdegreename.php")
      .then((res) => {
        //Storing users detail in state array object
        console.log(res.data);
        setData(res.data);
      });
  }, []);

  useEffect(() => {
    axios
      .post("http://localhost/php/pms/employee/getEducationDetail.php", localStorage.getItem("emp_id"))
      .then((res) => {
        //Storing users detail in state array object
        console.log(res.data)
        setInputList(res.data)
      });
  }, []);




  //   const onSubmit = (e) => {
  //     e.preventDefault();
  //   };

  const onSubmit = (e, index) => {
    // const form = e.currentTarget;
    // if (form.checkValidity() === false) {
    //   e.preventDefault();
    //   e.stopPropagation();
    // }
    //  setValidated(true);
    console.log(index);
    console.log(inputList[index]["degree"]);
    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("emp_id", "1");
    modalFormData.append("id", inputList[index]["id"]);
    modalFormData.append("degree", inputList[index]["degree"]);
    modalFormData.append(
      "degree_attachment",
      inputList[index]["degree_attachment"]
    );
    modalFormData.append("year_from", inputList[index]["year_from"]);
    modalFormData.append("year_to", inputList[index]["year_to"]);

    const config = {
      headers: { "content-type": "multipart/form-data" },
    };
    axios
      .post(
        "http://localhost/php/pms/employee/insertEmpEducation.php",
        modalFormData,
        config
      )
      .then((response) => {
        // axios.post(
        //     "http://localhost/girnar_backend/api/read_customer_inquiry.php", { customer: localStorage.getItem('customer_id')})
        //     .then((res) => {
        //         set_inquiry(res.data);
        //         //console.log(inquiry);
        //     })
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="row col-md-12">
      {inputList ? inputList.map((x, i) => {
        // {inputList.map((x, i) => {
        return (

          <div className="box">
            <Form noValidate validated={validated} onSubmit={onSubmit}>
              <Row className="mb-3">
                <Form.Group
                  as={Row}
                  className="mb-3"
                  controlId="validationCustom01"
                >
                  <Form.Label for="degree" column sm={2}>
                    Degree/Diploma
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      onChange={(e) => handleInputChange(e, i)}
                      required
                      as="select"
                      value={x.degree}
                      name="degree"
                      id="degree"
                      custom
                    >
                      <option value="">Select degree</option>
                      {
                        data
                          ? data.map((item) => {
                            return (
                              <option key={item.degree} value={item.degree}>

                                {item.degree_name}
                              </option>
                            );
                          })
                          : ""}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      Please select degree
                    </Form.Control.Feedback>
                  </Col>

                  <Form.Label for="degree_attachment" column sm={2}>
                    Upload degree
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="file"
                      onChange={(e) => handleInputChange(e, i)}
                      // onChange={(e) => uploadDegree(e, i)}
                      name="degree_attachment"
                      value={x.degree_attachment_name}
                    />
                  </Col>
                  <Form.Control.Feedback>
                    Looks good!
                  </Form.Control.Feedback>
                </Form.Group>
              </Row>

              <Row className="mb-3">
                <Form.Group
                  as={Row}
                  className="mb-3"
                  controlId="validationCustom01"
                >
                  <Form.Label for="year_from" column sm={2}>
                    Year From
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="text"
                      id="year_from"
                      name="year_from"
                      value={x.year_from}
                      placeholder="Enter degree start year"
                      onChange={(e) => handleInputChange(e, i)}
                    />
                  </Col>
                  <Form.Control
                    type="hidden"
                    id="id"
                    name="id"
                    value={x.id}
                    onChange={(e) => handleInputChange(e, i)}
                  />
                  <Form.Label column sm={2} for="year_to">
                    Year To
                  </Form.Label>
                  <Col sm={4}>
                    <Form.Control
                      type="text"
                      name="year_to"
                      id="year_to"
                      value={x.year_to}
                      placeholder="Enter degree end year"
                      onChange={(e) => handleInputChange(e, i)}
                    />
                  </Col>
                </Form.Group>
              </Row>

              <div className="btn-box">
                {inputList.length !== 1 && (
                  <div className="remove-tag">
                    <a
                      className="acnhor-tag-remove"
                      onClick={() => handleRemoveClick(i)}
                    >
                      Remove
                    </a>
                  </div>
                )}
                <Button
                  variant="success"
                  type="button"
                  onClick={(e) => onSubmit(e, i)}
                >
                  Save
                </Button>
                <br></br>
                {inputList.length - 1 === i && (
                  <div className="add-tag">
                    <a className="acnhor-tag-add" onClick={handleAddClick}>
                      Add
                    </a>
                  </div>
                )}
              </div>
            </Form>
          </div>
        );
      }) : []}

    </div>

  );
}
