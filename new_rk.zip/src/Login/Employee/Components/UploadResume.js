import React, { useState,useEffect } from "react";
import { Col, Row, Form , Button } from "react-bootstrap";
import axios from "axios";
export default function UploadResume() {
  const [validated, setValidated] = useState(false);
  // date parameter is a date object

  const [resume, set_resume] = useState();

  const resumeupload = (e) => {
    set_resume(e.target.files[0]);
  };

  
  const [resumefile, setresume] = useState();

  useEffect(() => {
    axios
      .get("http://localhost/php/pms/employee/getPanAadhar.php")
      .then((res) => {
        setresume(res.data[0]);
      });
  }, []);
  const uploadresume = (e) => {
    const form = e.currentTarget;
    if (form.checkValidity() === false) {
      e.preventDefault();
      e.stopPropagation();
    }
    setValidated(true);

    e.preventDefault();
    const modalFormData = new FormData();
    modalFormData.append("EmployeeID", "1");
    modalFormData.append("resume", resume);
    const config = {
      headers: { "content-type": "multipart/form-data" },
    };

    
    axios
      .post(
        "http://localhost//php/pms/employee/image/uploadResume.php",
        modalFormData,
        config
      )
      .then((response) => {
        // axios.post(
        //     "http://localhost/girnar_backend/api/read_customer_inquiry.php", { customer: localStorage.getItem('customer_id')})
        //     .then((res) => {
        //         set_inquiry(res.data);
        //         //console.log(inquiry);
        //     })
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="divclass">
      <Form noValidate validated={validated} onSubmit={uploadresume}>
        <Row className="mb-3">
          <Form.Group as={Row} className="mb-3" controlId="validationCustom01">
          <Form.Label column sm={2}>
                    Upload resume
                  </Form.Label>
                  <Col sm={8}>
                    <Form.Control
                      type="file"
                      reaquired
                      onChange={resumeupload}
                      required
                      name="resume"
                    />
                     <a href={resumefile === undefined ? "" : resumefile.resume} download>
                      <i className="fa fa-download" />
                    </a>
                    {resumefile === undefined ? "" : resumefile.resume}
                    <Form.Control.Feedback type="invalid">
                      Please attach resume
                    </Form.Control.Feedback>
                  </Col>
                  <Col sm={2}>
            <Button variant="success" type="submit">
              Save
            </Button>
            </Col>
          </Form.Group>
        </Row>
      </Form>
    </div>
  );
}
