import React, { useEffect } from 'react'
import './login.css'
import logo from './logo.png'
import './input.css'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useState } from 'react'
import { useHistory } from 'react-router-dom'

export default function Login() {
    // const [data, setData] = useState([]);
    const [insertData, setInsertData] = useState({
        email: '',
        password: '',
        cpassword: ''
    });

    const [activeFlag, setActiveFlag] = useState()

    useEffect(() => {
        localStorage.removeItem("authenticated")
        localStorage.removeItem("emp_id")
        localStorage.removeItem("role_id")
        localStorage.removeItem("tierlevel")
        localStorage.removeItem("role")
        localStorage.removeItem("active_flag")
        localStorage.removeItem("navRole")
    }, [])

    const history = useHistory()

    const updatePass = (e) => {
        e.preventDefault()
        history.push('/add_employee_detail')
    }
    const submit = (e) => {
        e.preventDefault()
        // alert("Error")
        console.log(activeFlag[0].active_flag)
        if (activeFlag[0].active_flag === "N") {
            if (insertData.cpassword === insertData.password) {
                axios.post("http://localhost/php/pms/auth/resetpassword.php", insertData).then((res) => {
                    axios.post("http://localhost/php/pms/auth/signin.php", insertData)
                        .then((resp) => {
                            console.log("success")
                            console.log(resp.data)
                            if (resp.data[0]) {
                                localStorage.setItem("authenticated", true)
                                localStorage.setItem("emp_id", resp.data[0].emp_id)
                                localStorage.setItem("role_id", resp.data[0].role_id)
                                localStorage.setItem("tierlevel", resp.data[0].tierlevel)
                                console.log(resp.data[0].role)
                                localStorage.setItem("role", resp.data[0].role)
                                localStorage.setItem("name", resp.data[0].emp_firstname + " " + resp.data[0].emp_lastname)
                                console.log(resp.data[0].active_flag)
                                localStorage.setItem("active_flag", resp.data[0].active_flag)

                                const obj = new Date();
                                localStorage.seconds = obj.getHours() * 60 * 60 + obj.getMinutes() * 60 + obj.getSeconds()

                                if (localStorage.getItem("authenticated") === 'true') {
                                    let tierlevel = localStorage.getItem("tierlevel")
                                    if (tierlevel === '1' || tierlevel === '2') {
                                        localStorage.setItem("navRole", "super")
                                        history.push('/add_employee_detail')
                                    } else if (tierlevel === '3') {
                                        localStorage.setItem("navRole", "principalArch")
                                        history.push('/add_employee_detail')
                                    } else if (tierlevel === '4') {
                                        if (localStorage.getItem("role") === "Coordinator") {
                                            localStorage.setItem("navRole", "coordinator")
                                            history.push('/add_employee_detail')
                                        } else {
                                            localStorage.setItem("navRole", "otherEmp")
                                            history.push('/add_employee_detail')
                                        }
                                    } else {
                                        localStorage.setItem("navRole", "")
                                    }
                                } else {
                                    localStorage.setItem("active_flag", "")
                                }
                                // history.push('/')
                            } else {
                                alert("Wrong Login Creds")
                            }
                        })
                })
            }
            else
                alert("Password and Confirm Password are not matching")
            history.push('/add_employee_detail')
        }
        else {

            axios.post("http://localhost/php/pms/auth/signin.php", insertData)
                .then((resp) => {
                    console.log("success")
                    console.log(resp.data)
                        if (resp.data[0]) {
                            // axios.get("http://localhost/php/new/tasks/updateProjectTask.php")
                            localStorage.setItem("authenticated", true)
                            localStorage.setItem("emp_id", resp.data[0].emp_id)
                            localStorage.setItem("role_id", resp.data[0].role_id)
                            localStorage.setItem("tierlevel", resp.data[0].tierlevel)
                            console.log(resp.data[0].role)
                            localStorage.setItem("role", resp.data[0].role)
                            localStorage.setItem("name", resp.data[0].emp_firstname + " " + resp.data[0].emp_lastname)
                            console.log(resp.data[0].active_flag)
                            localStorage.setItem("active_flag", resp.data[0].active_flag)

                            const obj = new Date();
                            localStorage.seconds = obj.getHours() * 60 * 60 + obj.getMinutes() * 60 + obj.getSeconds()

                            console.log("Demo")
                            if (localStorage.getItem("authenticated") === 'true') {
                                let tierlevel = localStorage.getItem("tierlevel")
                                if (tierlevel === '1' || tierlevel === '2') {
                                    localStorage.setItem("navRole", "super")
                                    history.push('/Dashboard')
                                } else if (tierlevel === '3') {
                                    localStorage.setItem("navRole", "principalArch")
                                    history.push('/Dashboard')
                                } else if (tierlevel === '4') {
                                    if (localStorage.getItem("role") === "Coordinator") {
                                        localStorage.setItem("navRole", "coordinator")
                                        history.push('/Tasks')
                                    } else {
                                        localStorage.setItem("navRole", "otherEmp")
                                        history.push('/Dashboard')
                                    }
                                } else {
                                    localStorage.setItem("navRole", "")
                                }
                            } else {
                                localStorage.setItem("active_flag", "")
                            }
                            // history.push('/')
                        } else {
                            alert("Wrong Login Creds")
                        }
                })
        }
    }

    // let x = localStorage.getItem("emp_id") + localStorage.getItem("role_id") + localStorage.getItem("tierlevel") + localStorage.getItem("role") + localStorage.getItem("active_flag");
    // console.log(localStorage.getItem("authenticated"), x)

    const handleChange = (e) => {
        setInsertData({ ...insertData, [e.target.name]: e.target.value });
    }

    const validate = (e) => {
        handleChange(e)
        axios.post("http://localhost/php/pms/auth/validateEmail.php", e.target.value).then((resp) => {
            // setData(resp.data)
            buttonVisbility(resp.data)
            if (resp.data.length !== 0)
                localStorage.setItem("emp_id", resp.data[0].emp_id)
            console.log(resp.data)
            setActiveFlag(resp.data)
        })
    }

    const buttonVisbility = (data) => {
        const obj1 = document.getElementsByName('login');
        const obj2 = document.getElementsByName('confirm_password');
        const obj3 = document.getElementsByName('cpassword');
        // const obj4 = document.getElementsByName('confirm_password');
        console.log(data[0])
        if (data[0]) {
            if (data[0].password === '') {
                obj2[0].style.display = 'block'
                // obj1[0].style.display = 'none'
                // obj3[0].value = "";
                // insertData.password = ""
                obj3[0].required = true;
                alert(0)
            }

        } else {
            obj2[0].style.display = 'none'
            obj1[0].style.display = 'block'
            obj3[0].disabled = false;
        }
    }

    // console.log(data)
    return (
        <div className="login-wrapper">
            <form className="form" method='post' onSubmit={submit}>
                <img src={logo} alt="logo" />
                <h3>SIGN IN</h3>
                <div className="omrs-input-group">
                    <label className="omrs-input-underlined">
                        <input
                            type="text"
                            name='email'
                            id="email"
                            value={insertData.email}
                            onChange={validate}
                            required />
                        <span className="omrs-input-label">Username</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>

                </div>
                <div className="omrs-input-group">
                    <label className="omrs-input-underlined">
                        <input
                            type="password"
                            name='password'
                            onChange={handleChange}
                            value={insertData.password}
                            required />
                        <span className="omrs-input-label">Password</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>
                </div>
                <div className="omrs-input-group" name='confirm_password' style={{ display: 'none' }}>
                    <label className="omrs-input-underlined">
                        <input
                            type="password"
                            name='cpassword'
                            onChange={handleChange}
                            value={insertData.cpassword}
                            // required 
                            />
                        <span className="omrs-input-label">Confirm Password</span>
                        <span className="omrs-input-helper">Helper Text</span>
                    </label>
                </div>
                <div className="row">
                    <div className="d-flex justify-content-between">
                        <p></p>
                        <input type="submit" value="Login" name="login" className="submit-btn" />
                        {/* <input type="button" value="Confirm Password" name="confirm_password" className="submit-btn" style={{ display: 'none' }} onClick={updatePass} /> */}
                        <p></p>
                    </div>
                    <div className="d-flex justify-content-between mt-3">
                        <p></p>
                        <Link className="fogotpassword" to='/Reset_Password'>Forgot Password?</Link>
                        <p></p>
                    </div>
                </div>
            </form>
        </div>
    );
}
