import React, { useState } from 'react'
import { Redirect, useHistory } from 'react-router';
import './Admin.css'
import MainRoutes from './Components/MainRoutes';
import Navb from './Components/Navb';
import Notification from './Components/Notification';

export default function Admin() {
  const navRole = localStorage.getItem("navRole") //super, principalArch, coordinator, otherEmp
  const [show, setShow] = useState(false);
  const history = useHistory()
  const menuItem = [
    {
      srno: 1, name: "Dashboard", link: "/Dashboard", class: "bx bxs-dashboard nav_icon", child: []
    },
    {
      srno: 2, name: "Projects", link: "/Projects", class: "bx bx-grid-alt nav_icon", child: [],
    },
    {
      srno: 3, name: "Tasks", link: "/Tasks", class: "bx bx-task nav_icon", child: [],
    },
    {
      srno: 4, name: "Reports", link: "/Reports", class: "bx bxs-report nav_icon", child: [],
    },
    {
      srno: 5, name: "Employee", link: "/Employee", class: "bx bx-user nav_icon", child: [],
    },
  ]

  const PrincipleArchItems = [
    {
      srno: 1, name: "Dashboard", link: "/Dashboard", class: "bx bxs-dashboard nav_icon", child: []
    },
    {
      srno: 2, name: "Projects", link: "/Projects", class: "bx bx-grid-alt nav_icon", child: [],
    },
    {
      srno: 3, name: "Tasks", link: "/Tasks", class: "bx bx-task nav_icon", child: [],
    },
  ]

  const CoordinatorItems = [
  
    {
      srno: 2, name: "Tasks", link: "/Tasks", class: "bx bx-task nav_icon", child: [],
    },
    {
      srno: 1, name: "My Tasks", link: "/MyTasks", class: "bx bxs-dashboard nav_icon", child: []
    },
  ]

  const OtherEmp = [
    {
      srno: 1, name: "Dashboard", link: "/Dashboard", class: "bx bxs-dashboard nav_icon", child: []
    },
    {
      srno: 2, name: "Tasks", link: "/Tasks", class: "bx bx-task nav_icon", child: [],
    },
  ]

  if (window.location.pathname === "/Task_Dashboard") {
    localStorage.setItem("projectSelectedFlag", false)
    // localStorage.setItem("projectSelected", "notSelected")

    console.log(1, localStorage.getItem("projectSelected"))
  }

  if (window.location.pathname === "/") {
    if (navRole === undefined || navRole === null) {
      history.push('/Login')
    } else if (navRole === "super") {
      history.push('/Dashboard')
    }
  }

  const handleClose = (e) => {
    e.preventDefault()
    setShow(false)
  }

  console.log(localStorage.getItem("emp_id"), localStorage.getItem("role_id"), localStorage.getItem("tierlevel"), localStorage.getItem("role"), localStorage.getItem("active_flag"))

  return (

    <div>
      {
        navRole === "super" ? <Navb menuItem={menuItem} role={navRole} setShow={setShow} /> :
          navRole === "principalArch" ? <Navb menuItem={PrincipleArchItems} role={navRole} setShow={setShow} /> :
            navRole === "coordinator" ? <Navb menuItem={CoordinatorItems} role={navRole} setShow={setShow} /> :
              navRole === "otherEmp" ? <Navb menuItem={OtherEmp} role={navRole} setShow={setShow} /> :
                navRole === "init" ? <Navb menuItem={OtherEmp} role={navRole} setShow={setShow} /> : <Redirect to="/Login" />
      }

      {/* <Navb menuItem={menuItem} /> */}
      <MainRoutes />
      {
        show ? <Notification show={show} handleClose={handleClose} /> : <></>
      }
    </div>
  );
}

