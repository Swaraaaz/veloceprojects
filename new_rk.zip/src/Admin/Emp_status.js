import React,{ useEffect, useState } from 'react';
import { PieChart, Pie} from 'recharts';
import MaterialTable from 'material-table';
import tableIcons from "./MaterialTableIcons";
import axios from 'axios';
import { useHistory,useLocation } from 'react-router';
import Moment from 'moment';
import high from '../img/high.png'
import Moderate from '../img/Moderate.png'
import low from '../img/low.png'


  
const Emp_status = () => {

const location=useLocation();



console.log("Emp id",window.location.pathname.split("/").pop())

console.log("New method of loc",location.state.emp_id);

  const [dashEmpId,setDashEmpId]=useState()
  useEffect(()=>{
    
    setDashEmpId(parseInt(window.location.pathname.split("/").pop()))
    
  },[])



    const history = useHistory()

    const viewHandle = (e, row) => {
        e.preventDefault()
        let state0 = 0
        if (row.state_name === "Approved") {
          state0 = "6"
        } else if (row.state_name === "Closed Approved") {
          state0 = "4"
        } else if (row.state_name === "New") {
          state0 = "0"
        } else if (row.state_name === "In Progress") {
          state0 = "1"
        } else if (row.state_name === "Closed Rejected") {
          state0 = "5"
        } else if (row.state_name === " Complete") {
          state0 = "2"
        } else if (row.state_name === "Incomplete") {
          state0 = "3"
        }
        localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
        localStorage.setItem("taskState", "view")
        history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
      }

    const renderCustomizedLabel = ({
        x, y, name
      }) => {
        return (
          <text x={x} y={y} fill="black" textAnchor="end" dominantBaseline="central">
            {name}
          </text>
        );
      };
// Sample datat


const [row, setRow] = useState([])
useEffect(() => {
  axios
    .post("http://localhost/php/new/tasks/getEmpAllTasks.php",{emp_id:location.state.emp_id})
    .then((resp) => {
      setRow(resp.data)
      console.log(resp.data)
    })
}, [])

const [taskCount,setTaskCount]=useState();
useEffect(()=>{
  console.log("Hello")
  axios
    .post("http://localhost/php/new/tasks/getEmpTaskCounter.php",{emp_id:location.state.emp_id})
    .then((resp) => {
      setTaskCount(resp.data[0])
      console.log("Hello I am here counter",resp.data[0])
    })
},[])

const column1 = [
    // {showTitle:"false"},
    { title: "Task name",
    field: "task_title",
    align: "jusify", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' },
    render: (params) => {
        return (
          <div className="task_title" onClick={(e) => viewHandle(e, params)}>
            {params.task_title}
          </div>
        );
      }
},

    { title: "Project Name ",
    field: "project_name",
    align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' } },

    { title: "Due Date",
    field: "due_date",
    align: "center",headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'black' },
    render:(params)=>{
        return(
          <div>
              {Moment(params.due_date).format('DD-MM-YYYY') }
          </div>
        )
      }  
},

    { title: "Priority",
    field: "priority",
    align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' },
    render: (params) => {
        return (
          <div className="priority">
            {
              params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
                params.priority === "High" ? <img src={high} alt="High" /> :
                  params.priority === "Low" ? <img src={low} alt="Low" /> :
                    <></>
            }
          </div>
        );
      }
},

{
    title: "Status", field: "state_name",
    render: (params) => {
      return (
        <div className="">
          {
            params.state_name === "Approved" ? <span className='verified'>Verified</span> :
              params.state_name === "Closed Approved" ? <span className='Rejected'>Closed</span> :
                params.state_name === "New" ? <span className='new'>New</span> :
                  params.state_name === "In Progress" ? <span className='in-progress'>In Progress</span> :
                    params.state_name === "Closed Rejected" ? <span className='Rejected'>Rejected</span> :
                      params.state_name === " Complete" ? <span className='completed'>Complete</span> : <></>
          }
        </div>
      );
    }
  },
  ];
  

  const data = [
    {name: taskCount===undefined?[]:taskCount.Not_Started, students: parseInt(taskCount===undefined?[]:taskCount.Not_Started),fill: '#1c96ff'},
    {name: taskCount===undefined?[]:taskCount.Ongoing, students:parseInt(taskCount===undefined?[]:taskCount.Ongoing) ,fill: '#0c5493'},
    {name: taskCount===undefined?[]:taskCount.Completed, students: parseInt(taskCount===undefined?[]:taskCount.Completed),fill: '#0578db'},
  
  ];

return (
 <>
        <div className='container' style={{marginTop:'0px'}}>
       
        <div className='row' >
            <PieChart width={230} height={230}>
            <Pie data={data}  dataKey="students" outerRadius={80} innerRadius={50} isAnimation={false} label={renderCustomizedLabel} nameKey="name"/>
            </PieChart>
        
            <div className='col-sm'>
            <ul className='list-grpup'>
            
                <li className="list-group-item"><i className='bx bxs-square' style={{color:"#0578DB"}}/> Completed</li>
                <li className="list-group-item "><i className='bx bxs-square' style={{color:"#0C5493"}}/> Ongoing Task</li>
                <li className="list-group-item"><i className='bx bxs-square'style={{color:"#1C96FF"}}/> Not Started Yet</li>
            
            </ul>
            </div>
        </div>
        </div>
        <MaterialTable
        title="All Tasks"
        variant="scrollable"
        style={{ margin: '20px' }}
        textColor="primary"
        columns={column1}
        data={row===undefined?[]:row}
        icons={tableIcons}
        indicatorColor="primary"
        options={{
            exportButton: true,
        }}
        />
 </>
        
);
}
  
export default Emp_status;