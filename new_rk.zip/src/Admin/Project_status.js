import React, { useEffect, useState } from 'react';
import Chart from 'react-google-charts';
import { Col, Row, Form, InputGroup, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from 'axios';
import MaterialTable from 'material-table';
import tableIcons from './MaterialTableIcons';
import { useHistory } from 'react-router';
import Moment from 'moment';


import high from '../img/high.png'
import Moderate from '../img/Moderate.png'
import low from '../img/low.png'


export default function Project_status() {

  const [projectName,setProjectName]=useState([])

  const [projectTaskCount, setTaskProjectCount] = useState([])

  console.log("Hello",projectTaskCount);
  const data = [
    ["City","Ongoing task", "Completed task"],
        ["",parseInt(projectTaskCount.ongoing),parseInt(projectTaskCount.completed)],
  ];
  
  const options = {
  
    legend: { position: "top" },
    chartArea: { width: "50%" },
    chartArea: { height: "20%" },
    colors: ["#FFB782", "#82E29D"],
    isStacked: true,
   
  };
  const [activityStream, setActivityStream] = useState()
    const history = useHistory()
    const goToTask = (e, row) => {
      e.preventDefault()
      localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
      if (row.state === "In Progress" || row.state === "New" || row.state === "Incomplete")
        localStorage.setItem("taskState", "in-progress")
      else
        localStorage.setItem("taskState", "view")
  
      const obj1 = new Date()
      localStorage.setItem("currentTime", obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds())
      let state0 = 0
      if (row.state === "Approved") {
        state0 = "3"
      } else if (row.state === "Closed Approved") {
        state0 = "4"
      } else if (row.state === "New") {
        state0 = "0"
      } else if (row.state === "In Progress") {
        state0 = "1"
      } else if (row.state === "Closed Rejected") {
        state0 = "5"
      } else if (row.state === " Complete") {
        state0 = "2"
      } else if (row.state === "Incomplete") {
        state0 = "3"
      }
      history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
    }
  
    const column2 = [{
        title: "Task name",
        field: "task_title",
        render: (params) => {
          return (
            <div className="task_title" onClick={(e) => goToTask(e, params)}>
              {params.task_title}
            </div>
          );
        }
      },
      {
        title: "Due date",
        field: "due_date",
        render:(params)=>{
          return(
            <div>
                {Moment(params.due_date).format('DD-MM-YYYY') }
            </div>
          )
        }  
      },
      {
        title: "Assigned to",
        // field: "history_status",
        field: "emp_name",
      },
      {
        title: "Proirity",
        field: "priority",
        render: (params) => {
          return (
            <div className="priority">
              {
                params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
                  params.priority === "High" ? <img src={high} alt="High" /> :
                    params.priority === "Low" ? <img src={low} alt="Low" /> :
                      <></>
              }
            </div>
          );
        }
      },
      {
        title: "Status", field: "state",
        render: (params) => {
          return (
            <div className="">
              {
                params.state === "Approved" ? <span className='verified'>Verified</span> :
                  params.state === "Closed Approved" ? <span className='Closed'>Closed</span> :
                    params.state === "New" ? <span className='new'>New</span> :
                      params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                        params.state === "Incomplete" ? <span className='in-progress'>Incomplete</span> :
                          params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
              }
            </div>
          );
        }
      },
      ]
    
  const [value, setValue] = useState(0)

  const [row, setRow] = useState([])
  useEffect(() => {
    // setTimeout(() => {
      
    axios
      .post("http://localhost/php/new/tasks/allProjectTask.php",{proj_id:window.location.pathname.split("/").pop()})
      .then((resp) => {
        setRow(resp.data)
        // console.log(resp.data)
      })
    // }, 500);
  }, [])


  //API called for getting project task count

  useEffect(() => {
    // setTimeout(() => {
    axios
      .post("http://localhost/php/new/tasks/projectTaskCount.php",{proj_id:window.location.pathname.split("/").pop()})
      .then((resp) => {
        setTaskProjectCount(resp.data[0])
        console.log(resp.data)
      })
    // }, 500);
  }, [])


    // API called for getting project name by ID
  useEffect(() => {
    // setTimeout(() => {
    axios
      .post("http://localhost/php/new/project/getProjectNameById.php",{proj_id:window.location.pathname.split("/").pop()})
      .then((resp) => {
        setProjectName(resp.data[0])
        console.log(resp.data)
      })
    // }, 500);
  }, [])

  
    return (
      <>
      <div className="card" >
        <div className="card-body">
          <>
          {/* Gantt Chart Button is here */}

          <div style={{display:'flex'}}>
              <div  style={{flex: '1',color:'#3772FF',fontSize:'25px',marginLeft:'1.5%'}}>
                  <b>{projectName.project_name}</b>
              </div>

              <div  style={{textAlign:'right',flex:'1'}}>
                  <button className='btn btn-primary'>
                    <Link to={{pathname:'/GanttChart',state:{username:'swaraj'}}} style={{color:'white',textDecoration:'none'}}>
                      Gantt Chart
                    </Link>
                  </button>
              </div>
          </div>

          {/* <Button
              variant="link"
              style={{ fontSize: "medium", color: "blue" }}
            >
              {" "}
              <Link to="Gantt">Gannt chartT</Link>{" "}
            </Button> */}
      <Chart
        chartType="BarChart"
        width="100%"
        height="200px"
        data={data}
        options={options}
      />
      <MaterialTable
                title="My Task List"
                icons={tableIcons}
                columns={column2}
                variant="scrollable"
                style={{ margin: '20px' }}
                value={value}
                textColor="primary"
                indicatorColor="primary"
                data={row}
                options={{
                    exportButton: true,
                }}
            />
            </>
            </div>
      </div>
    </>
    );
  }