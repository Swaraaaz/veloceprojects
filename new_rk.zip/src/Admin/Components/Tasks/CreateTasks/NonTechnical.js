import React, { useState, useEffect } from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap';
import { Formik } from 'formik';
import * as yup from 'yup';
import axios from 'axios'

export default function NonTechnical(props) {
  const [reported, setDepartment] = useState([])
  const [role, setRole] = useState([])

  const [responsiblePerson,setResponsiblePerson]=useState([])
  const [project, setProject] = useState([])
  const [assignedTo, setAssignedTo] = useState([])
  const [reportedTo, setReportedTo] = useState([])

  
  const [createNonTechTask,setCreateNonTechTask]=useState({
    project_id:"",
    project_name:"",
    // task_id:"",
    task_title:"",
    description:"",
    assign_to:"",
    assign_to_name:"",
    responsible_person:"",
    responsible_person_name:"",
    task_start_date:"",
    task_finish_date:"",
    priority:"",
    reminder:"",
    reminder_reponsible_person:"",
    reminder_reponsible_person_name:"",
  });

  const onInputChange = (e) => {
    setCreateNonTechTask({ ...createNonTechTask, [e.target.name]: e.target.value })
}

const onFormSubmit=(e)=>{
  // e.preventDefault()
  console.log(createNonTechTask)
  axios.post("http://localhost/php/new/tasks/addNonTechTask.php",createNonTechTask)
  .then((res) => {         
    console.log("Hi");
      // handleClose()
      props.setOpen(false)
      axios.get("http://localhost/php/new/tasks/allTasks.php")
          .then((res) => {
      //       setRow(res.data);
          })
  })
}


  useEffect(() => {
    axios.get('http://localhost/php/new/tasks/fetchproject.php').then((resp) => setProject(resp.data))

    axios.get('http://localhost/php/pms/nontechnical_task/getNonTechEmployee.php').then((resp) => setRole(resp.data))
    axios.post('http://localhost/php/pms/nontechnical_task/getreportedtoEmp.php', localStorage.getItem("emp_id")).then((resp) => setDepartment(resp.data))
    axios.get('http://localhost/php/new/tasks/getAllEmployee.php').then((resp) => setAssignedTo(resp.data))
    axios.get('http://localhost/php/new/tasks/getReportedemployee.php').then((resp) => setReportedTo(resp.data))
    axios.get('http://localhost/php/new/tasks/getResponsiblePerson.php').then((resp) => setResponsiblePerson(resp.data))

  }, [])

  const schema = yup.object().shape({
    task_name: yup.string().required(),
    description: yup.string().required(),
    assign_to: yup.string().required(),
    due_by: yup.date().required(),
    reported: yup.string().required(),
    reminder_date: yup.date().required()
  });

  return (
    <Formik
      validationSchema={schema}
      onSubmit={(values) => {
        axios.post("http://localhost/php/pms/nontechnical_task/non_technical_emp_task.php", JSON.stringify({...values, task_id: ''})).then((resp) => alert("success"))
        // alert(JSON.stringify({ ...values, session_emp_id: localStorage.getItem("emp_id"), session_role_id: localStorage.getItem("role_id") }))
        props.setOpen(false)
      }}
      initialValues={{
        task_name: '',
        description: '',
        assign_to: '',
        due_by: '',
        reported: '',
        reminder_date: '',
      }}
    >
      {({
        handleSubmit,
        handleChange,
        handleBlur,
        values,
        touched,
        isValid,
        errors,
      }) => (
        <Form noValidate onSubmit={(e) => {
          e.preventDefault()
          onFormSubmit()
          handleSubmit()
        }}>
          <Row className="mb-3">

{/*             
            <Form.Group as={Col} md="12" controlId="validationFormik03">
              <Form.Label>Project Name</Form.Label>
              <Form.Control
                as="select"
                placeholder="Project Name"
                name="project_name"
                value=""
                onChange={handleChange}
              />
                <option key={''} value={''}>Select Project</option>
                {project.map((item, key) => {
                  return (
                    <option key={key} value={item.project_id}>{item.project_name}</option>
                  );
                })}
            </Form.Group> */}

          <Form.Group as={Col} md="12" controlId="validationFormik03">
              <Form.Label>Project Name</Form.Label>
              <Form.Control
                as="select"
                placeholder="Project Name"
                name="project_id"
                onChange={onInputChange}
              // isInvalid={!!errors.project_id}
              >
                <option key={''} value={''}>Select Project</option>
                {project.map((item, key) => {
                  return (
                    <option key={key} value={item.project_id}>{item.project_name}</option>
                  );
                })}
              </Form.Control>
            </Form.Group>


            <Form.Group as={Col} md="12" controlId="validationFormik03">
              <Form.Label>Task Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Task Name"
                name="task_title"
                onChange={onInputChange}
              />
            </Form.Group>


            <Form.Group as={Col} md="12" controlId="validationFormik04">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={2}
                placeholder="Description"
                name="description"
                onChange={onInputChange}

              />
            </Form.Group>


            <Form.Group as={Col} md="6" controlId="validationFormik10">
              <Form.Label>Assigned to</Form.Label>
              <Form.Control
                as="select"
                placeholder="Assigned to"
                name="assign_to"
                onChange={onInputChange}
              >
                <option key={'empty'} value={''}>Select Type</option>
                {assignedTo.map((item, key) => {
                  return (
                    <option key={key} value={item.emp_id}>{item.empname}</option>
                  );
                })}
              </Form.Control>
            </Form.Group>


            <Form.Group as={Col} md="6" controlId="validationFormik11">
              <Form.Label>Reported to</Form.Label>
              <Form.Control
                as="select"
                placeholder="Reported to"
                name="responsible_person"
                onChange={onInputChange}
              >
                <option key={'empty'} value={''}>Select Type</option>
                {reportedTo.map((item, key) => {
                  return (
                    <option key={key} value={item.emp_id}>{item.empname}</option>
                  );
                })}
              </Form.Control>
            </Form.Group>


            <Form.Group as={Col} md="6" controlId="validationFormik08">
              <Form.Label>Task Start Date</Form.Label>
              <Form.Control
                type="date"
                placeholder="Actual Start Date."
                name="task_start_date"
                onChange={onInputChange}
              />
            </Form.Group>


            <Form.Group as={Col} md="6" controlId="validationFormik09">
              <Form.Label>Task Finish Date</Form.Label>
              <Form.Control
                type="date"
                placeholder="Task Finish Date"
                name="task_finish_date"
                onChange={onInputChange}
              />
            </Form.Group>

            <Form.Group as={Col} md="3" controlId="validationFormik10">
              <Form.Label>Priority</Form.Label>
              <Form.Control
                as="select"
                placeholder="Priority"
                name="priority"
                onChange={onInputChange}
              >
                <option key={'empty'} value={''}>Select Priority</option>
                <option key={''} value={'High'}>High</option>
                <option key={''} value={'Moderate'} selected >Moderate</option>
                <option key={''} value={'Low'}>Low</option>

              </Form.Control>

            </Form.Group>

            <Form.Group as={Col} md="3" controlId="validationFormik09">
              <Form.Label>Set Reminder Date</Form.Label>
              <Form.Control
                type="date"
                placeholder="Set Reminder Date"
                name="reminder"
                onChange={onInputChange}
              />
            </Form.Group>

            <Form.Group as={Col} md="6" controlId="validationFormik11">
              <Form.Label>Reponsible person</Form.Label>
              <Form.Control
                as="select"
                placeholder="Reminder Reponsible person"
                name="reminder_reponsible_person"
                onChange={onInputChange}
              >
                <option key={'empty'} value={''}>Select Reponsible person</option>
                {responsiblePerson.map((item, key) => {
                  return (
                    <option key={key} value={item.emp_id}>{item.empname}</option>
                  );
                })}
              </Form.Control>
              <Form.Control.Feedback type="invalid">
                {errors.reminder_reponsible_person}
              </Form.Control.Feedback>
            </Form.Group>

          </Row>
          <div style={{textAlign:'center'}}>
            <Button type="submit">Submit form</Button>
          </div>
        </Form>
      )}
    </Formik>
  )
}
