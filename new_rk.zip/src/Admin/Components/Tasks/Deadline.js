import axios from 'axios'
import React, { useEffect, useState } from 'react'
import './deadline.css'

export default function Deadline() {
    const [taskbyOverdue, setTaskbyOverdue] = useState([[], [], [], []])
    useEffect(() => {
        axios.post("http://localhost/php/new/tasks/deadline.php", {emp_id: localStorage.getItem("emp_id"), tirelevel: localStorage.getItem("tirelevel")}).then((resp) => {
        // axios.post("http://localhost/php/pms/tasks/deadlineAPI.php", {}).then((resp) => {
            setTaskbyOverdue(resp.data)
            console.log(resp.data)
        })
    }, [])
    return (
        <div className='row'>
            <div className="col-3">
                <div className="deadline-title deadline-overdue text-center">
                    <strong>Overdue</strong>
                </div>
                {
                    taskbyOverdue[1].length !== 0 ?
                        taskbyOverdue[1].map((item, key) => (
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} key={key}>
                                <span className="task-title overdue">{item.task_title}</span>
                                <div>
                                    <span className="project-name">{item.project_name}</span>
                                </div>
                                <div>
                                    <span className="task-date">{item.task_finish_date}</span>
                                </div>
                            </div>
                        )) : <>
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} >
                                <span style={{ fontSize: '15px', }}>None</span>
                            </div>
                        </>
                }
            </div>
            <div className="col-3">
                <div className="deadline-title deadline-due-today text-center">
                    <strong>Due Today</strong>
                </div>
                {
                    taskbyOverdue[0].length !== 0 ?
                        taskbyOverdue[0].map((item, key) => (
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} key={key}>
                                <span className="task-title today">{item.task_title}</span>
                                <div>
                                    <span className="project-name">{item.project_name}</span>
                                </div>
                                <div>
                                    <span className="task-date">{item.task_finish_date}</span>
                                </div>
                            </div>
                        )) : <>
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} >
                                <span style={{ fontSize: '15px', }}>None</span>
                            </div>
                        </>
                }

            </div>
            <div className="col-3">
                <div className="deadline-title deadline-due-this-week text-center">
                    <strong>Due This Week</strong>
                </div>
                {
                    taskbyOverdue[3].length !== 0 ?
                        taskbyOverdue[3].map((item, key) => (
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} key={key}>
                                <span className="task-title this-week">{item.task_title}</span>
                                <div>
                                    <span className="project-name">{item.project_name}</span>
                                </div>
                                <div>
                                    <span className="task-date">{item.task_finish_date}</span>
                                </div>
                            </div>
                        )) : <>
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} >
                                <span style={{ fontSize: '15px', }}>None</span>
                            </div>
                        </>
                }

            </div>
            <div className="col-3">
                <div className="deadline-title deadline-due-next-week text-center">
                    <strong>Due Next Week</strong>
                </div>
                {
                    taskbyOverdue[2].length !== 0 ?
                        taskbyOverdue[2].map((item, key) => (
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} key={key}>
                                <span className="task-title next-week">{item.task_title}</span>
                                <div>
                                    <span className="project-name">{item.project_name}</span>
                                </div>
                                <div>
                                    <span className="task-date">{item.task_finish_date}</span>
                                </div>
                            </div>
                        )) : <>
                            <div className="card deadline-title text-center" style={{ color: 'black', textTransform: "none" }} >
                                <span style={{ fontSize: '15px', }}>None</span>
                            </div>
                        </>
                }
            </div>
        </div>
    )
}
