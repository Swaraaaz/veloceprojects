import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'
import high from '../../../img/high.png'
import Moderate from '../../../img/Moderate.png'
import low from '../../../img/low.png'
import { useHistory } from 'react-router';

export default function Approved(props) {
  const deleteHandle = (e, row) => {
    e.preventDefault()
    // axios.post('http://localhost/php/new/employee/dismissEmp.php', { dismiss_emp_id: row.emp_id, emp_id: localStorage.getItem("emp_id"), role_id: localStorage.getItem("role_id") }).then(() => {
    //   axios.get('http://localhost/php/new/employee/allActiveEmployees.php').then(res => {
    //     //Storing users detail in state array object
    //     setRow(res.data);
    //   });
    // })
  }

  const history = useHistory()
  const viewHandle = (e, row) => {
    e.preventDefault()
    let state0 = 0
    if (row.state === "Approved") {
      state0 = "6"
    } else if (row.state === "Closed Approved") {
      state0 = "4"
    } else if (row.state === "New") {
      state0 = "0"
    } else if (row.state === "In Progress") {
      state0 = "1"
    } else if (row.state === "Closed Rejected") {
      state0 = "5"
    } else if (row.state === " Complete") {
      state0 = "2"
    } else if (row.state === "Incomplete") {
      state0 = "3"
    }
    localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
    localStorage.setItem("taskState", "approved")
    history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
  }

  const editHandle = (e, row) => {
    e.preventDefault()
    props.setTaskId(row.task_id)
    axios.post(
      "http://localhost/php/new/tasks/getTaskByID.php",
      { task_id: row.task_id, emp_id: localStorage.getItem("emp_id") }).then((resp) => {
        props.setEditData(resp.data[0])
        // localStorage.setItem("editData", JSON.stringify(resp.data[0]))
        console.log("A");
        // setTimeout(() => {
        props.setOpen1(true)
        // }, 1000);
      })
  }
  const columns = [
    { title: "Task Name", field: "task_title", width: "10%" },
    { title: "Project Name", field: "project_name" },
    { title: "Due date", field: "due_date" },
    { title: "Assigned to", field: "emp_name" },
    { title: "Priority", field: "priority" },
    {
      title: "Status", field: "state",
      render: (params) => {
        return (
          <div className="priority">
            {
              params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
                params.priority === "High" ? <img src={high} alt="High" /> :
                  params.priority === "Low" ? <img src={low} alt="Low" /> :
                    <></>
            }
          </div>
        );
      }
    },
    {
      title: "Status", field: "state",
      render: (params) => {
        return (
          <div className="">
            {
              params.state === "Approved" ? <span className='verified'>Verified</span> :
                params.state === "Closed Approved" ? <span className='Closed'>Closed</span> :
                  params.state === "New" ? <span className='new'>New</span> :
                    params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                      params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
            }
          </div>
        );
      }
    },
    {
      tititle: "", field: "",
      render: (params) => {
        return (
          <div className="">
            <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
              onClick={(e) => viewHandle(e, params)}
            >
              <i className="bi bi-eye-fill" style={{ color: 'blue' }}></i>
            </button>
            <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
              onClick={(e) => editHandle(e, params)}
            >
              <i className="bi bi-pencil-square" style={{ color: 'blue' }}></i>
            </button>
            {/* <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
              onClick={(e) => deleteHandle(e, params)}
            >
              <i className="bi bi-trash-fill" style={{ color: 'red' }}></i>
            </button> */}
          </div>
        );
      }
    }
  ];

  const [row, setRow] = useState([])
  useEffect(() => {
    axios
      .get("http://localhost/php/new/tasks/completedTasks.php")
      .then((resp) => {
        setRow(resp.data)
        console.log(resp.data)
      })
  }, [])


  return (
    <>
      <MaterialTable title="Approved Tasks" icons={tableIcons} columns={columns} data={row} />
    </>
  )
}
