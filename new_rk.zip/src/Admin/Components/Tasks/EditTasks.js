import { Modal } from 'react-bootstrap'
import Technical from './CreateTasks/Technical';
import axios from 'axios';
import React, { useState, useEffect } from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap';
import { Formik } from 'formik';
import * as yup from 'yup';
import { Typeahead } from 'react-bootstrap-typeahead';

export default function EditTask(props) {
  // const [value, setValue] = useState(0)
  // if (props.taskId !== undefined) {
  //   axios.post("http://localhost/php/new/tasks/getTaskByID.php", {task_id: props.taskId, emp_id: localStorage.getItem("emp_id")}).then((resp) => {
  //     setEditData(resp.data[0])
  //   })
  // } 

  const [assignedTo, setAssignedTo] = useState([])
  // Project List
  const [project, setProject] = useState([])
  // Reported to List
  const [reportedTo, setReportedTo] = useState([])
  // Selected linked Task 
  const [linkedTasks, setLinkedTasks] = useState([])
  // linked Task List
  const [linkedTasksList, setLinkedTasksList] = useState('')
  // Attachments
  const [attachment, setattachment] = useState();
  // Days
  const [days, setDays] = useState(props.editData.task_duration_days)
  // Selected Project 
  const [projectId, setProjectId] = useState(props.editData.project_id)
  // selected start_date 
  const [taskStartDate, setTaskStartDate] = useState('')
  // Data to edit 
  //   const [editData, setEditData] = useState({
  //     task_title: '',
  //     assign_to: '',
  //     project_id: '',
  //     priority: '',
  //     responsible_person: '',
  //     task_start_date: '',
  //     linked_issues_arr: '',
  //     task_finish_date: '',
  //     reminder_date: '',
  //     reminder_reponsible_person: '',
  //     linked_issue_condition: '',
  // })

  // console.log(editData)

  // useEffect(() => {
  //   console.log(props.taskId);
  //   if (props.taskId !== undefined) {
  //     axios.post("http://localhost/php/new/tasks/getTaskByID.php", {task_id: props.taskId, emp_id: localStorage.getItem("emp_id")}).then((resp) => {
  //       setEditData(resp.data[0])
  //     })
  //   } 
  // }, [editData])

  useEffect(() => {
    
    axios.get('http://localhost/php/new/tasks/fetchproject.php').then((resp) => setProject(resp.data))
    axios.get('http://localhost/php/new/tasks/getAllEmployee.php').then((resp) => setAssignedTo(resp.data))
    axios.get('http://localhost/php/new/tasks/getReportedemployee.php').then((resp) => setReportedTo(resp.data))
  }, [])

  const uploadattachment = (e) => {
    setattachment(e.target.files[0]);
  };

  const calDays = (e) => {
    const [year, month, days] = taskStartDate.split('-')
    const [year2, month2, days2] = e.target.value.split('-')
    const start = new Date(month + "/" + days + "/" + year)
    const end = new Date(month2 + "/" + days2 + "/" + year2)
    var Difference_In_Time = end.getTime() - start.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    setDays(Difference_In_Days)
  }

  const getLinkedTask = (e) => {
    e.preventDefault()
    setProjectId(e.target.value)
    axios.post('http://localhost/php/new/tasks/getTask.php', e.target.value).then((resp) => {
      let x = []
      for (let i = 0; i < resp.data.length; i++) {
        x = [...x, resp.data[i].name]
      }
      console.log(x);
      setLinkedTasksList(x)
    })
    console.log("x");
  }

  const schema = yup.object().shape({
    task_title: yup.string().required(),
    assign_to: yup.string().required(),
    // project_id: yup.string().required(),
    priority: yup.string().required(),
    responsible_person: yup.string().required(),
    linked_issue_condition: yup.string().required(),
    task_start_date: yup.date().required(),
    task_finish_date: yup.date().required(),
    reminder_date: yup.date().required(),
    reminder_reponsible_person: yup.string().required(),
  });


  return (
    <>
      <Modal
        show={props.open1}
        onHide={() => props.setOpen1(false)}
      >
        <Modal.Header closeButton>
          <Modal.Title>Edit Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {
            props.open1 === true ? 
            <Formik
            validationSchema={schema}
            onSubmit={(values) => {
              // axios.post("http://localhost/php/new/tasks/addProjectTask.php",
              //   JSON.stringify({
              //     ...values,
              //     task_id: '',
              //     linked_issues_arr: linkedTasks.join(),
              //     session_emp_id: localStorage.getItem("emp_id"),
              //     session_role_id: localStorage.getItem("role_id"),
              //     reported: values.responsible_person,
              //     task_duration_days: days,
              //     project_id: projectId
              //   }))
              //   .then((resp) => {

              //     const modalFormData = new FormData();
              //     modalFormData.append("file[]", attachment);
              //     modalFormData.append("task_id", resp.data);
              //     modalFormData.append("linkforfile", resp.data);
              //     modalFormData.append("project_id", values.project_id);
              //     // alert(JSON.stringify(modalFormData))
              //     axios
              //       .post(
              //         "http://localhost/php/new/tasks/uploadAttchments.php",
              //         modalFormData
              //       ).then((resp) => {
              //       })

              //   })
              // alert(JSON.stringify({
              //   ...values,
              //   task_id: '',
              //   linked_issues_arr: linkedTasks.join(),
              //   session_emp_id: localStorage.getItem("emp_id"),
              //   session_role_id: localStorage.getItem("role_id"),
              //   reported: values.responsible_person,
              //   task_duration_days: days,
              //   project_id: projectId
              // }))
              props.setOpen(false)
            }}
            initialValues={
              {
                task_title: props.editData.task_title,
                assign_to: props.editData.assign_to,
                // project_id: '',
                priority: props.editData.priority,
                responsible_person: props.editData.responsible_person,
                task_start_date: props.editData.task_start_date,
                task_finish_date: props.editData.task_finish_date,
                reminder_date: props.editData.reminder_date,
                reminder_reponsible_person: props.editData.reminder_reponsible_person,
                linked_issue_condition: props.editData.linked_issue_condition
              }
            }
          >
            {({
              handleSubmit,
              handleChange,
              handleBlur,
              values,
              touched,
              isValid,
              errors,
            }) => (
              <Form noValidate onSubmit={(e) => {
                e.preventDefault()
                handleSubmit()
              }}>
                <Row className="mb-3">
                  {/* Task Name */}
                  <Form.Group as={Col} md="6" controlId="validationFormik03">
                    <Form.Label>Task Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Task Name"
                      name="task_title"
                      value={values.task_title}
                      defaultValue={props.editData.task_title}
                      onChange={handleChange}
                      isInvalid={!!errors.task_title}
                    />

                    <Form.Control.Feedback type="invalid">
                      {errors.task_title}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Assigned To */}
                  <Form.Group as={Col} md="6" controlId="validationFormik06">
                    <Form.Label>Assign to</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Assign to"
                      name="assign_to"
                      value={values.assign_to}
                      defaultValue={props.editData.assign_to}
                      onChange={handleChange}
                      isInvalid={!!errors.assign_to}
                    >
                      <option key={'empty'} value={''}>Select Assign to  </option>
                      {assignedTo.map((item, key) => {
                        return (
                          <option key={key} value={item.emp_id}>{item.empname}</option>
                        );
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      {errors.assign_to}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Project Name */}
                  <Form.Group as={Col} md="6" controlId="validationFormik09">
                    <Form.Label>Project Name</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Project Name"
                      name="project_id"
                      value={projectId}
                      defaultValue={props.editData.project_id}
                      onChange={getLinkedTask}
                    // isInvalid={!!errors.project_id}
                    >
                      <option key={''} value={''}>Select Project</option>
                      {project.map((item, key) => {
                        return (
                          <option key={key} value={item.project_id}>{item.project_name}</option>
                        );
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      {/* {errors.project_id} */}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Priority */}
                  <Form.Group as={Col} md="6" controlId="validationFormik10">
                    <Form.Label>Priority</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Priority"
                      name="priority"
                      value={values.priority}
                      defaultValue={props.editData.priority}
                      onChange={handleChange}
                      isInvalid={!!errors.priority}
                    >
                      <option key={'empty'} value={''}>Select Priority</option>
                      <option key={''} value={'High'}>High</option>
                      <option key={''} value={'Moderate'}>Moderate</option>
                      <option key={''} value={'Low'}>Low</option>

                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      {errors.priority}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Reported To */}
                  <Form.Group as={Col} md="6" controlId="validationFormik11">
                    <Form.Label>Reported To</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Reported To"
                      name="responsible_person"
                      value={values.responsible_person}
                      defaultValue={props.editData.responsible_person}
                      onChange={handleChange}
                      isInvalid={!!errors.responsible_person}
                    >
                       <option key={'empty'} value={''}>Select Reported To</option>
                      {reportedTo.map((item, key) => {
                        return (
                          <option key={key} value={item.emp_id}>{item.empname}</option>
                        );
                      })} 
                      
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      {errors.responsible_person}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Linked Tasks */}

                  {
                    linkedTasksList === '' ? <></> : <>
                      <Form.Group as={Col} md="6" controlId="validationFormik11">
                        <Form.Label>Linked Tasks</Form.Label>
                        <Typeahead
                          id="basic-typeahead-single"
                          labelKey="name"
                          onChange={setLinkedTasks}
                          defaultValue={props.editData.linked_issues_arr}
                          options={linkedTasksList}
                          placeholder="Choose a state..."
                        />
                        <Form.Control.Feedback type="invalid">
                          {errors.linked_issues_arr}
                        </Form.Control.Feedback>
                      </Form.Group>
                      {/* Linked Tasks Condition */}
                      <Form.Group as={Col} md="6" controlId="validationFormik11">
                        <Form.Label>Linked Tasks Condition</Form.Label>
                        <Form.Control
                          as="select"
                          placeholder="Linked Tasks Condition"
                          name="linked_issue_condition"
                          value={values.linked_issue_condition}
                          defaultValue={props.editData.linked_issue_condition}
                          onChange={handleChange}
                          isInvalid={!!errors.linked_issue_condition}
                        >
                          <option key={'empty'} value={''}>Select Condition</option>

                          <option value="1">blocked by</option>
                          <option value='2'>cloned by</option>
                          <option value='3'>depends by</option>
                          <option value='4'>Linked to</option>
                        </Form.Control>
                        <Form.Control.Feedback type="invalid">
                          {errors.linked_issue_condition}
                        </Form.Control.Feedback>
                      </Form.Group></>
                  }


                  {/* Attachment */}
                  <Form.Group as={Col} md="6" controlId="validationFormik03">
                    <Form.Label>Attachment</Form.Label>
                    <Form.Control
                      type="file"
                      onChange={(e) => uploadattachment(e)}
                      // onChange={(e) => uploadDegree(e, i)}
                      name="attachments"
                    />
                  </Form.Group>
                  {/* Task start date */}
                  <Form.Group as={Col} md="4" controlId="validationFormik07">
                    <Form.Label>Task start date</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Task start date"
                      name="task_start_date"
                      value={values.task_start_date}
                      defaultValue={props.editData.task_start_date}
                      onChange={(e) => {
                        handleChange(e)
                        setTaskStartDate(e.target.value)
                      }}
                      isInvalid={!!errors.task_start_date}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.task_start_date}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Task finish date */}
                  <Form.Group as={Col} md="4" controlId="validationFormik08">
                    <Form.Label>Task finish date</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Task finish date"
                      name="task_finish_date"
                      value={values.task_finish_date}
                      defaultValue={props.editData.task_finish_date}
                      onChange={(e) => {
                        handleChange(e)
                        calDays(e)
                      }}
                      isInvalid={!!errors.task_finish_date}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.task_finish_date}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Task Duration Days */}
                  <Form.Group as={Col} md="4" controlId="validationFormik08">
                    <Form.Label>Task finish date</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Task durations in days"
                      value={days}
                      onChange={setDays}
                      disabled
                    />
                    <Form.Control.Feedback type="invalid">
                      {/* {errors.task_finish_date} */}
                    </Form.Control.Feedback>
                  </Form.Group>
                  {/* Set reminder */}
                  <Form.Group as={Col} md="6" controlId="validationFormik07">
                    <Form.Label>Set reminder</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Set reminder"
                      name="reminder_date"
                      min="1950-01-01"
                      max="2000-12-31"
                      value={values.reminder_date}
                      defaultValue={props.editData.reminder_date}
                      onChange={handleChange}
                      isInvalid={!!errors.reminder_date}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.reminder_date}
                    </Form.Control.Feedback>
                  </Form.Group>

                  {/* Reponsible person */}
                  <Form.Group as={Col} md="6" controlId="validationFormik11">
                    <Form.Label>Reponsible person</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Reponsible person"
                      name="reminder_reponsible_person"
                      value={values.reminder_reponsible_person}
                      onChange={handleChange}
                      defaultValue={props.editData.reminder_reponsible_person}
                      isInvalid={!!errors.reminder_reponsible_person}
                    >
                      <option key={'empty'} value={''}>Select Reponsible person</option>
                      {assignedTo.map((item, key) => {
                        return (
                          <option key={key} value={item.emp_id}>{item.empname}</option>
                        );
                      })}
                    </Form.Control>
                    <Form.Control.Feedback type="invalid">
                      {errors.reminder_reponsible_person}
                    </Form.Control.Feedback>
                  </Form.Group>

                </Row>
                <Button type="submit">Submit form</Button>
              </Form>
            )}
          </Formik> : <></>
          }
        </Modal.Body>
      </Modal>
    </>
  );
}
