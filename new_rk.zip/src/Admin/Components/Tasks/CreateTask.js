import { Modal } from 'react-bootstrap';
import React, { useState } from 'react'
import { Paper, Tab, Tabs } from '@material-ui/core';
import Technical from './CreateTasks/Technical';
import NonTechnical from './CreateTasks/NonTechnical';

export default function CreateTask(props) {
    const [value, setValue] = useState(0)

    return (
        <>
            <Modal
                show={props.open}
                onHide={() => props.setOpen(false)}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Create Task</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Paper style={{ justifyContent: 'space-between', display: 'flex', marginBottom: '1rem' }}>
                        <Tabs
                            variant="scrollable"
                            value={value}
                            textColor="primary"
                            indicatorColor="primary"
                            onChange={(event, newValue) => {
                                setValue(newValue)
                            }}
                        >
                            <Tab label="Technical" />
                            <Tab label="Non Technical" />
                        </Tabs>
                    </Paper>
                    {
                        value === 0 ? <NonTechnical taskId="" setOpen={props.setOpen} /> :
                        value === 1 ? <Technical setOpen={props.setOpen} /> :


                            // value === 0 ? <Technical setOpen={props.setOpen} /> :
                            // value === 1 ? <NonTechnical taskId="" /> :
                            <></>
                    }
                    
                </Modal.Body>
            </Modal>
        </>
    );
}
