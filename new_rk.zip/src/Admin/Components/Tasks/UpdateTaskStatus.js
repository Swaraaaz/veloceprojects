import React, { useState, useEffect } from 'react'
import { Button, Col, Form, Row } from 'react-bootstrap';
import { Formik } from 'formik';
import * as yup from 'yup';
import axios from 'axios'
import { useHistory, useLocation } from 'react-router-dom';
import DisplayComponent from '../Timer/DisplayComponent';
import './TaskStatus.css'

export default function UpdateTaskStatus(props) {
    const history=useHistory();
    const location = useLocation();
    const [state0, setState0] = useState()
    const [timing, setTiming] = useState();
    const [time, setTime] = useState({ hour: "00", minutes: "00", seconds: "00" });
    const [delegate, setDelegate] = useState([])
    const [inputData, setInputData] = useState({})
    useEffect(() => {

        axios.post("http://localhost/php/pms/project/getTaskByID.php", { task_id: location.state.task_id, emp_id: location.state.emp_id }).then((resp) => {
            setInputData(resp.data[0])
            console.log(resp.data[0])
            let timer = resp.data[0].timer.split(":")
            let hr = parseInt(timer[0])
            let min = parseInt(timer[1])
            let sec = parseInt(timer[2])

            if (hr < 10) {
                hr = "0" + hr
            }

            if (min < 10) {
                min = "0" + min
            }

            if (sec < 10) {
                sec = "0" + sec
            }

            setTime({ hour: hr, minutes: min, seconds: sec })

            let secs;
            const obj1 = new Date()
            if (localStorage.getItem("taskState") === "in-progress")
                secs = localStorage.getItem("currentTime")
            else
                secs = obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds()

            let x = parseInt(hr * 60 * 60 + min * 60 + sec)
            if (secs > x) {
                setTiming(secs - x)
            } else {
                setTiming(x - secs)
            }
            axios.post("http://localhost/php/pms/project/getProjectEmp.php", resp.data[0].project_id).then((resp) => setDelegate(resp.data))
        })
    }, [])

    const start = () => {
        // setTime(JSON.parse(localStorage.timerValue))
        // console.log("ash")
        setTimeout(function () {
            const obj1 = new Date()
            const secs = obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds()
            var n = secs - timing
            var hour = parseInt(n / 3600);
            if (hour < 10) {
                hour = "0" + hour
            }
            n %= 3600;
            var minutes = parseInt(n / 60);
            if (minutes < 10) {
                minutes = "0" + parseInt(minutes)
            }

            n %= 60;
            var seconds = parseInt(n);
            if (seconds < 10) {
                seconds = "0" + parseInt(seconds)
            }
            setTime({ hour: hour + "", minutes: minutes + "", seconds: seconds + "" })
        }, 1000);
    };

    var status = localStorage.getItem("taskState") === "in-progress";

    useEffect(() => {
        if (status) {
            start()
            console.log("Y")
        } else {
            clearInterval()
        }
    }, [time])

    const schema = yup.object().shape({
        task_state: yup.string().required(),
        delegate: yup.string(),
        reminder_date: yup.date().required(),
    });


    return (
        <>
            <div className="card mx-3">
                <div className="card-body">
                    <Formik
                        validationSchema={schema}
                        onSubmit={(values) => {
                            axios.post("http://localhost/php/new/tasks/addTaskState.php", JSON.stringify({ ...inputData, ...values, timer: time.hour + ":" + time.minutes + ":" + time.seconds, state: values.task_state }))
                            .then((resp) =>{
                                history.push("/Tasks")
                            })
                            // alert(JSON.stringify({ ...inputData, ...values, timer: time.hour + ":" + time.minutes + ":" + time.seconds, state: values.task_state }))
                            props.setOpen(false)
                            
                        }}
                        initialValues={{
                            task_state: location.state.state0,
                            delegate: '',
                            reminder_date: '',
                        }}
                    >
                        {({
                            handleSubmit,
                            handleChange,
                            handleBlur,
                            values,
                            touched,
                            isValid,
                            errors,
                        }) => (
                            <Form noValidate onSubmit={(e) => {
                                e.preventDefault()
                                handleSubmit()
                            }}>
                                <Row className="mb-3">
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Task Name</Form.Label>
                                        <h5>{inputData.task_title}</h5>
                                    </Form.Group>
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Project Name</Form.Label>
                                        <h5>{inputData.project_name}</h5>
                                    </Form.Group>
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Priority </Form.Label>
                                        <h5>{inputData.priority}</h5>
                                    </Form.Group>
                                    {
                                        localStorage.getItem("taskState") === "in-progress" ?
                                            <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                                <Form.Label>Opened </Form.Label>
                                                <h5>{localStorage.openedTime}</h5>
                                            </Form.Group> : <></>
                                    }
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Opened by</Form.Label>
                                        <h5>{inputData.assignedto}</h5>
                                    </Form.Group>
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Due By </Form.Label>
                                        <h5>{inputData.due_date}</h5>
                                    </Form.Group>
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Reported to </Form.Label>
                                        <h5>{inputData.reported}</h5>
                                    </Form.Group>
                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik01">
                                        <Form.Label>Timer </Form.Label>

                                        <DisplayComponent time={time} />
                                    </Form.Group>
                                    {/* {
                                        localStorage.getItem("taskState") === "approved" ?
                                            <>
                                                <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik02">
                                                    <Form.Label>State</Form.Label>
                                                    <Form.Control
                                                        as="select"
                                                        placeholder="Assigned to"
                                                        name="task_state"
                                                        value={values.task_state}
                                                        onChange={handleChange}
                                                        isInvalid={!!errors.task_state}
                                                        disabled
                                                    >
                                                        <option key={'empty'} value={''}>Select State</option>
                                                        <option key={''} value={'6'}>Verified</option>
                                                        <option key={''} value={'4'}>Closed</option>
                                                        <option key={''} value={'5'}>Reject</option>


                                                    </Form.Control>
                                                    <Form.Control.Feedback type="invalid">
                                                        {errors.task_state}
                                                    </Form.Control.Feedback>
                                                </Form.Group>
                                            </> : <></>
                                    } */}
                                    {
                                        localStorage.getItem("taskState") === "ongoing" ?
                                            <>
                                                <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik02">
                                                    <Form.Label>State</Form.Label>
                                                    <Form.Control
                                                        as="select"
                                                        placeholder="Assigned to"
                                                        name="task_state"
                                                        value={values.task_state}
                                                        onChange={handleChange}
                                                        isInvalid={!!errors.task_state}
                                                        disabled
                                                    >
                                                        <option key={'empty'} value={''}>Select State</option>
                                                        <option key={''} value={'1'}>In Progress</option>
                                                        <option key={''} value={'2'}> Complete</option>
                                                        <option key={''} value={'3'}> Incomplete</option>
                                                        <option key={''} value={'0'}>Not Yet Started</option>


                                                    </Form.Control>
                                                    <Form.Control.Feedback type="invalid">
                                                        {errors.task_state}
                                                    </Form.Control.Feedback>
                                                </Form.Group>
                                            </> : <></>
                                    }
                                    {
                                        localStorage.getItem("taskState") === "view" ?
                                            <>
                                                <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik02">
                                                    <Form.Label>State</Form.Label>
                                                    <Form.Control
                                                        as="select"
                                                        placeholder="Assigned to"
                                                        name="task_state"
                                                        value={values.task_state}
                                                        onChange={handleChange}
                                                        isInvalid={!!errors.task_state}
                                                        disabled
                                                    >
                                                        <option key={'empty'} value={''}>Select State</option>
                                                        <option key={''} value={'1'}>In Progress</option>
                                                        <option key={''} value={'2'}> Complete</option>
                                                        <option key={''} value={'3'}> Incomplete</option>
                                                        <option key={''} value={'0'}>Not Yet Started</option>
                                                        <option key={''} value={'6'}>Verified</option>
                                                        <option key={''} value={'4'}>Closed</option>
                                                        <option key={''} value={'5'}>Reject</option>

                                                    </Form.Control>
                                                    <Form.Control.Feedback type="invalid">
                                                        {errors.task_state}
                                                    </Form.Control.Feedback>
                                                </Form.Group>
                                            </> : <></>
                                    }
                                    {
                                        localStorage.getItem("taskState") === "view" ? <></> :
                                            localStorage.getItem("taskState") === "ongoing" ? <></> :
                                                <>
                                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik02">
                                                        <Form.Label>State</Form.Label>
                                                        <Form.Control
                                                            as="select"
                                                            placeholder="Assigned to"
                                                            name="task_state"
                                                            value={values.task_state}
                                                            onChange={handleChange}
                                                            isInvalid={!!errors.task_state}
                                                        >
                                                            <option key={'empty'} value={''}>Select State</option>
                                                            {
                                                                localStorage.getItem("taskState") === "in-progress" ? 
                                                                <>
                                                                    {/* <option key={''} value={'1'}>In Progress</option> */}
                                                                    <option key={''} value={'7'}> Complete</option>
                                                                    <option key={''} value={'1'}> Incomplete</option>
                                                                </> : <></> 
                                                            }
                                                            {

                                                                localStorage.getItem("taskState") === "approved" ?
                                                                    <>
                                                                        <option key={''} value={'6'}>Approved</option>
                                                                        {/* <option key={''} value={'4'}>Closed</option> */}
                                                                        <option key={''} value={'1'}>Reject</option>
                                                                    </>
                                                                    : <></> 
                                                            }


                                                        </Form.Control>
                                                        <Form.Control.Feedback type="invalid">
                                                            {errors.task_state}
                                                        </Form.Control.Feedback>
                                                    </Form.Group>
                                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik03">
                                                        <Form.Label>Delegate</Form.Label>
                                                        <Form.Control
                                                            as="select"
                                                            placeholder="Reported to"
                                                            name="delegate"
                                                            value={values.delegate}
                                                            onChange={handleChange}
                                                            isInvalid={!!errors.delegate}
                                                        >
                                                            <option key={''} value={''}>Select Type</option>
                                                            {
                                                                delegate === undefined ? delegate.map((item, key) => <option key={key} value={item.emp_id}>{item.emp_name}</option>) : <></>
                                                            }
                                                        </Form.Control>
                                                        <Form.Control.Feedback type="invalid">
                                                            {errors.delegate}
                                                        </Form.Control.Feedback>
                                                    </Form.Group>
                                                    <Form.Group as={Col} className="mb-2" md="6" controlId="validationFormik04">
                                                        <Form.Label>Reminder Date</Form.Label>
                                                        <Form.Control
                                                            type="datetime-local"
                                                            placeholder="Reminder Date"
                                                            name="reminder_date"
                                                            value={values.reminder_date}
                                                            onChange={handleChange}
                                                            isInvalid={!!errors.reminder_date}
                                                        />
                                                        <Form.Control.Feedback type="invalid">
                                                            {errors.reminder_date}
                                                        </Form.Control.Feedback>
                                                    </Form.Group>
                                                    <Button type="submit">Submit form</Button>
                                                </>
                                    }
                                </Row>
                            </Form>
                        )}
                    </Formik>
                </div>
            </div>

        </>
    )
}
