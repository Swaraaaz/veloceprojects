import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'
import high from '../../../img/high.png'
import Moderate from '../../../img/Moderate.png'
import low from '../../../img/low.png'
import { useHistory } from 'react-router';
import Moment from 'moment';
import { Modal, Button, Form, Col, Row } from "react-bootstrap";  


export default function AllTasks(props) {

  const [days, setDays] = useState(0)
  const [taskStartDate, setTaskStartDate] = useState('')


  const [attachment, setattachment] = useState();
  const [responsiblePerson,setResponsiblePerson]=useState([])
  const [assignedTo, setAssignedTo] = useState([])
  const [reportedTo, setReportedTo] = useState([])
  // const [attachment, setattachment] = useState();

  const [updateTask,setUpdateTask]=useState({
    task_id:"",
    task_title:"",
    assign_to_name:"",
    project_id:"",
    priority:"",
    responsible_person:"",
    task_start_date:"",
    task_finish_date:"",
    total_task_date:"",
    reminder:"",
    reminder_reponsible_person:"",
  });

  const deleteHandle = (e, row) => {
    e.preventDefault()
    // axios.post('http://localhost/php/new/employee/dismissEmp.php', { dismiss_emp_id: row.emp_id, emp_id: localStorage.getItem("emp_id"), role_id: localStorage.getItem("role_id") }).then(() => {
    //   axios.get('http://localhost/php/new/employee/allActiveEmployees.php').then(res => {
    //     //Storing users detail in state array object
    //     setRow(res.data);
    //   });
    // })
  }

  useEffect(() => {

    axios.get('http://localhost/php/new/tasks/getAllEmployee.php').then((resp) => setAssignedTo(resp.data))
    axios.get('http://localhost/php/new/tasks/getReportedemployee.php').then((resp) => setReportedTo(resp.data))
    axios.get('http://localhost/php/new/tasks/getResponsiblePerson.php').then((resp) => setResponsiblePerson(resp.data))
  }, [])



  //Modal
  const [showModal, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);


  const history = useHistory()
  const viewHandle = (e, row) => {
    e.preventDefault()
    let state0 = 0
    if (row.state === "Approved") {
      state0 = "6"
    } else if (row.state === "Closed Approved") {
      state0 = "4"
    } else if (row.state === "New") {
      state0 = "0"
    } else if (row.state === "In Progress") {
      state0 = "1"
    } else if (row.state === "Closed Rejected") {
      state0 = "5"
    } else if (row.state === " Complete") {
      state0 = "2"
    } else if (row.state === "Incomplete") {
      state0 = "3"
    }
    localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
    localStorage.setItem("taskState", "view")
    history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
  }

  // const editHandle = (e, row) => {
  //   e.preventDefault()
  //   props.setTaskId(row.task_id)

  //   axios.post(
  //     "http://localhost/php/new/tasks/getTaskByID.php",
  //     { task_id: row.task_id, emp_id: localStorage.getItem("emp_id") }).then((resp) => {
  //       props.setEditData(resp.data[0])
  //       // localStorage.setItem("editData", JSON.stringify(resp.data[0]))
  //       console.log("A");
  //       // setTimeout(() => {
  //       props.setOpen1(true)
  //       // }, 1000);
  //     })
  // }

  const calDays = (e) => {
    const [year, month, days] = updateTask.task_start_date.split('-') //Task start date
    const [year2, month2, days2] = e.target.value.split('-') //Task end date
    const start = new Date(month + "/" + days + "/" + year)
    const end = new Date(month2 + "/" + days2 + "/" + year2)
    var Difference_In_Time = end.getTime() - start.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    setDays(Difference_In_Days)
    setUpdateTask({ ...updateTask, total_task_date: Difference_In_Days,task_finish_date:e.target.value })
    //setUpdateTask({ ...updateTask, task_finish_date: e.target.value })
  }

  const columns = [
    { title: "Task Name", field: "task_title", width: "10%",
    render: (params) => {
      return (
        <div className="task_title" onClick={(e) => viewHandle(e, params)}>
          {params.task_title}
        </div>
      );
    }},
    { title: "Project Name", field: "project_name" },
    { title: "Due date", field: "due_date",
    render:(params)=>{
      return(
        <div>
            {Moment(params.due_date).format('DD-MM-YYYY') }
        </div>
      )
    }   },
    { title: "Assigned to", field: "emp_name" },
    {
      title: "Priority", field: "priority",
      render: (params) => {
        return (
          <div className="priority">
            {
              params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
                params.priority === "High" ? <img src={high} alt="High" /> :
                  params.priority === "Low" ? <img src={low} alt="Low" /> :
                    <></>
            }
          </div>
        );
      }
    },

    {
      title: "Status", field: "state",
      render: (params) => {
        return (
          <div className="">
            {
              params.state === "Approved" ? <span className='verified'>Verified</span> :
                params.state === "Closed Approved" ? <span className='RejectedRejectedRejectedRejected'>Closed</span> :
                  params.state === "New" ? <span className='new'>New</span> :
                    params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                      params.state === "Closed Rejected" ? <span className='Rejected'>Rejected</span> :
                        params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
            }
          </div>
        );
      }
    },
    {
      title: "", field: "",
      render: (params) => {
        return (
          <div className="">
            <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
              onClick={(e) => viewHandle(e, params)}
            >
              <i className="bi bi-eye-fill" style={{ color: 'blue' }}></i>
            </button>

            <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
               onClick={(e) => editHandle(params)} 
            >
              <i className="bi bi-pencil-square" style={{ color: 'blue' }}></i>
            </button>
            {/* <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
              onClick={(e) => deleteHandle(e, params)}
            >
              <i className="bi bi-trash-fill" style={{ color: 'red' }}></i>
            </button> */}
          </div>
        );
      }
    }
  ];

  const [row, setRow] = useState([])
  useEffect(() => {
    const interval=setInterval(() => {
    axios
      .get("http://localhost/php/new/tasks/allTasks.php")
      .then((resp) => {
        setRow(resp.data)
        console.log(resp.data)
      })
     }, 1000);
     return ()=>clearInterval(interval);
  },[])


  const onInputChange = (e) => {
    setUpdateTask({ ...updateTask, [e.target.name]: e.target.value })
}

const uploadattachment = (e) => {
  setattachment(e.target.files[0]);
};

const onModalFormSubmit=(e)=>{
  e.preventDefault()
  axios.post("http://localhost/php/new/tasks/updateTask.php",updateTask)
  .then((res) => {

            const modalFormData = new FormData();
            modalFormData.append("file[]", attachment);
            modalFormData.append("task_id", updateTask.task_id);
            modalFormData.append("linkforfile",'NULL');
            modalFormData.append("project_id", updateTask.project_id); //Project ID
            // alert(JSON.stringify(modalFormData))
            axios
              .post(
                "http://localhost/php/new/tasks/uploadAttchments.php",
                modalFormData
              ).then((resp) => {
              })


      handleClose()


      axios.get("http://localhost/php/new/tasks/allTasks.php")
          .then((res) => {
            setRow(res.data);
          })
        
  })
  console.log(updateTask)
}




const editHandle=(row)=>{
  // e.preventDefault()
  console.log(row);
  const [year, month, days] = row.task_start_date.split('-') //Task start date
  const [year2, month2, days2] = row.due_date.split('-') //Task end date
  const start = new Date(month + "/" + days + "/" + year)
  const end = new Date(month2 + "/" + days2 + "/" + year2)
  var Difference_In_Time = end.getTime() - start.getTime();
  var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
  setDays(Difference_In_Days)

  
  handleShow();
  setUpdateTask({
    task_id:row.task_id,
    task_title: row.task_title,
    assign_to:row.assign_to,
    assign_to_name:row.emp_name,
    project_id:row.project_id,
    project_name:row.project_name,
    priority:row.priority,
    reported_to:row.reported_to,  //Kapil_desai
    responsible_person:row.responsible_person, //Kapil Desai's ID
    task_start_date:row.task_start_date,
    task_finish_date:row.due_date,
    total_task_date:Difference_In_Days,
    reminder:row.reminder_date,
    reminder_reponsible_person:row.reminder_reponsible_person, //ID
    reminder_reponsible_person_name:row.reminder_reponsible_person_name, //Name
})
}



  return (
    <>
      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header>
          <Modal.Title>Update Task</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {/* <form>
           <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Name :</label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="project_name" placeholder="Enter Project Name" aria-label="default input example" 
              />
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Category: </label>
            <div class="col-sm-10">
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Email Id: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="client_email" placeholder="Enter Client's Email Id" aria-label="default input example" 
              />
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Contact Number: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="contact_number" placeholder="Enter Client's Contact Number" aria-label="default input example"
                />
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Site Address: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="site_address" placeholder="Enter Client's Address" aria-label="default input example" 
               />
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Start date: </label>
            <div class="col-sm-3">
              <input type="date" class="form-control" name="estimated_start_date" placeholder="Last name" aria-label="Last name"
               />
            </div>
            <label for="staticName" class="col-sm-3  col-form-label" style={{ marginLeft: '5px' }}>Estimated end date: </label>
            <div class="col-sm-3">
              <input type="date" name="estimated_end_date" class="form-control" placeholder="Last name" aria-label="Last name" 
               />
            </div>
          </div>
          
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Description :</label>
            <div class="col-sm-10">
              <textarea class="form-control" type="text" name="project_description" placeholder="Project Description" aria-label="default input example" rows="3"
               />
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
          </form> */}
          <Form onSubmit={onModalFormSubmit} >
                <Row className="mb-3">
                  {/* Task Name */}
                  <Form.Group as={Col} md="6" >
                    <Form.Label>Task Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Task Name"
                      name="task_title"
                      defaultValue={updateTask.task_title}
                      onChange={onInputChange}
                    />

                    
                  </Form.Group>
                  {/* Assigned To */}
                  {/* <Form.Group as={Col} md="6" >
                    <Form.Label>Assign to</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Assign to"
                      name="assign_to"
                      onChange={onInputChange}
                      defaultValue={updateTask.assign_to}
                    >
                      <option key={'empty'} value={''}>Select Assign to  </option>
                    {assignedTo.map((item, key) => {
                      return (
                    <option key={key} value={item.emp_id}>{item.empname}</option>
                  );
                })}
                    </Form.Control>
                  </Form.Group> */}

              <Form.Group as={Col} md="6" controlId="validationFormik06">
                    <Form.Label>Assign to</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="Assign to"
                      name="assign_to"
                      value={updateTask.assign_to}
                      onChange={onInputChange}
                      // defaultValue={updateTask.assign_to}
                      // isInvalid={!!errors.assign_to}
                    >
                      <option key={'empty'} value={''}>{updateTask.assign_to_name}</option>
                      {assignedTo.map((item, key) => {
                        return (
                          <option key={key} value={item.emp_id}>{item.empname}</option>
                        );
                      })}
                    </Form.Control>
                    {/* <Form.Control.Feedback type="invalid">
                      {errors.assign_to}
                    </Form.Control.Feedback> */}
             </Form.Group>




                  {/* Project Name */}
                  <Form.Group as={Col} md="6" controlId="validationFormik09">
                    <Form.Label>Project Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Project Name"
                      name="project_name"
                      onChange={onInputChange}
                      defaultValue={updateTask.project_name}
                      disabled
                    >
                     
                    </Form.Control>
                   
                  </Form.Group>
                  {/* Priority */}
                  <Form.Group as={Col} md="6" controlId="validationFormik10">
                    <Form.Label>Priority</Form.Label>
                    <Form.Control
                      // type="text"
                      as="select"
                      placeholder="Priority"
                      name="priority"
                      onChange={onInputChange}
                      defaultValue={updateTask.priority}
                    >
                      {/* <option key={'empty'} value={''}>{updateTask.priority}</option> */}
                   
                        <option value='High'>High</option>
                        <option value='Low'>Low</option>
                        <option value='Moderate'>Moderate</option>
                     
                    </Form.Control>
                    
                  </Form.Group>
                  {/* Reported To */}
                  {/* <Form.Group as={Col} md="6" controlId="validationFormik11">
                    <Form.Label>Reported To</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Reported To"
                      name="responsible_person"
                      onChange={onInputChange}
                      defaultValue={updateTask.responsible_person}
                    >
                    </Form.Control>
                  </Form.Group> */}

            <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>Reported To</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="Reported To"
                    name="responsible_person"
                    value={updateTask.responsible_person}
                    onChange={onInputChange}
                    // isInvalid={!!errors.responsible_person}
                  >
                    <option key={'empty'} value={''}>{updateTask.reported_to}</option>
                    {reportedTo.map((item, key) => {
                      return (
                        <option key={key} value={item.emp_id}>{item.empname}</option>
                      );
                    })}
                  </Form.Control>
            </Form.Group>
                 


                  {/* Attachment */}
                  <Form.Group as={Col} md="6" controlId="validationFormik03">
                    <Form.Label>Attachment</Form.Label>
                    <Form.Control
                      type="file"
                      onChange={(e) => uploadattachment(e)}
                      // defaultValue={updateTask.task_title}
                      name="attachments"
                    />
                  </Form.Group>
                  {/* Task start date */}
                  <Form.Group as={Col} md="4" >
                    <Form.Label>Task start date</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Task start date"
                      name="task_start_date"
                      onChange={(e)=>{
                        onInputChange(e)
                        setTaskStartDate(e.target.value)
                      }
                      }
                      // value={updateTask.task_start_date}
                      defaultValue={updateTask.task_start_date}
                      
                    />
                    
                  </Form.Group>
                  {/* Task finish date */}
                  <Form.Group as={Col} md="4" >
                    <Form.Label>Task finish date</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Task finish date"
                      name="task_finish_date"
                      // onChange={onInputChange}
                      onChange={(e)=>{
                        onInputChange(e)
                       // setDays(3)
                        calDays(e)
                      }}
                      // value={updateTask.task_finish_date}
                      defaultValue={updateTask.task_finish_date}
                    />
                    
                  </Form.Group>
                  {/* Task Duration Days */}
                  <Form.Group as={Col} md="4" >
                    <Form.Label>Task duration days</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Task durations in days"
                      name="total_task_date"
                      value={days}
                      
                      // onChange={(e)=>{
                      //   onInputChange(e)
                      //   setDays(e)
                      // }}
                      // defaultValue={updateTask.total_task_date}
                      disabled
                     
                    />
                   
                  </Form.Group>
                  {/* Set reminder */}
                  <Form.Group as={Col} md="6" controlId="validationFormik07">
                    <Form.Label>Set reminder</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Set remainder"
                      onChange={onInputChange}
                      defaultValue={updateTask.reminder}
                      name="reminder"
                    />
                    
                  </Form.Group>

                  {/* Reponsible person */}
                  {/* <Form.Group as={Col} md="6" controlId="validationFormik11">
                    <Form.Label>Reponsible person</Form.Label>
                    <Form.Control
                     type="text"
                      placeholder="Reponsible person"
                      name="reminder_reponsible_person"
                      onChange={onInputChange}
                      defaultValue={updateTask.reminder_reponsible_person}
                    >
                      
                    </Form.Control>
                    
                  </Form.Group> */}

              {/* <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>Responsible To</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="Responsible Person"
                    name="reminder_responsible_person"
                    value={updateTask.reminder_reponsible_person}
                    onChange={onInputChange}
                    // isInvalid={!!errors.responsible_person}
                  >
                    <option key={'empty'} value={''}>{updateTask.reminder_reponsible_person_name}</option>
                    {responsiblePerson.map((item, key) => {
                      return (
                        <option key={key} value={item.emp_id}>{item.empname}</option>
                      );
                    })}
                  </Form.Control>
            </Form.Group> */}

          <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>Responsible Person</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="Responsible Person"
                    name="reminder_reponsible_person"
                    value={updateTask.reminder_reponsible_person}
                    onChange={onInputChange}
                    // isInvalid={!!errors.responsible_person}
                  >
                    <option key={'empty'} value={''}>{updateTask.reminder_reponsible_person_name}</option>
                    {responsiblePerson.map((item, key) => {
                      return (
                        <option key={key} value={item.emp_id}>{item.empname}</option>
                      );
                    })}
                  </Form.Control>
            </Form.Group>
            

                </Row>
                <Button type="submit">Submit form</Button>
              </Form>
        </Modal.Body>
        {/* <Modal.Footer>
          
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>

        </Modal.Footer> */}
      </Modal>
      <MaterialTable title="All Tasks" icons={tableIcons} columns={columns} data={row} />
    </>
  )
}
