import React, { useState } from 'react'
import { Paper, Tab, Tabs } from '@material-ui/core'
import Task from './Reports/Task'
import Projects from './Reports/Projects'
import Employee from './Reports/Employee'

export default function Report() {
  const [value, setValue] = useState(0)
  const [insertData, setInsertData] = useState({
    to_date: '',
    from_date: '',
  })

  const handleChange = (e) => {
    setInsertData({ ...insertData, [e.target.name]: e.target.value });
  }
  const onSubmit = (e)=>{
    e.preventDefault()
  }
  return (
    <>
      <div className="card">
        <div className="card-body">
          <br></br>
          <form onSubmit={onSubmit}>
            <div className="form-group p col-md-15 row">
              <div className="col-md-1">
                <label htmlFor="exampleInputEmail1" >From date<span class="asterisk" aria-hidden="true"></span>  </label>
              </div>
              <div className="col-md-5">
                <input
                  className='form-control'
                  type="date"
                  id="from_date"
                  name="from_date"
                  onChange={handleChange}
                  style={{ border: "1px solid #ced4da", padding: "0.175rem 0.66rem", fontSize: "0.87rem" }}

                  required />
              </div>
              <div className="col-md-1">
                <label htmlFor="exampleInputPassword1">To date<span class="asterisk" aria-hidden="true"></span></label>
              </div>
              <div className="col-md-5">
                <input
                  className='form-control'
                  type="date"
                  id="to_date"
                  name="to_date"
                  onChange={handleChange}
                  placeholder="Select date"
                  style={{ border: "1px solid #ced4da", padding: "0.175rem 0.66rem", fontSize: "0.87rem" }}

                  required />
              </div>
              
            </div>

            <br></br>

          </form>
          <div className="card">
            <div className="card-body">
              <Paper style={{ justifyContent: 'space-between', display: 'flex' }}>
                <Tabs
                  value={value}
                  textColor="primary"
                  indicatorColor="primary"
                  onChange={(event, newValue) => {
                    setValue(newValue)
                  }}
                >
                  <Tab label="Projects" />
                  <Tab label="Employee" />
                  <Tab label="Task" />
                </Tabs>
              </Paper>
              {
                value === 0 ? <Projects proj = {insertData}/> :
                  value === 1 ? <Employee emp = {insertData}/> :
                    value === 2 ? <Task ta = {insertData} /> : <></>
              }
            </div>
          </div>
        </div>
      </div>
      {/* {
        data ? loading ? <div className='progress'><CircularProgress /> </div> : <MaterialTable
          title="Project report"
          icons={tableIcons}
          columns={columns}
          data={data}
          options={{
            exportButton: true,
          }}
        /> : <></>
      } */}
    </>
  )

}
