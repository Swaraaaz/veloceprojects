import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Modal } from 'react-bootstrap'
import './Tasks/deadline.css'

export default function Notification(props) {
    const [data, setData] = useState([])
    useEffect(() => {
        axios.post("http://localhost/php/pms/tasks/getAllOverdueTasks.php", { emp_id: localStorage.getItem("emp_id") }).then((resp) => {
            setData(resp.data)
        })
    }, [])

    return (
        <Modal
            show={props.show}
            onHide={props.handleClose}
            backdrop="static"
            keyboard={false}
        >
            <Modal.Header >
                <Modal.Title>Overdue Notification</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <div className="row" >
                    {
                        data.map((item, key) => {
                            return (
                                <div className="col-6">
                                    <div className="card deadline-title" style={{ color: 'black', textTransform: "none", borderTop: '3px solid red' }} key={key}>
                                        <div className="row">
                                            <div className="col-4">
                                                <h5>Task Name:</h5> <br />
                                            </div>
                                            <div className="col-8">
                                                <h5 style={{textTransform: 'capitalize !important'}}>{item.task_title}</h5><br />
                                            </div>
                                            <div className="col-4">
                                                <h6>Project Name: </h6> <br />

                                            </div>
                                            <div className="col-8">
                                                {item.project_name}<br />

                                            </div>
                                            <div className="col-4">
                                                <span>Due Date:</span> <br />
                                            </div>
                                            <div className="col-8">
                                                <span style={{ background: 'red', color: 'white' }}>{item.task_finish_date}<br /></span>
                                            </div>
                                        </div>
                                    </div>
                                    </div>
                            )
                        })
                    }
                </div>
                {/* <div className="card">
                    <h1>Demo</h1>
                </div> */}
            </Modal.Body>
            <Modal.Footer>
                <button type='button' className='btn btn-secondary' onClick={props.handleClose}>
                    Close
                </button>
            </Modal.Footer>
        </Modal >
    )
}
