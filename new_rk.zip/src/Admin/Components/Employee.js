import React, { useState } from 'react'
// import { Button, Modal } from 'react-bootstrap'
import Active from './Employee/Active'
import AllEmployees from './Employee/AllEmployees'
import CreateEmployee from './Employee/CreateEmployee'
import Inactive from './Employee/Inactive'
import { Paper, Tab, Tabs } from '@material-ui/core'

export default function Employee() {
  const [value, setValue] = useState(0)
  const [open, setOpen] = useState(false)
  return (
    <>
      <CreateEmployee open={open} setOpen={setOpen}/>
      <div className="card">
        <div className="card-body">
          <Paper className='tabs-paper'>
            <Tabs
              variant="scrollable"
              value={value}
              textColor="primary"
              indicatorColor="primary"
              onChange={(event, newValue) => {
                setValue(newValue)
              }}
            >
              <Tab label="All Employees" />
              <Tab label="Active" />
              <Tab label="Inactive" />
            </Tabs>
            <button className='btn btn-primary btn-employee' onClick={(e)=>setOpen(true)}>Create New Employee</button>
          </Paper>
          {
            value === 0 ? <AllEmployees /> : 
            value === 1 ? <Active /> : 
            value === 2 ? <Inactive /> : <></>
          }
        </div>
      </div>
    </>
  )

}
