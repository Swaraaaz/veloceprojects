import React from 'react';
import './timer.css'

function DisplayComponent(props) {
    // console.log(props.time)
//   const h = () => {
//      if(props.time.h === 0){
//        return '';
//      }else {
//        return <span>{(props.time.h >= 10)? props.time.h : "0"+ props.time.h}</span>;
//      }
//   }
// console.log(props.time)
  return (
    <>
    <div className="countdown">
        <div className="bloc-time hours" data-init-value={24}>
          <div className="figure hours hours-1">
            <span className="top">{props.time.hour}</span>
            <span className="top-back">
              <span>{props.time.hour}</span>
            </span>
            <span className="bottom">{props.time.hour}</span>
            <span className="bottom-back">
              <span>{props.time.hour}</span>
            </span>
          </div>
        </div>
        <div className="bloc-time min" data-init-value={0}>
          <div className="figure min min-1">
            <span className="top">{props.time.minutes}</span>
            <span className="top-back">
              <span>{props.time.minutes}</span>
            </span>
            <span className="bottom">{props.time.minutes}</span>
            <span className="bottom-back">
              <span>{props.time.minutes}</span>
            </span>        
          </div>
        </div>
        <div className="bloc-time sec" data-init-value={0}>
          <div className="figure sec sec-1">
            <span className="top">{props.time.seconds}</span>
            <span className="top-back">
              <span>{props.time.seconds}</span>
            </span>
            <span className="bottom">{props.time.seconds}</span>
            <span className="bottom-back">
              <span>{props.time.seconds}</span>
            </span>          
          </div>
        </div>
      </div>
    </>
  );
}

export default DisplayComponent;