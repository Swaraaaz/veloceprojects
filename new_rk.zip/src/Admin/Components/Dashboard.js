
import axios from 'axios';
import MaterialTable from 'material-table';
import React, { useState, useEffect } from 'react';
import tableIcons from "../MaterialTableIcons";
import { useHistory } from 'react-router';
import Moment from 'moment';

export default function Dashboard() {
  // const [dashboardCount, setDashboardCount] = useState({
  //   total_projects: 0,
  //   completed_projects: 0,
  //   ongoing_projects: 0,
  //   not_started_yet: 0
  // })

  const [todaysTask,setTodaysTask]=useState()
  const [empTasks,setEmpTasks]=useState()
  const [activityStream, setActivityStream] = useState()
  const [value, setValue] = useState(0)

  // const [loading1, setLoading1] = useState(true)
  // const [loading2, setLoading2] = useState(true)

  const history = useHistory()

  const goToTask = (e, row) => {
    e.preventDefault()
    localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
    if (row.state === "In Progress" || row.state === "New" || row.state === "Incomplete")
      localStorage.setItem("taskState", "in-progress")
    else
      localStorage.setItem("taskState", "view")

    const obj1 = new Date()
    localStorage.setItem("currentTime", obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds())
    let state0 = 0
    if (row.state === "Approved") {
      state0 = "3"
    } else if (row.state === "Closed Approved") {
      state0 = "4"
    } else if (row.state === "New") {
      state0 = "0"
    } else if (row.state === "In Progress") {
      state0 = "1"
    } else if (row.state === "Closed Rejected") {
      state0 = "5"
    } else if (row.state === " Complete") {
      state0 = "2"
    } else if (row.state === "Incomplete") {
      state0 = "3"
    }
    history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
  }


  const goToEmp = (e, row) => {
    e.preventDefault();
    console.log(row)
    history.push("/Emp_status/" + row.emp_id, {emp_id: row.emp_id })

  }


  const [data, setData] = useState()
  const columns = [
    // {showTitle:"false"},
    { 
      title: "Employee", 
      field: "fullname", 
      align: "jusify", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem'},
      render: (params) => {
        return (
          <div className="project_title" onClick={(e) => goToEmp(e, params)}>
            {params.fullname}
          </div>
        );
      }

  },

    { title: "Task", field: "task_title", align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem' } },
    { title: "Project", field: "project_name", align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem' } },
    { title: "Due Date", field: "due_date", align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem' },
    render:(params)=>{
      return(
        <div>
            {Moment(params.due_date).format('DD-MM-YYYY') }
        </div>
      )
    }  
  
  },
    { title: "Status", field: "state", align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem' },
    render: (params) => {
      return (
        <div className="">
          {
            params.state === "Approved" ? <span className='verified'>Verified</span> :
              params.state === "Closed Approved" ? <span className='Closed'>Closed</span> :
                params.state === "New" ? <span className='new'>New</span> :
                  params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                    params.state === "Incomplete" ? <span className='in-progress'>Incomplete</span> :
                      params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
          }
        </div>
      );
    }
  },
  ];

  useEffect(() => {
    axios
      .post("http://localhost/php/new/dashboard/get_project_list.php", { emp_id: localStorage.getItem("emp_id") })
      .then((resp) => {
        setData(resp.data)
        console.log(resp.data);
      })
  }, [])

  useEffect(() => {
    axios.post('http://localhost/php/new/dashboard/getEmpTasksById.php', { emp_id: localStorage.getItem("emp_id") }).then(res => {
      //Storing users detail in state array object
      if (res.data === null) {
        setActivityStream([])
      } else {
        setActivityStream(res.data)
      }
    });
  }, [])

  useEffect(()=>{
    axios.post('http://localhost/php/new/dashboard/todaysTaskCount.php', { emp_id: localStorage.getItem("emp_id") })
    .then(res => {
      setTodaysTask(res.data[0])
      console.log("Task count",todaysTask)
      })
  },[])

  console.log(activityStream)

  const column2 = [{
    title: "Task",
    field: "task_title",
    render: (params) => {
      return (
        <div className="task_title" onClick={(e) => goToTask(e, params)}>
          {params.task_title}
        </div>
      );
    }
  },
  {
    title: "Project",
    field: "project_name",
  
  },
  {
    title: "Due date",
    // field: "history_status",
    field: "due_date",
    render:(params)=>{
      return(
        <div>
            {Moment(params.due_date).format('DD-MM-YYYY') }
        </div>
      )
    }  
  },
  {
    title: "Status", field: "state",
    render: (params) => {
      return (
        <div className="">
          {
            params.state === "Approved" ? <span className='verified'>Verified</span> :
              params.state === "Closed Approved" ? <span className='Closed'>Closed Approved</span> :
                params.state === "New" ? <span className='new'>New</span> :
                  params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                    params.state === "Incomplete" ? <span className='in-progress'>Incomplete</span> :
                      params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
          }
        </div>
      );
    }
  },
  ]

  const column1 = [{
    title: "Serial no",
    field: "role_id",
    render: (data) => {
      return (data.tableData.id + 1)
    }
  },
  {
    title: "Task Name",
    field: "task_name",
  },
  {
    title: "Status",
    field: "status",
  },
  ]


  return (
    <>
    <div style={{display:'flex'}}>

      <div className='left-div' style={{flex:'1',marginLeft:'3%',textAlign:'center',width:'30%'}}>
        <b style={{fontSize:'2.2rem'}}>Welcome {localStorage.getItem("name")}</b>
        <br></br>
        <lable style={{color:'gray'}}>You have {todaysTask===undefined?"":todaysTask.today_task} tasks for today</lable>
      </div>

      <div className='right-div' style={{flex:'1',width:'70%',textAlign:'left'}}>
       <img src='img/RK_dashboard.png' width='400' height='120'/>
      </div>
    </div>
    <h5 style={{color:'#1E90FF',marginLeft:'20px'}}>Assigned to me</h5>
      <MaterialTable
        title="Activity Streams"
        icons={tableIcons}
        columns={column2}
        variant="scrollable"
        style={{ margin: '20px' }}
        value={value}
        textColor="primary"
        indicatorColor="primary"
        data={activityStream}
        options={{
          exportButton: true,
          toolbar:false,
          rowStyle:{height:'30px'}
        }}
        
      />
    <h5 style={{color:'#1E90FF',marginLeft:'20px'}}>Recently assigned</h5>

      <MaterialTable
        title="Projects"
        variant="scrollable"
        style={{ margin: '20px' }}
        icons={tableIcons}
        columns={columns}
        value={value}
        textColor="primary"
        indicatorColor="primary"
        data={data}
        options={{
          exportButton: true,
          toolbar:false,
        }}
      />
    </>
  );
}
