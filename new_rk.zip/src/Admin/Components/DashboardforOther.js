
import { PieChart, Pie } from 'recharts';
import Container from '@material-ui/core/Container';
import React, { useEffect, useState } from 'react';
import MaterialTable from 'material-table';
import tableIcons from "../MaterialTableIcons";
import { useHistory } from 'react-router';
import axios from 'axios';
import Moment from 'moment';
import high from './Tasks/CreateTasks/img/high.png'
import Moderate from './Tasks/CreateTasks/img/Moderate.png'
import low from './Tasks/CreateTasks/img/low.png'

// export default function DashboardforOther() {
const DashboardforOther = () => {

  // const [empTopTask,setEmpTopTask]=useState({
  //   task_id:"",
  //   task_title:"",
  //   project_id:"",
  //   project_name:"",
  //   due_date:"",
  //   priority:"",
  //   state:"",
  // });

  const [activityStream, setActivityStream] = useState();

  useEffect(() => {
    axios.post('http://localhost/php/new/dashboard/getEmpTasksById.php', { emp_id: localStorage.getItem("emp_id") }).then(res => {
      //Storing users detail in state array object
      if (res.data === null) {
        setActivityStream([])
      } else {
        setActivityStream(res.data)
      }
    });
  }, [])

  const renderCustomizedLabel = ({
    x, y, name
  }) => {
    return (
      <text x={x} y={y} fill="black" textAnchor="end" dominantBaseline="central">
        {name}
      </text>
    );
  };


  const [taskCount,setTaskCount]=useState();
useEffect(()=>{
  console.log("Hello")
  axios
    .post("http://localhost/php/new/tasks/getEmpTaskCounter.php", {emp_id: localStorage.getItem("emp_id") })
    .then((resp) => {
      setTaskCount(resp.data[0])
      console.log("Hello I am here counter",resp.data[0])
    })
},[])

  // Sample data
  const data = [
    {name: taskCount===undefined?[]:taskCount.Not_Started, students: parseInt(taskCount===undefined?[]:taskCount.Not_Started),fill: '#1c96ff'},
    {name: taskCount===undefined?[]:taskCount.Ongoing, students:parseInt(taskCount===undefined?[]:taskCount.Ongoing) ,fill: '#0c5493'},
    {name: taskCount===undefined?[]:taskCount.Completed, students: parseInt(taskCount===undefined?[]:taskCount.Completed),fill: '#0578db'},
  
  ];


  const options = {

    legend: { position: "top" },
    chartArea: { width: "50%" },
    chartArea: { height: "20%" },
    colors: ["#FFB782", "#82E29D"],
    isStacked: true,

  };

  // API for getting top four tasks of employee > High
  // useEffect(()=>{
  //   console.log("Hello")
  //   axios
  //     .post("http://localhost/php/new/employee/empTopFourTask.php", {emp_id: localStorage.getItem("emp_id") })
  //     .then((resp) => {
  //       setEmpTopTask(resp.data)
  //       console.log("Hello I am here",resp.data)
  //     })
  // },[])




  const history = useHistory()
  const goToTask = (e, row) => {
    e.preventDefault()
    localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
    if (row.state === "In Progress" || row.state === "New" || row.state === "Incomplete")
      localStorage.setItem("taskState", "in-progress")
    else
      localStorage.setItem("taskState", "view")

    const obj1 = new Date()
    localStorage.setItem("currentTime", obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds())
    let state0 = 0
    if (row.state === "Approved") {
      state0 = "3"
    } else if (row.state === "Closed Approved") {
      state0 = "4"
    } else if (row.state === "New") {
      state0 = "0"
    } else if (row.state === "In Progress") {
      state0 = "1"
    } else if (row.state === "Closed Rejected") {
      state0 = "5"
    } else if (row.state === " Complete") {
      state0 = "2"
    } else if (row.state === "Incomplete") {
      state0 = "3"
    }
    history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
  }

  const column2 = [{
    title: "Task",
    field: "task_title",
    render: (params) => {
      return (
        <div className="task_title" onClick={(e) => goToTask(e, params)}>
          {params.task_title}
        </div>
      );
    }
  },
  {
    title: "Project",
    field: "project_name",
  },
 
  {
    title: "Proirity",
    field: "priority",
    align: "center",
    render: (params) => {
      return (
        <div className="priority">
          {
            params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
              params.priority === "High" ? <img src={high} alt="High" /> :
                params.priority === "Low" ? <img src={low} alt="Low" /> :
                  <></>
          }
        </div>
      );
    }
  },
  {
    title: "Start Date",
    field: "start_date",
    render:(params)=>{
      return(
        <div>
            {Moment(params.start_date).format('DD-MM-YYYY') }
        </div>
      )
    }  
  },
  {
    title: "Due Date",
    field: "due_date",
    render:(params)=>{
      return(
        <div>
            {Moment(params.due_date).format('DD-MM-YYYY') }
        </div>
      )
    }  
  },
  {
    title: "Status", field: "state",
    render: (params) => {
      return (
        <div className="">
          {
            params.state === "Approved" ? <span className='verified'>Verified</span> :
              params.state === "Closed Approved" ? <span className='Closed'>Closed</span> :
                params.state === "New" ? <span className='new'>New</span> :
                  params.state === "In Progress" ? <span className='in-progress'>In Progress</span> :
                    params.state === "Incomplete" ? <span className='in-progress'>Incomplete</span> :
                      params.state === " Complete" ? <span className='completed'>Complete</span> : <></>
          }
        </div>
      );
    }
  },
  ]

  const [value, setValue] = useState(0)


  //Bar Chart
  const state = {
    labels: ['January', 'February', 'March',
             'April', 'May'],
    datasets: [
      {
        label: 'Rainfall',
        backgroundColor: 'rgba(75,192,192,1)',
        borderColor: 'rgba(0,0,0,1)',
        borderWidth: 2,
        data: [65, 59, 80, 81, 56]
      }
    ]
  }

 
  return (
<>
    <div class="" style={{padding:"30px",height:'100%',overflow:'scroll'}}>
      

<div className="containerrr">
        <div className="area1" style={{alignContent:'center',width:'100%'}}>
            <Container maxWidth="sm">

              <div className='row' style={{width:'100%',margin:'0 auto',position:'relative'}}>
                <PieChart width={230} height={230}>
                <Pie data={data}  dataKey="students" outerRadius={80} innerRadius={50} isAnimation={false} label={renderCustomizedLabel} nameKey="name"/>
                </PieChart>
            
                {/* <div className='' style={{backgroundColor:'red',width:'100%',textAlign:'left'}}> */}
                <ul className='list-grpup'>
                
                    <li className="list-group-item"><i className='bx bxs-square' style={{color:"#0578DB"}}/> Completed: </li>
                    <li className="list-group-item "><i className='bx bxs-square' style={{color:"#0C5493"}}/> Ongoing</li>
                    <li className="list-group-item"><i className='bx bxs-square'style={{color:"#1C96FF"}}/> Not Started:</li>
                
                </ul>
                {/* </div> */}
            </div>
            </Container>
        </div>



      {/* -----------------------------Employee High Priority Task's here--------------------------------- */}
        <div className="col1">
                <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Task Title</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Project Name</h6>
                  <p className="card-text">Due Date:</p>
                  <p className="card-text">Priority:</p>
                </div>
              </div>
        </div>


        <div className="col2">
        <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Task Name</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Project Name</h6>
                  <p className="card-text">Due Date:</p>
                  <p className="card-text">Priority:</p>
                </div>
              </div>
        </div>

        <div className="col3">
        <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Task Name</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Project Name</h6>
                  <p className="card-text">Due Date:</p>
                  <p className="card-text">Priority:</p>
                </div>
              </div>
        </div>


        <div className="col4">
        <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Task Name</h5>
                  <h6 className="card-subtitle mb-2 text-muted">Project Name</h6>
                  <p className="card-text">Due Date:</p>
                  <p className="card-text">Priority:</p>
                </div>
              </div>
        </div>
      </div>
    </div>


    <MaterialTable
        title="Today's Task "
        icons={tableIcons}
        columns={column2}
        variant="scrollable"
        style={{ marginTop: '2%', maxWidth: '300%' }}
        value={value}
        textColor="primary"
        indicatorColor="primary"
        data={activityStream}
        options={{
          exportButton: true,
        }}
      />

</>

  );
}
export default DashboardforOther;

// import React from "react";
// import Paper from '@material-ui/core/Paper';
// import {
// ArgumentAxis,
// ValueAxis,
// Chart,
// BarSeries,
// } from '@devexpress/dx-react-chart-material-ui';

// export default function DashboardforOther() {
// const App = () => {

// // Sample data
// const data = [
// { argument: 'Monday', value: 30 },
// { argument: 'Tuesday', value: 20 },
// { argument: 'Wednesday', value: 10 },
// { argument: 'Thursday', value: 50 },
// { argument: 'Friday', value: 60 },
// ];
// return (
// 	<Paper>
// 	<Chart
// 	data={data}
// 	>
// 	<ArgumentAxis />
// 	<ValueAxis />

// 	<BarSeries valueField="value" argumentField="argument" />
// 	</Chart>
// </Paper>
// );
// }
// }
// // export default DashboardforOther;



