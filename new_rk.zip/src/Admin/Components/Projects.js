import React, { useEffect, useState } from "react";
import { Paper, Tab, Tabs } from "@material-ui/core";
import "./Tasks/task.css";
import CreateTask from "./Tasks/CreateTask";
import MaterialTable from "material-table";
import tableIcons from "../MaterialTableIcons";
import { useHistory } from 'react-router';
import { Modal, Button, Form } from "react-bootstrap";  
import axios from 'axios'

export default function ProjrctsS() {
  const history = useHistory();

  //const [projectdata,setProjectData]=useState();
  const [projectcat,setProjectCat]=useState();

  const [row, setRow] = useState([]);
  const [projectinfo,setProjectInfo]=useState({
    reporter:localStorage.getItem("emp_id"),
    project_name:"",
    project_category:"",
    client_email:"",
    contact_number:"",
    site_address:"",
    project_description:"",
    estimated_start_date:"",
    estimated_end_date:"",
    status:""
  });

  //Edit Handle State
  const [editProject,setEditProject]=useState({
    project_id:"",
    project_name:"",
    actual_end_date:"",
    status:""
  });

  //Modal
    const [showModal, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    //Edit Handle Modal
    const [showModal2, setShow2] = useState(false);
    const handleClose2 = () => setShow2(false);
    const handleShow2 = () => setShow2(true);

  const [value, setValue] = useState(0);
  const [open, setOpen] = useState(false);
  const [taskId, setTaskId] = useState("");
  const [open1, setOpen1] = useState(false);
  
  const onInputChange = (e) => {
    setProjectInfo({ ...projectinfo, [e.target.name]: e.target.value })
}

const onEditChange =(e)=>{
  setEditProject({...editProject,[e.target.name]:e.target.value})
}

useEffect(()=>{
  axios.get("http://localhost/php/new/project/readProject.php")
    .then((res) => {
      setProjectCat(res.data)
    })
    
  },[])

  //Redirect User to Project Details page where all tasks is shown
  const goToTask = (e, row) => {
    e.preventDefault();
    console.log(row)
    history.push("/Project_status/" + row.project_id, { project_id: row.project_id, emp_id: localStorage.getItem("emp_id") })
  }

const onModalFormSubmit=(e)=>
{
    e.preventDefault();
    axios.post("http://localhost/php/new/project/create_project.php",projectinfo)
    .then((res) => {
        // toast.configure();
        // toast.warning("Updated Successfully");
        axios.get("http://localhost/php/new/project/read_projects.php")
        .then((res) => {
          console.log(res);
          //setProjectData(res.data);
          setRow(res.data.data);
        })
    })
    handleClose();
}
  const columns = [
    { title: "Project Name", field: "project_name",
    render: (params) => {
      return (
        <div className="project_title" onClick={(e) => goToTask(e, params)}>
          {params.project_name}
        </div>
      );
    }
    },
    { title: "Actual start date", field: "estimated_start_date" },
    { title: "Estimated end date", field: "estimated_end_date" },
    {
      title: "Status", field: "status",
      render: (params) => {
        return (
          <div className="">
            {
              params.status === "O" ? <span className='verified'>Ongoing</span> :
              params.status === "N" ? <span className='new'>Not Started</span> :
              params.status === "1" ? <span className='Incompleted'>Incompleted</span> :
              params.status === "2" ? <span className='completed'>Completed</span> :
              params.status === "C" ? <span className='completed'>Completed</span> : <></>
            }
          </div>
        );
      }
    },
    {
      tititle: "", field: "",
      render: (params) => {
        return (  
          <div className="">
      
            <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
               onClick={(e) => editHandle(params)}>
              <i className="bi bi-pencil-square" style={{ color: 'blue' }}></i>
            </button>

              <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
                  onClick={(e) => deleteProject(e, params)}>
                  <i className="bi bi-trash-fill" style={{ color: 'red' }}></i>
                </button>

              {/* Edit Button */}         
            
          </div>
        );
      }
    }
  ];
  

    //Edit Handle

  const editHandle=(row)=>{
    console.log(row)
    handleShow2();
    setEditProject({
      project_id:row.project_id,
      project_name: row.project_name,
  })

  }

  const onModalFormSubmit2=(e)=>
  {
      e.preventDefault();
      axios.post("http://localhost/php/new/project/updateProjectStatus.php",editProject)
      .then((res) => {
        axios.get("http://localhost/php/new/project/read_projects.php")
        .then((res) => {
          console.log(res);
          //setProjectData(res.data);
          setRow(res.data.data);
        })
      })
      handleClose2();
  }


  useEffect(() => {}, []);


  const createProject=()=>{
    handleShow();
  }

  //Read
  useEffect(() => {
    axios.get("http://localhost/php/new/project/read_projects.php")
        .then((res) => {
          console.log(res);
          //setProjectData(res.data);
          setRow(res.data.data);
        })
}, [])

  //Delete
  const deleteProject = (e, row) => {
    // e.preventDefault()
    axios.post("http://localhost/php/new/project/deleteProject.php",{id:row.project_id})
    .then(() => {
      // const interval=setInterval(() => {
      axios.get("http://localhost/php/new/project/read_projects.php")
      .then(res => {
        setRow(res.data.data);
      });
    // }, 1000);
    // return ()=>clearInterval(interval);

    })
  }




  return (
    <>
      <Modal show={showModal} onHide={handleClose}>
        <Modal.Header>
          <Modal.Title>Create Project</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form  onSubmit={onModalFormSubmit}>
           <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Name :</label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="project_name" placeholder="Enter Project Name" aria-label="default input example" 
              onChange={onInputChange}/>
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Category: </label>
            <div class="col-sm-10">
              {/* <input class="form-control" type="text" name="project_category" placeholder="Select Category" aria-label="default input example" 
               onChange={onInputChange}/> */}
              <select className='form-control' name="project_category" required onChange={onInputChange}>
                <option>Select</option>
                  {projectcat === undefined ? [] : projectcat.map((project) => (
                   <option value={project.id} key={project.id}>{project.project_category}</option>
                 ))}
               </select>
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Email Id: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="client_email" placeholder="Enter Client's Email Id" aria-label="default input example" 
               onChange={onInputChange}/>
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Contact Number: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="contact_number" placeholder="Enter Client's Contact Number" aria-label="default input example"
                onChange={onInputChange}/>
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Site Address: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="site_address" placeholder="Enter Client's Address" aria-label="default input example" 
               onChange={onInputChange}/>
            </div>
          </div>
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Start date: </label>
            <div class="col-sm-3">
              <input type="date" class="form-control" name="estimated_start_date" placeholder="Last name" aria-label="Last name"
               onChange={onInputChange} />
            </div>
            <label for="staticName" class="col-sm-3  col-form-label" style={{ marginLeft: '5px' }}>Estimated end date: </label>
            <div class="col-sm-3">
              <input type="date" name="estimated_end_date" class="form-control" placeholder="Last name" aria-label="Last name" 
               onChange={onInputChange}/>
            </div>
          </div>
          
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Description :</label>
            <div class="col-sm-10">
              <textarea class="form-control" type="text" name="project_description" placeholder="Project Description" aria-label="default input example" rows="3"
               onChange={onInputChange}/>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </Modal.Body>
        <Modal.Footer>
          
          <Button variant="primary" onClick={handleClose}>
            Close
          </Button>

        </Modal.Footer>
      </Modal>



     {/* Edit Handle Modal is here  */}
     <Modal show={showModal2} onHide={handleClose2}>
        <Modal.Header>
          <Modal.Title>Edit Project</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form  onSubmit={onModalFormSubmit2}>

           <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Name :</label>
            <div class="col-sm-10">
              <input class="form-control" 
              type="text" 
              name="project_name" 
              placeholder="Enter Project Name" 
              aria-label="default input example" 
              onChange={onEditChange}
              disabled
              defaultValue={editProject.project_name}
              />
              
            </div>
          </div>


          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Project Status : </label>
            <div class="col-sm-10">
              <select className='form-control' name="status" required onChange={onEditChange}>
                <option>Select Status</option>  
                   <option value="2">Completed</option>
                   <option value="1">Incompleted</option>
    
               </select>
            </div>
          </div>

          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Completion Date: </label>
            <div class="col-sm-10">
              <input type="date" class="form-control" name="actual_end_date" 
               onChange={onEditChange} />
            </div>
          </div>

{/* 
          <div class="mb-3 row">
            <label for="staticName" class="col-sm-2 col-form-label">Email Id: </label>
            <div class="col-sm-10">
              <input class="form-control" type="text" name="client_email" placeholder="Enter Client's Email Id" aria-label="default input example" 
               onChange={onEditChange}/>
            </div>
          </div> */}
          <div style={{textAlign:'center'}}>
              <button type="submit" class="btn btn-primary">Submit</button>
          </div>
          </form>
        </Modal.Body>
        <Modal.Footer>
          
          <Button variant="primary" onClick={handleClose2}>
            Close
          </Button>

        </Modal.Footer>
      </Modal>


      <div className="row">
        <div className="col-md-12">
          <div className="card">
            <div
              className="card-header"
              style={{ display: "flex", backgroundColor: "white" }}
            >
              <h3 className="card-title" style={{ color: "#306EFF" }}>
                <b>All Projects</b>
              </h3>

              <div style={{width:'85%',textAlign:'right'}}>
                <button className="btn btn-primary" onClick={createProject}>Create New Project</button>
              </div>


            </div>
            <div className="card-body">
              <div style={{ height: 550, width: "100%" }}>
                <MaterialTable
                  title="Projects"
                  icons={tableIcons}
                  columns={columns}
                  data={row}
                  options={{ toolbar: false }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
