import MessageArea from './MessageArea';
import './MessageArea.css';
export default MessageArea;