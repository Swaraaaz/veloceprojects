// import { Language } from '@material-ui/icons';
import React, { useEffect, useState } from 'react';
import { Collapse, Dropdown, DropdownButton, Navbar } from 'react-bootstrap';
import { Link, useHistory } from 'react-router-dom';
// import ThemeToggle from './ThemeToggle';
import axios from 'axios';
import './toggle.css'
import logo from '../../img/logo3.png'
import Timer from './Timer';

export default function Navb(props) {
  const [time, setTime] = useState({hour: "00", minutes: "00", seconds: "00"});
  const [menu, setMenu] = useState(true);
  const menuItem = props.menuItem;
  const history = useHistory()

  const notification = (e) => {
    e.preventDefault()
    props.setShow(true)
  }
  // Menu Toggle Function
  function menuToggle() {
    let menubar = document.getElementById("nav-bar")
    setMenu(!menu)
    if (menu) {
      menubar.style.display = 'block'
    } else {
      menubar.style.display = 'none'
    }
  }

  // Logout
  const signout = (e) => {
    e.preventDefault()
    localStorage.removeItem("authenticated")
    localStorage.removeItem("emp_id")
    localStorage.removeItem("role_id")
    localStorage.removeItem("tierlevel")
    localStorage.removeItem("role")
    localStorage.removeItem("active_flag")
    localStorage.removeItem("navRole")
    const obj1 = new Date()
    localStorage.logoutTime = obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds()
    let timer = time.hour + ":" + time.minutes + ":" + time.seconds
    // alert(timer)
    axios.post("http://localhost/php/pms/auth/addtime.php", {time: timer, user_id: localStorage.getItem("emp_id"), date: "current Date"}) .then((resp) => {
      history.push('/Login')
    })
  }

  useEffect(() => {
    /*===== LINK ACTIVE =====*/
    let linkColor = document.querySelectorAll('.nav_link')

    function colorLink() {
      if (linkColor) {
        linkColor.forEach(l => l.classList.remove('active'))
        this.classList.add('active')
      }
    }
    linkColor.forEach(l => {
      if (!(l.tagName === 'P'))
        l.addEventListener('click', colorLink)
    })
    /*===== LINK ACTIVE END =====*/
  });


  return (
    <>
      {/* Mobile View Nav */}
      <Navbar bg="light" className='mobile_navbar'>
        <Link to="/" className="nav_logo">
          <img src={logo} alt="" />
        </Link>
        <i className="bi bi-list" id="menu" style={{ width: '50px', fontSize: '30px' }} onClick={menuToggle}></i>
      </Navbar>
      {/* Mobile View Nav end */}
      <nav className="navbar navbar-light justify-content-between main-nav" style={{background: '#F8FCFF'}}>
        <Link to="/" className="nav_logo">
          <img src={logo} alt="logo" />
        </Link>

        <div className='user'>
          {/* <Avatar {...stringAvatar(localStorage.getItem('name'))} /> */}
{/* 
          <form className="form-inline">
            <input className="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" />
            <button className="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form> */}
          <i className='bx bxs-bell bx-sm px-1 ml-3 border-right' onClick={notification} style={{cursor: 'pointer',lineHeight:'35px',color:'#1E90FF'}}></i>
          
          <i className='bx bxs-user bx-sm px-1 ml-3' aria-hidden="true" style={{textAlign:'center',height:'35px',width:'35px',cursor: 'pointer',lineHeight:'35px',borderRadius:'50%',backgroundColor:'#D5EBFF',boxShadow: 'inset 0px 0px 10px rgba(0, 0, 0, 0.25)'
}}></i>
          <DropdownButton
            id="dropdown-button-dark-example2"
            variant="primary"
            menuVariant="light"
            title={localStorage.getItem("name")}
            className="ml-2"
            // style={{color:'#1E90FF'}}
          >
            <Dropdown.Item href="/my_profile">
              My Account
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item href="/Signout" onClick={signout}>
              <span className="nav_name">SignOut</span>
            </Dropdown.Item>
          </DropdownButton>
        </div>

      </nav>
      <div className="animate__animated fadeInLeft l-navbar show-nav" id="nav-bar">
        {/* Navbar */}
        <nav className="nav">
          <div>
            {/* Logo / Brand Name */}
            <Link to="/" className="nav_logo">
              <img src={logo} alt="logo" />
            </Link>
            {/* Logo / Brand Name End */}

            {/* MenuItems */}
            <div className="nav_list">
              {
                // Dynamically adds Menu Items using Iterations
                menuItem.map((item, key) => {
                  // Checks "is Menu Items having 0 Subitems?"
                  return (item.child.length === 0 ? (
                    // If yes then it print the Menu Item only
                    <MenuItem item={item} key={key} k={key} />
                  ) : (
                    // If no then it print the Menu Item with their Sub Menu Items
                    < >
                      {/* Here it prints the Main Menu Item */}
                      <p
                        key={key}
                        onClick={() => item.setOpen(!item.open)}
                        aria-controls="example-collapse-text"
                        aria-expanded={item.open}
                        className={item.open ? "nav_link active" : "nav_link"}>

                        <i className={item.class} />
                        <span className="nav_name">

                          {item.name}
                          <i className='bx bx-chevron-down' />

                        </span>

                      </p>

                      {/* After that it prints Sub Menu Items inside this Collapse Tag of React-Bootstrap */}
                      <Collapse in={item.open} >
                        {/* Please Don't Remove this Div its Important to Display Sub Menu Item */}
                        <div id="example-collapse-text">
                          {
                            item.child.map((item, key) => (

                              <div key={key}>
                                <SubMenuItem item={item} key={key} k={key} />
                              </div>

                            ))
                          }
                        </div>

                      </Collapse>
                    </>
                  ))
                })
              }
            </div>
            {/* MenuItems */}

          </div>

          {/* Signout Button/ Profile */}
          <div className='nav-bottom'>
          <div style={{ display: 'flow-root' }}>
              {
                props.role === 'super' ? <></> : <Timer time={time} setTime={setTime} />
              }
            </div>
          </div>
        </nav>
        {/* Navbar End */}
      </div>
    </>
  );
}


function MenuItem(props) {
  const [activeState, setActiveState] = useState((window.location.pathname === props.item.link) ? " active" : "");

  return (
    <Link to={props.item.link} key={props.k} className={"nav_link" + activeState} >
      <i className={props.item.class} />
      <span className="nav_name">{props.item.name}</span>
    </Link>
  );
}

function SubMenuItem(props) {
  const [activeState, setActiveState] = useState((window.location.pathname === props.item.link) ? " active" : "");

  return (
    <Link to={props.item.link} key={props.k} className={"nav_link" + activeState} >
      <i className={"sub-menu-item " + props.item.class} />
      <span className="nav_name">{props.item.name}</span>
    </Link>
  );
}