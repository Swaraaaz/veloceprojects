import MaterialTable from "material-table";
import React, { useEffect, useState } from "react";
import tableIcons from "../../MaterialTableIcons";
import axios from "axios";
import Moment from "moment";
import { Modal, Button, Form, Col, Row  } from "react-bootstrap";

export default function AllEmployees() {

  
  const [department, setDepartment] = useState([])
  const [role, setRole] = useState([])
  const [type, setType] = useState([])
  
  //Edit Handle Modal
  const [showModal2, setShow2] = useState(false);
  const handleClose2 = () => setShow2(false);
  const handleShow2 = () => setShow2(true);

    //State is created for storing form data
    // const [updateEmployee,setUpdateEmployee]=useState();
  
    // const [employeeDetails,setEmployeeDetails]=useState();

    useEffect(() => {
      axios.get('http://localhost/php/pms/employee/getDepartment.php').then((resp) => setDepartment(resp.data))
      axios.get('http://localhost/php/pms/employee/getrole.php').then((resp) => setRole(resp.data))
      axios.get('http://localhost/php/pms/employee/getEmployeeType.php').then((resp) => setType(resp.data))
  }, [])

    const [updateEmp,setUpdateEmp]=useState({
      emp_id:"",
      emp_firstname:"",
      emp_lastname:"",
      email:"",
      sex:"",
      dob:"",
      hiring_date:"",

      emp_role:"", //It's Designation
      role:"",

      emp_type:"", //It's Type > Permanent / Temp / Part Time
      type:"",

      department:"", //Technical or Non technical
      deptname:"",
  })

  const onInputChange = (e) => {
    setUpdateEmp({ ...updateEmp, [e.target.name]: e.target.value })
}


  const onDelete = (e, params) => {
    console.log(params.emp_id);
    e.preventDefault();
    axios
      .post("http://localhost/php/new/employee/deleteEmp.php", {
        emp_id: params.emp_id,
      })
      .then(() => {
        axios
          .get("http://localhost/php/new/employee/allEmployee.php")
          .then((res) => {
            //Storing users detail in state array object
            setRow(res.data);
          });
      });
  };

  // const editHandle = (e, row) => {
  //   e.preventDefault()
  // }
  const columns = [
    { title: "Name", field: "empname" },
    { title: "Type", field: "type" },
    { title: "Designation", field: "role" },
    {
      title: "Joining Date",
      field: "hiring_date",
      render: (params) => {
        return <div>{Moment(params.hiring_date).format("DD-MM-YYYY")}</div>;
      },
    },
    {
      tititle: "",
      field: "",
      render: (params) => {
        return (
          <div className="">
            <button
              className="btn btn-primary mx-2"
              style={{ backgroundColor: "white", borderColor: "white" }}
              onClick={(e) => editHandle(params)}
            >
              <i className="bi bi-pencil-square" style={{ color: "blue" }}></i>
            </button>

            <button
              className="btn btn-primary mx-2"
              style={{ backgroundColor: "white", borderColor: "white" }}
              onClick={(e) => onDelete(e, params)}
            >
              <i className="bi bi-trash-fill" style={{ color: "red" }}></i>
            </button>
          </div>
        );
      },
    },
  ];

  const [row, setRow] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost/php/new/employee/allEmployee.php")
      .then((resp) => {
        setRow(resp.data);
        console.log(resp.data);
      });
  }, []);

  // -----------------------------Edit Employee Modal-----------------------------

  const editHandle = (row) => {
    console.log(row)
    handleShow2();
    setUpdateEmp({
      emp_id:row.emp_id,
      emp_firstname:row.emp_firstname,
      emp_lastname:row.emp_lastname,
      email:row.email,
      sex:row.sex,
      dob:row.dob,
      hiring_date:row.hiring_date,

      emp_role:row.emp_role, //It's Designation
      role:row.role,

      emptype:row.emptype, //It's Type > Permanent / Temp / Part Time
      type:row.type,

      department:row.department, //Technical or Non technical
      deptname:row.deptname,
    })
  };

  const onModalFormSubmit2 = (e) => {
    e.preventDefault();
    console.log("Hello Biatch",updateEmp);
    axios.post("http://localhost/php/new/employee/updateEmp.php",updateEmp)
    .then((res) => {
      axios.get("http://localhost/php/new/employee/allEmployee.php")
      .then((resp) => {
        setRow(resp.data);
        console.log(resp.data);
      });
    })
    handleClose2();
  };

  // console.log(updateEmp)
  return (
    <>
      <MaterialTable
        title="All Employee"
        icons={tableIcons}
        columns={columns}
        data={row}
      />

      <Modal show={showModal2} onHide={handleClose2}>
        <Modal.Header>
          <Modal.Title>Edit Employee</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={onModalFormSubmit2} >
                <Row className="mb-3">
                  {/* Task Name */}
                  <Form.Group as={Col} md="6" >
                    <Form.Label>First Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="First Name"
                      name="emp_firstname"
                      defaultValue={updateEmp.emp_firstname}
                      onChange={onInputChange}
                    />        
                  </Form.Group>

                  <Form.Group as={Col} md="6" >
                    <Form.Label>Last Name</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Last Name"
                      name="emp_lastname"
                      defaultValue={updateEmp.emp_lastname}
                      onChange={onInputChange}
                    />        
                  </Form.Group>

              <Form.Group as={Col} md="6">
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      type="text"
                      placeholder="Email address"
                      name="email"
                      defaultValue={updateEmp.email}
                      onChange={onInputChange}
                    >
                    </Form.Control>
             </Form.Group>


             <Form.Group as={Col} md="6" controlId="validationFormik10">
                    <Form.Label>Gender</Form.Label>
                    <Form.Control
                      as="select"
                      placeholder="gender"
                      name="sex"
                      onChange={onInputChange}
                      defaultValue={updateEmp.sex}
                    >
                        <option value='male'>Male</option>
                        <option value='Female'>Female</option>
                    </Form.Control>
            </Form.Group>

            <Form.Group as={Col} md="6" >
                    <Form.Label>Date of Birth</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Date of Birth"
                      name="dob"
                      onChange={onInputChange}
                      defaultValue={updateEmp.dob}
                    />  
            </Form.Group>

            <Form.Group as={Col} md="6" >
                    <Form.Label>Joining Date</Form.Label>
                    <Form.Control
                      type="date"
                      placeholder="Joining Date"
                      name="hiring_date"
                      onChange={onInputChange}
                      defaultValue={updateEmp.hiring_date}
                    />  
            </Form.Group>
                 
          <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>Designation</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="Designation"
                    name="emp_role"
                    defaultValue={updateEmp.emp_role}
                    onChange={onInputChange}
                  >
                    {/* <option key={'empty'} value={''}>{updateEmp.role}</option> */}
                    {role.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.role_id}>{item.role}</option>
                                                );
                                            })}
                  </Form.Control>
            </Form.Group>

            <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>User Type</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="User Type"
                    name="emptype"
                    defaultValue={updateEmp.emptype}
                    onChange={onInputChange}
                  >
                    {/* <option key={'empty'} value={''}>{updateEmp.type}</option> */}
                    {type.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.id}>{item.type}</option>
                                                );
                                            })}
                  </Form.Control>
            </Form.Group>
            
            <Form.Group as={Col} md="6" controlId="validationFormik11">
                  <Form.Label>Department</Form.Label>
                  <Form.Control
                    as="select"
                    placeholder="Department"
                    name="department"
                    defaultValue={updateEmp.department}
                    onChange={onInputChange}
                  >
                    {/* <option key={'empty'} value={''}>{updateEmp.deptname}</option> */}
                    {department.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.id}>{item.department}</option>
                                                );
                                            })}
                  </Form.Control>
            </Form.Group>

                </Row>
                <div style={{textAlign:'center'}} className="mt-3">
                  <Button type="submit">Submit form</Button>
                </div>
              </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={handleClose2}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </>
  );
}
