import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'
import Moment from 'moment';

export default function Active() {
  const deleteHandle = (e, row) => {
    e.preventDefault()
    axios.post('http://localhost/php/new/employee/dismissEmp.php', {dismiss_emp_id: row.emp_id, emp_id: localStorage.getItem("emp_id"), role_id: localStorage.getItem("role_id")}).then(() => {
      axios.get('http://localhost/php/new/employee/allActiveEmployees.php').then(res => {
        //Storing users detail in state array object
        setRow(res.data);
      });
    })
  }

  const editHandle = (e, row) => {
    e.preventDefault()
  }
  const columns = [
    { title: "Name", field: "empname" },
    { title: "Type", field: "emptype" },
    { title: "Designation", field: "role" },
    { title: "Joining Date", field: "hiring_date",
    render:(params)=>{
      return(
        <div>
            {Moment(params.hiring_date).format('DD-MM-YYYY') }
        </div>
      )
    }  },
    // {
    //   tititle: "", field: "",
    //   render: (params) => {
    //     return (
    //       <div className="">
    //         <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
    //           onClick={(e) => editHandle(e, params)}
    //         >
    //           <i className="bi bi-pencil-square" style={{ color: 'blue' }}></i>
    //         </button>
    //         <button className="btn btn-primary mx-2" style={{ backgroundColor: 'white', borderColor: 'white' }}
    //           onClick={(e) => deleteHandle(e, params)}
    //         >
    //           <i className="bi bi-trash-fill" style={{ color: 'red' }}></i>
    //         </button>
    //       </div>
    //     );
    //   }
    // }
  ];

  const [row, setRow] = useState([])
  useEffect(() => {
    axios
      .get("http://localhost/php/new/employee/allActiveEmployees.php")
      .then((resp) => {
        setRow(resp.data)
        console.log(resp.data)
      })
  }, [])


  return (
    <>
      <MaterialTable title="Active Employee" icons={tableIcons} columns={columns} data={row} />
    </>
  )
}
