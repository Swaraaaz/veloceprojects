import { Button, Col, Form, Modal, Row } from 'react-bootstrap';
import React, { useState, useEffect } from 'react'
import { Formik } from 'formik';
import * as yup from 'yup';
import axios from 'axios'

export default function CreateEmployee(props) {

    const [department, setDepartment] = useState([])
    const [role, setRole] = useState([])
    const [type, setType] = useState([])

    useEffect(() => {
        axios.get('http://localhost/php/pms/employee/getDepartment.php').then((resp) => setDepartment(resp.data))
        axios.get('http://localhost/php/pms/employee/getrole.php').then((resp) => setRole(resp.data))
        axios.get('http://localhost/php/pms/employee/getEmployeeType.php').then((resp) => setType(resp.data))
    }, [])

    const schema = yup.object().shape({
        emp_firstname: yup.string().required(),
        emp_lastname: yup.string().required(),
        email: yup.string().email().required(),
        dob: yup.date().required(),
        sex: yup.string().required(),
        role_id: yup.string().required(),
        emptype: yup.string().required(),
        department: yup.string().required(),
        hiring_date: yup.date().required()
    });

    return (
        <>
            <Modal
                show={props.open}
                onHide={() => props.setOpen(false)}
            >
                <Modal.Header closeButton>
                    <Modal.Title>Create Employee</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Formik
                        validationSchema={schema}
                        onSubmit={(values) => {
                            axios.post("http://localhost/php/pms/employee/addEmployee.php", JSON.stringify(values))
                            // alert(JSON.stringify({ ...values, session_emp_id: localStorage.getItem("emp_id"), session_role_id: localStorage.getItem("role_id") }))
                            props.setOpen(false)
                        }}
                        initialValues={{
                            emp_firstname: '',
                            emp_lastname: '',
                            email: '',
                            dob: '',
                            sex: '',
                            role_id: '',
                            emptype: '',
                            department: '',
                            hiring_date: ''
                        }}
                    >
                        {({
                            handleSubmit,
                            handleChange,
                            handleBlur,
                            values,
                            touched,
                            isValid,
                            errors,
                        }) => (
                            <Form noValidate onSubmit={(e) => {
                                e.preventDefault()
                                handleSubmit()
                            }}>
                                <Row className="mb-3">
                                    <Form.Group as={Col} md="6" controlId="validationFormik03">
                                        <Form.Label>First Name</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Employee First Name"
                                            name="emp_firstname"
                                            value={values.emp_firstname}
                                            onChange={handleChange}
                                            isInvalid={!!errors.emp_firstname}
                                        />

                                        <Form.Control.Feedback type="invalid">
                                            {errors.emp_firstname}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik04">
                                        <Form.Label>Last Name</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Last Name"
                                            name="emp_lastname"
                                            value={values.emp_lastname}
                                            onChange={handleChange}
                                            isInvalid={!!errors.emp_lastname}
                                        />
                                        <Form.Control.Feedback type="invalid">
                                            {errors.emp_lastname}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik05">
                                        <Form.Label>Email</Form.Label>
                                        <Form.Control
                                            type="text"
                                            placeholder="Email"
                                            name="email"
                                            value={values.email}
                                            onChange={handleChange}
                                            isInvalid={!!errors.email}
                                        />
                                        <Form.Control.Feedback type="invalid">
                                            {errors.email}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik06">
                                        <Form.Label>Gender</Form.Label>
                                        <Form.Control
                                            as="select"
                                            placeholder="Gender"
                                            name="sex"
                                            value={values.sex}
                                            onChange={handleChange}
                                            isInvalid={!!errors.sex}
                                        >
                                            <option key={'empty'} value={''}>Select gender  </option>
                                            <option value="male">Male</option>
                                            <option value="Female">Female</option>
                                        </Form.Control>
                                        <Form.Control.Feedback type="invalid">
                                            {errors.sex}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik07">
                                        <Form.Label>Date of Birth</Form.Label>
                                        <Form.Control
                                            type="date"
                                            placeholder="Contact No."
                                            name="dob"
                                            min="1950-01-01"
                                            max="2000-12-31"
                                            value={values.dob}
                                            onChange={handleChange}
                                            isInvalid={!!errors.dob}
                                        />
                                        <Form.Control.Feedback type="invalid">
                                            {errors.dob}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik08">
                                        <Form.Label>Joining</Form.Label>
                                        <Form.Control
                                            type="date"
                                            placeholder="Contact No."
                                            name="hiring_date"
                                            value={values.dhiring_dateob}
                                            onChange={handleChange}
                                            isInvalid={!!errors.hiring_date}
                                        />
                                        <Form.Control.Feedback type="invalid">
                                            {errors.hiring_date}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik09">
                                        <Form.Label>Designation</Form.Label>
                                        <Form.Control
                                            as="select"
                                            placeholder="Designation"
                                            name="role_id"
                                            value={values.role_id}
                                            onChange={handleChange}
                                            isInvalid={!!errors.role_id}
                                        >
                                            <option key={'empty'} value={''}>Select Designation</option>
                                            {role.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.role_id}>{item.role}</option>
                                                );
                                            })}
                                        </Form.Control>
                                        <Form.Control.Feedback type="invalid">
                                            {errors.role_id}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik10">
                                        <Form.Label>Type</Form.Label>
                                        <Form.Control
                                            as="select"
                                            placeholder="Designation"
                                            name="emptype"
                                            value={values.emptype}
                                            onChange={handleChange}
                                            isInvalid={!!errors.emptype}
                                        >
                                            <option key={'empty'} value={''}>Select Type</option>
                                            {type.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.id}>{item.type}</option>
                                                );
                                            })}
                                        </Form.Control>
                                        <Form.Control.Feedback type="invalid">
                                            {errors.emptype}
                                        </Form.Control.Feedback>
                                    </Form.Group>
                                    <Form.Group as={Col} md="6" controlId="validationFormik11">
                                        <Form.Label>Department</Form.Label>
                                        <Form.Control
                                            as="select"
                                            placeholder="Department"
                                            name="department"
                                            value={values.department}
                                            onChange={handleChange}
                                            isInvalid={!!errors.department}
                                        >
                                            <option key={'empty'} value={''}>Select Type</option>
                                            {department.map((item, key) => {
                                                return (
                                                    <option key={key} value={item.id}>{item.department}</option>
                                                );
                                            })}
                                        </Form.Control>
                                        <Form.Control.Feedback type="invalid">
                                            {errors.department}
                                        </Form.Control.Feedback>
                                    </Form.Group>

                                </Row>
                                <Button type="submit">Submit form</Button>
                            </Form>
                        )}
                    </Formik>
                </Modal.Body>
            </Modal>
        </>
    );
}
