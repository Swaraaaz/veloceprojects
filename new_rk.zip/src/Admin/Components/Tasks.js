import React, { useState } from 'react'
import AllTasks from './Tasks/AllTasks'
import Approved from './Tasks/Approved'
import Ongoing from './Tasks/Ongoing'
import Deadline from './Tasks/Deadline'
import { Paper, Tab, Tabs } from '@material-ui/core'
import './Tasks/task.css'
import CreateTask from './Tasks/CreateTask'
import EditTask from './Tasks/EditTasks'
import MyTasks from './Tasks/MyTasks'
import AdminAllTasks from './Tasks/AdminAllTasks'
import OngoingEmpTasks from './Tasks/OngoingEmpTasks'
import CompletedEmpTasks from './Tasks/CompletedEmpTasks'
import AllEmpTasks from './Tasks/AllEmpTask'
import TaskApproval from './Tasks/TaskApproval'

export default function Tasks() {
  const [value, setValue] = useState(0)
  const [open, setOpen] = useState(false)
  const [taskId, setTaskId] = useState('')
  const [open1, setOpen1] = useState(false)
  const [editData, setEditData] = useState({
    task_title: '',
    assign_to: '',
    project_id: '',
    priority: '',
    responsible_person: '',
    task_start_date: '',
    linked_issues_arr: '',
    task_finish_date: '',
    reminder_date: '',
    reminder_reponsible_person: '',
    linked_issue_condition: '',
  })
  return (
    <>
      {
        localStorage.getItem("navRole") === "super" ? <>
          <CreateTask open={open} setOpen={setOpen} />
          {
            open1 === true ? <EditTask open1={open1} setOpen1={setOpen1} taskId={taskId} editData={editData} /> : <></>
          }
          <Paper style={{ justifyContent: 'space-between', display: 'flex', marginBottom: '1rem' }}>
            <Tabs
              variant="scrollable"
              value={value}
              textColor="primary"
              indicatorColor="primary"
              onChange={(event, newValue) => {
                setValue(newValue)
              }}
            >
              <Tab label="All Tasks" />
              <Tab label="Ongoing" />
              <Tab label="Approve" />
              <Tab label="Deadline" />
            </Tabs>
            <button className='btn btn-primary btn-employee' onClick={(e) => setOpen(true)}>Create New Task</button>
          </Paper>
          {
            value === 0 ? <AllTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
              value === 1 ? <Ongoing open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                value === 2 ? <TaskApproval open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                  value === 3 ? <Deadline open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> : <></>
          }
        </> : localStorage.getItem("navRole") === "coordinator" ?
          <>
            <CreateTask open={open} setOpen={setOpen} />
            {
              open1 === true ? <EditTask open1={open1} setOpen1={setOpen1} taskId={taskId} editData={editData} /> : <></>
            }
            <Paper style={{ justifyContent: 'space-between', display: 'flex', marginBottom: '1rem' }}>
              <Tabs
                variant="scrollable"
                value={value}
                textColor="primary"
                indicatorColor="primary"
                onChange={(event, newValue) => {
                  setValue(newValue)
                }}
              >
                <Tab label="All Tasks" />
                <Tab label="Ongoing" />
                <Tab label="Deadline" />

              </Tabs> 
              <input type="date" className='form-control date' style={{width:'20%',marginLeft:'25%'}}/>
              <button className='btn btn-primary btn-employee' onClick={(e) => setOpen(true)}>Create New Task</button>
            </Paper>

            {
              value === 0 ? <AdminAllTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                value === 1 ? <Ongoing open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                  value === 2 ? <Deadline open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> : <></>
            }
          </>
          : localStorage.getItem("navRole") === "principalArch" ?
            <>
              <Paper style={{ justifyContent: 'space-between', display: 'flex', marginBottom: '1rem' }}>
                <Tabs
                  variant="scrollable"
                  value={value}
                  textColor="primary"
                  indicatorColor="primary"
                  onChange={(event, newValue) => {
                    setValue(newValue)
                  }}
                >
                  <Tab label="All Tasks" />
                  <Tab label="Ongoing" />
                  <Tab label="Approve" />
                  <Tab label="Deadline" />
                </Tabs>
              </Paper>
              {
                value === 0 ? <AllTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                  value === 1 ? <Ongoing open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                    value === 2 ? <Approved open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                      value === 3 ? <Deadline open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> : <></>
              }
            </> : localStorage.getItem("navRole") === "otherEmp" ?
              <>
                <Paper style={{ justifyContent: 'space-between', display: 'flex', marginBottom: '1rem' }}>
                  <Tabs
                    variant="scrollable"
                    value={value}
                    textColor="primary"
                    indicatorColor="primary"
                    onChange={(event, newValue) => {
                      setValue(newValue)
                    }}
                  >
                    <Tab label="My Tasks" />
                    <Tab label="Ongoing"/>
                    <Tab label="Deadline" />
                    <Tab label="Completed" />
                  </Tabs>
                </Paper>
                {
                value === 0 ? <MyTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                value === 1 ? <OngoingEmpTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                value === 2 ? <Deadline open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                value === 3 ? <CompletedEmpTasks open1={open1} setOpen1={setOpen1} setTaskId={setTaskId} taskId={taskId} editData={editData} setEditData={setEditData} /> :
                 <></>
                }
              </>
              : <></>
      }
    </>
  )

}
