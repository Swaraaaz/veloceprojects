import React, { useState } from 'react';
import { Route } from 'react-router-dom';
import { Switch } from 'react-router-dom';
import Dashboard from './Dashboard';
import Projects from './Projects'
import Tasks from './Tasks'
import Report from './Report'
import Employee from './Employee';
import UpdateTaskStatus from './Tasks/UpdateTaskStatus'
import DashboardforOther from './DashboardforOther';
import MyTasks from './Tasks/MyTasks';
import Project_status from '../Project_status';
import GanttChart from '../GanttChart';
import DonutEmp from '../DonutEmp';
import Emp_status from '../Emp_status';
import CompletedEmpTasks from './Tasks/CompletedEmpTasks';
import CoordinatorTask from './Tasks/CoordinatorTask';
import Employee_status_task from '../Employee_status_task.js';


export default function MainRoutes(props) {
    const [navRole, setNavRole] = useState(localStorage.getItem("navRole"))
    return (
        <div className='mainb' id="mainb">
            <Switch>
                {/* <Route path='/Dashboard'> <Dashboard /></Route>
                <Route path='/Projects'> <Projects /></Route>
                <Route path='/Tasks'> <Tasks /></Route>
                <Route path='/Reports'> <Report /></Route>
                <Route path='/Employee'> <Employee /></Route> */}
                {
                    navRole === 'super' ?
                        <>
                            <Route path='/Dashboard'> <Dashboard /></Route>
                            <Route path='/Projects'> <Projects /></Route>
                            <Route path='/Tasks'> <Tasks /></Route>
                            <Route path='/Update_Status/:id'> <UpdateTaskStatus /> </Route>
                    
                            {/* <Route path='/Update_Status'> <UpdateTaskStatus /> </Route> */}
                            <Route path='/Reports'> <Report /></Route>
                            <Route path='/Employee'> <Employee /></Route>
                            <Route path='/Emp_status'> <Emp_status/> </Route>
                            <Route path='/Employee_status_task'> <Employee_status_task/> </Route>
                            <Route path='/Project_status'> <Project_status/> </Route>
                            <Route path='/GanttChart'> <GanttChart/> </Route>
                            <Route path='/DonutEmp'><DonutEmp/></Route>
                            {/* <Route path='/ganttchart'> <GanttChart/> </Route> */}
                        </> :
                        
                    navRole === 'principalArch' ?
                    <>
                        <Route path='/Dashboard'> <DashboardforOther /></Route>
                        <Route path='/Projects'> <Projects /></Route>
                        <Route path='/Tasks'> <Tasks /></Route>
                        <Route path='/Update_Status/:id'> <UpdateTaskStatus /> </Route>
                    </> :
                    
                    navRole === 'coordinator' ?
                        <>
                            {/* <Route path='/Dashboard'> <DashboardforOther /></Route> */}
                            <Route path='/Tasks'> <Tasks /></Route>
                            <Route path='/MyTasks'><CoordinatorTask/> </Route>
                            <Route path='/Update_Status/:id'> <UpdateTaskStatus /> </Route>
                        </> :
                        
                    navRole === 'otherEmp' ?
                    <>
                        <Route path='/Dashboard'> <DashboardforOther /></Route>
                        <Route path='/Tasks'> <Tasks /></Route>
                        <Route path='/MyTasks'> <MyTasks/> </Route>
                            <Route path='/Update_Status/:id'> <UpdateTaskStatus /> </Route>
                            <Route path='/CompletedEmpTasks'><CompletedEmpTasks/></Route>
                    </> :
                        <></>
                }
                {/* <Route component={PageNotFound} /> */}


                {/* {
                    menuItem.map((item, key) => {
                        if (item.child.length === 0) {
                            return (
                                <Route path={'/' + item.link} key={key}>
                                    {item.Component}
                                </Route>
                            )
                        } else {
                            return (
                                item.child.map((item, key) => (
                                    <Route path={'/' + item.link} key={key}>
                                        {item.Component}
                                    </Route>
                                ))
                            )
                        }
                    })
                } */}


            </Switch>
        </div>
    );
}
