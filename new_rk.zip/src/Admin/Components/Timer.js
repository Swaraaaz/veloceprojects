import React, { useEffect, useState } from 'react'
import DisplayComponent from './Timer/DisplayComponent';

export default function Timer(props) {

  useEffect(() => {
    start()
  }, [props.time])
  

  const start = () => {

    setTimeout(function () {
      const obj1 = new Date()
      const secs = obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds()
      var n = secs - localStorage.seconds
      var hour = parseInt(n / 3600);
      if(hour < 10){
        hour = "0" + hour
      }

      n %= 3600;
      var minutes = parseInt(n / 60);
      if(minutes < 10){
        minutes = "0" + parseInt(minutes)
      }

      n %= 60;
      var seconds = parseInt(n);
      if(seconds < 10){
        seconds = "0" + parseInt(seconds)
      }
      props.setTime({hour: hour+"", minutes: minutes+"", seconds: seconds+""})
    }, 1000);
  };

  return (
    <> 
      <DisplayComponent time={props.time} />
    </>
  )
}
