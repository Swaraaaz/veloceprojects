import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'

function Employee(props) {
    const columns = [
        { title: "Name", field: "emp_name" },
        { title: "Position", field: "role" },
        { title: "Working Days", field: "days"},
        { title: "Working Hours", field: "hours" },
        { title: "Total Projects", field: "titles" },
        { title: "Total Tasks", field: "projects" },
      ];
    
      const [row, setRow] = useState([])
      useEffect(() => {
          console.log(props.emp.to_date)
        axios
        .post("http://localhost/php/new/report/employee.php", {from: props.emp.from_date, to: props.emp.to_date})
        .then((resp) => {
          setRow(resp.data)
          console.log(resp.data)
        })
      }, [props.emp])
      
      
      return (
        <>
          <MaterialTable title="Employee" icons={tableIcons} columns={columns} data={row==="No rows"?[]:row} />
        </>
      )
}

export default Employee