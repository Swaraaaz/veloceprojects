import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'


function Projects(props) {
    const columns = [
        { title: "Project Name", field: "project_name" },
        { title: "Actual Start Date", field: "actual_start_date" },
        { title: "Estimated End Date", field: "estimated_end_date"},
        { title: "Ongoing Tasks", field: "ongoing" },
        { title: "Completed Tasks", field: "completed" },
      ];
    
      const [row, setRow] = useState([])
      useEffect(() => {
        axios
        .post("http://localhost/php/new/report/allProjects.php",{from: props.proj.from_date, to:props.proj.to_date})
        .then((resp) => {
          setRow(resp.data)
          console.log(resp.data)
        })
      }, [props.proj])
      
      
      return (
        <>
          <MaterialTable title="Projects" icons={tableIcons} columns={columns} data={row==="No rows"?[]:row} />
        </>
      )
}

export default Projects