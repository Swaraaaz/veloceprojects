import MaterialTable from 'material-table';
import React, { useEffect, useState } from 'react'
import tableIcons from '../../MaterialTableIcons'
import axios from 'axios'

function Task(props) {
    const columns = [
        { title: "Task Name", field: "task_title" },
        { title: "Project Name", field: "project_name" },
        { title: "Employee Name", field: "emp_name"},
        { title: "Time", field: "timer" },
        { title: "status", field: "state" },
      ];
    
      const [row, setRow] = useState([])
      useEffect(() => {
        axios
        .post("http://localhost/php/new/report/tasks.php", {from: props.ta.from_date, to: props.ta.to_date})
        .then((resp) => {
          setRow(resp.data)
          console.log(resp.status)
        })
      },[props.ta])
      
      
      return (
        <>
          <MaterialTable title="Tasks" icons={tableIcons} columns={columns} data={row} />
        </>
      )
}

export default Task