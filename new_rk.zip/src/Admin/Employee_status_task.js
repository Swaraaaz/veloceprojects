import React, { useEffect, useState } from 'react';
import Chart from 'react-google-charts';
import { Link } from "react-router-dom";
import axios from 'axios';
import MaterialTable from 'material-table';
import tableIcons from "./MaterialTableIcons";
import { useHistory } from 'react-router';
import Moment from 'moment';
import high from '../img/high.png'
import Moderate from '../img/Moderate.png'
import low from '../img/low.png'

const Employee_status_task = () => {

  
  const [activityStream, setActivityStream] = useState()


  const history = useHistory()
  const goToTask = (e, row) => {
    e.preventDefault()
    localStorage.openedTime = new Date().toLocaleDateString("en-IN", { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' })
    if (row.state === "In Progress" || row.state === "New" || row.state === "Incomplete")
      localStorage.setItem("taskState", "in-progress")
    else
      localStorage.setItem("taskState", "view")

    const obj1 = new Date()
    localStorage.setItem("currentTime", obj1.getHours() * 60 * 60 + obj1.getMinutes() * 60 + obj1.getSeconds())
    let state0 = 0
    if (row.state === "Approved") {
      state0 = "3"
    } else if (row.state === "Closed Approved") {
      state0 = "4"
    } else if (row.state === "New") {
      state0 = "0"
    } else if (row.state === "In Progress") {
      state0 = "1"
    } else if (row.state === "Closed Rejected") {
      state0 = "5"
    } else if (row.state === " Complete") {
      state0 = "2"
    } else if (row.state === "Incomplete") {
      state0 = "3"
    }
    history.push("/Update_Status/" + row.task_id, { task_id: row.task_id, emp_id: localStorage.getItem("emp_id"), state0: state0 })
  }

  const column2 = [
    // {showTitle:"false"},
    { title: "Task name",
    field: "task_title",
    align: "jusify", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' },
    // render: (params) => {
    //     return (
    //       <div className="task_title" onClick={(e) => viewHandle(e, params)}>
    //         {params.task_title}
    //       </div>
    //     );
    //   }
},

    { title: "Project Name ",
    field: "project_name",
    align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' } },

    { title: "Due Date",
    field: "due_date",
    align: "center",headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'black' },
    render:(params)=>{
        return(
          <div>
              {Moment(params.due_date).format('DD-MM-YYYY') }
          </div>
        )
      }  
},

    { title: "Priority",
    field: "priority",
    align: "center", headerStyle: { fontWeight: 'bold', fontSize: '1.1rem', color: 'Black' },
    render: (params) => {
        return (
          <div className="priority">
            {
              params.priority === "Moderate" ? <img src={Moderate} alt="Moderate" /> :
                params.priority === "High" ? <img src={high} alt="High" /> :
                  params.priority === "Low" ? <img src={low} alt="Low" /> :
                    <></>
            }
          </div>
        );
      }
},

{
    title: "Status", field: "state_name",
    render: (params) => {
      return (
        <div className="">
          {
            params.state_name === "Approved" ? <span className='verified'>Verified</span> :
              params.state_name === "Closed Approved" ? <span className='Rejected'>Closed</span> :
                params.state_name === "New" ? <span className='new'>New</span> :
                  params.state_name === "In Progress" ? <span className='in-progress'>In Progress</span> :
                    params.state_name === "Closed Rejected" ? <span className='Rejected'>Rejected</span> :
                      params.state_name === " Complete" ? <span className='completed'>Complete</span> : <></>
          }
        </div>
      );
    }
  },
  ];

  const [value, setValue] = useState(0)
  const [row, setRow] = useState([])
  useEffect(() => {
      axios
      .post("http://localhost/php/new/tasks/getEmpAllTasks.php",{emp_id:23})
      .then((resp) => {
        setRow(resp.data)
      })
  }, [])

  return (




      <MaterialTable
        title="Today's Task "
        icons={tableIcons}
        columns={column2}
        variant="scrollable"
        style={{ marginTop: '5%', maxWidth: '300%' }}
        value={value}
        textColor="primary"
        indicatorColor="primary"
        data={row}
        options={{
          exportButton: true,
        }}
      />

   

  );
}

export default Employee_status_task;