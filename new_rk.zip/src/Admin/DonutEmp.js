import React from 'react';
import { PieChart, Pie} from 'recharts';
  
  
const DonutEmp = () => {
    const renderCustomizedLabel = ({
        x, y, name
      }) => {
        return (
          <text x={x} y={y} fill="black" textAnchor="end" dominantBaseline="central">
            {name}
          </text>
        );
      };
// Sample data
const data = [
  {name: '300', students: 300,fill: '#1c96ff'},
  {name: '200', students: 200,fill: '#0c5493'},
  {name: '500', students: 500,fill: '#0578db'},
  
  // {name: 'Geek-o-mania', students: 1000}
];
  
return (
 
        <PieChart width={230} height={230}>
          <Pie data={data}  dataKey="students" outerRadius={80} innerRadius={50} isAnimation={false} label={renderCustomizedLabel} nameKey="name"/>
        </PieChart>
        
);
}
  
export default DonutEmp;